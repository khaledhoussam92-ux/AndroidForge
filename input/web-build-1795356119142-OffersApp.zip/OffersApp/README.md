# عروضي — تطبيق أندرويد خفيف

حفظ عدة أرقام (جلسات مشفّرة على الهاتف)، عرض الرصيد والباقات النشطة، تفعيل العروض (1GB / 2GB / يوتيوب)، الهدية اليومية، وصناديق Power Snake.

## التقنيات (أحدث إصدارات وقت الإنشاء — نوفمبر 2026)
- Android Gradle Plugin 9.5.0 · Gradle 9.6.1 · Kotlin 2.4.20
- Jetpack Compose BOM 2026.11.01 (Material 3 1.5.0) · Activity Compose 1.13.0 · Lifecycle 2.11.0
- بدون مكتبات شبكة أو JSON خارجية (HttpURLConnection + org.json) ليبقى الحجم صغيرًا (~2–3 MB بعد R8).
- minSdk 26 · compileSdk 37.1 · JDK 17+ (يُنصح 21)

## طريقة البناء

### 1) الأسهل — من GitHub (بدون كمبيوتر)
1. أنشئ مستودعًا على GitHub وارفع محتوى هذا المجلد.
2. تبويب **Actions ← Build APK ← Run workflow**.
3. حمّل الملف من **Artifacts ← offers-apk** وثبّته على الهاتف.

### 2) Android Studio (أحدث إصدار)
افتح المجلد ← انتظر المزامنة ← **Build ← Build APK(s)**.
أو من الطرفية (يلزم Gradle 9.6.1+):
```
gradle assembleRelease
```
الناتج: `app/build/outputs/apk/release/app-release.apk`

> ملاحظة: الـ APK موقّع بمفتاح debug لسهولة التثبيت. للنشر الرسمي أنشئ مفتاحك وعدّل `signingConfig` في `app/build.gradle.kts`.

## ملاحظات
- إذا لم يتوفر SDK 37.1 على جهاز البناء، ثبّته من SDK Manager (أو خفّض الـ BOM إلى إصدار أقدم مع compileSdk 37).
- الخدمة تستخدم واجهات غير رسمية لتطبيق المشغّل؛ قد تتغير أو تتوقف في أي وقت، واستخدمها على أرقامك فقط.
