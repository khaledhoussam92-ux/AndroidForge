package com.offers.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Account(
    val msisdn: String,
    val instanceId: String,
    val label: String = "",
    val accessToken: String = "",
    val refreshToken: String = "",
    val accessExp: Long = 0,
    val refreshExp: Long = 0,
) {
    val masked get() = "0" + msisdn.removePrefix("213").take(1) + "••••" + msisdn.takeLast(4)
    val title get() = label.ifBlank { masked }
    val hasSession: Boolean
        get() = System.currentTimeMillis() / 1000 < refreshExp - 60 ||
            System.currentTimeMillis() / 1000 < accessExp - 60
}

/** تشفير بيانات الحسابات (الرموز) بمفتاح داخل Android Keystore. */
private object Vault {
    private const val ALIAS = "offers_vault_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun decrypt(data: String): String {
        val all = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    }
}

class Store(context: Context) {
    private val sp = context.getSharedPreferences("accounts_v1", Context.MODE_PRIVATE)

    fun load(): List<Account> = try {
        val raw = sp.getString("data", null) ?: return emptyList()
        val arr = JSONArray(Vault.decrypt(raw))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Account(
                msisdn = o.getString("m"),
                instanceId = o.getString("i"),
                label = o.optString("l", ""),
                accessToken = o.optString("a", ""),
                refreshToken = o.optString("r", ""),
                accessExp = o.optLong("ae", 0),
                refreshExp = o.optLong("re", 0),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Account>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("m", it.msisdn).put("i", it.instanceId).put("l", it.label)
                    .put("a", it.accessToken).put("r", it.refreshToken)
                    .put("ae", it.accessExp).put("re", it.refreshExp)
            )
        }
        sp.edit().putString("data", Vault.encrypt(arr.toString())).apply()
    }
}
