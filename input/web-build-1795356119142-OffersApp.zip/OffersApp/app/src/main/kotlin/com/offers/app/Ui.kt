package com.offers.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale

private val Brand = Color(0xFFE5002B)

private val LightScheme = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD9),
    onPrimaryContainer = Color(0xFF410006),
    secondary = Color(0xFF775653),
    background = Color(0xFFF7F5F6),
    surface = Color.White,
    onSurface = Color(0xFF1F1A1B),
    onSurfaceVariant = Color(0xFF6B6061),
    surfaceVariant = Color(0xFFF1E4E3),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF5A64),
    onPrimary = Color(0xFF68000F),
    primaryContainer = Color(0xFF93001B),
    onPrimaryContainer = Color(0xFFFFDAD9),
    secondary = Color(0xFFE7BDB9),
    background = Color(0xFF121012),
    surface = Color(0xFF1C191A),
    onSurface = Color(0xFFEBE0E0),
    onSurfaceVariant = Color(0xFFB8AAAA),
    surfaceVariant = Color(0xFF3A3233),
)

@Composable
fun OffersTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        content = content,
    )
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BackHandler(enabled = vm.screen !is Screen.Home) { vm.back() }

        when (val s = vm.screen) {
            is Screen.Home -> HomeScreen(vm)
            is Screen.Add -> AddScreen(vm, s.prefill)
            is Screen.Detail -> DetailScreen(vm, s.msisdn)
        }

        Dialogs(vm)
    }
}

// ------------------------------------------------------------ Home

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(vm: AppViewModel) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("أرقامي", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { vm.startAdd() },
                text = { Text("إضافة رقم") },
                icon = { Text("+", fontSize = 22.sp) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        },
    ) { pad ->
        if (vm.accounts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad).padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "لا توجد أرقام محفوظة.\nأضف رقمك لتفعيل العروض بسهولة.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(vm.accounts, key = { it.msisdn }) { acc -> AccountCard(vm, acc) }
            }
        }
    }
}

@Composable
private fun AccountCard(vm: AppViewModel, acc: Account) {
    Card(
        onClick = {
            if (acc.hasSession) vm.open(acc.msisdn) else vm.startAdd("0" + acc.msisdn.removePrefix("213"))
        },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    acc.title.take(1),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(acc.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    (if (acc.label.isNotBlank()) acc.masked + " · " else "") +
                        if (acc.hasSession) "الجلسة نشطة" else "يلزم تسجيل الدخول",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = { vm.askDelete(acc) }) { Text("🗑") }
        }
    }
}

// ------------------------------------------------------------ Add

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddScreen(vm: AppViewModel, prefill: String) {
    var number by rememberSaveable(prefill) { mutableStateOf(prefill) }
    var label by rememberSaveable { mutableStateOf("") }
    var otp by rememberSaveable { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (vm.otpStep) "رمز التحقق" else "إضافة رقم", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = { vm.back() }) { Text("→", fontSize = 22.sp) } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (!vm.otpStep) {
                Text(
                    "أدخل رقمك وسيصلك رمز تحقق عبر SMS. يُحفظ الرقم وجلسته مشفّرَين على هاتفك فقط.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("رقم الهاتف (05xxxxxxxx)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("اسم للرقم (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { vm.sendOtp(number, label) },
                    enabled = !vm.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("إرسال رمز التحقق") }
            } else {
                Text(
                    "أدخل الرمز الذي وصلك على الرقم $number",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = otp,
                    onValueChange = { otp = it.filter(Char::isDigit).take(8) },
                    label = { Text("رمز التحقق") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { vm.verifyOtp(otp) },
                    enabled = !vm.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("تأكيد") }
                TextButton(onClick = { vm.back() }, modifier = Modifier.fillMaxWidth()) { Text("تغيير الرقم") }
            }
        }
    }
}

// ------------------------------------------------------------ Detail

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScreen(vm: AppViewModel, msisdn: String) {
    val acc = vm.accounts.firstOrNull { it.msisdn == msisdn }
    val d = vm.detail
    var renaming by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(acc?.title ?: "", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = { vm.goHome() }) { Text("→", fontSize = 22.sp) } },
                actions = {
                    IconButton(onClick = { renaming = true }) { Text("✎", fontSize = 20.sp) }
                    IconButton(onClick = { vm.refreshDetail() }) { Text("↻", fontSize = 22.sp) }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (vm.busy || d.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            // الرصيد
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("الرصيد", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                    Text(
                        d.balance?.let { "$it دج" } ?: "…",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        acc?.masked ?: "",
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            if (d.error != null) {
                Text(d.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            // العروض النشطة
            Section("العروض النشطة") {
                val list = d.allowances
                when {
                    list == null -> Text("جارٍ التحميل…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    list.isEmpty() -> Text("لا توجد باقات إنترنت نشطة.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else -> list.forEachIndexed { i, a ->
                        if (i > 0) HorizontalDivider()
                        AllowanceRow(a)
                    }
                }
            }

            // تفعيل عرض
            Section("تفعيل عرض") {
                BUNDLES.forEachIndexed { i, b ->
                    if (i > 0) HorizontalDivider()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(b.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${b.desc} · ${b.price}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        FilledTonalButton(onClick = { vm.askBuy(b) }, enabled = !vm.busy) { Text("تفعيل") }
                    }
                }
            }

            // الهدية
            Section("الهدية اليومية") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "الحالة: " + (d.gift?.text ?: "…"),
                        Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FilledTonalButton(onClick = { vm.askGift() }, enabled = !vm.busy && d.gift?.availableNow != false) {
                        Text("العب")
                    }
                }
            }

            // الصناديق
            Section("صناديق Power Snake") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "افتح الصناديق المتاحة للحصول على مكافآت.",
                        Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FilledTonalButton(onClick = { vm.loadBoxes() }, enabled = !vm.busy) { Text("عرض") }
                }
            }
            Spacer(Modifier.size(16.dp))
        }
    }

    if (renaming && acc != null) {
        var text by remember { mutableStateOf(acc.label) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("اسم الرقم") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = { vm.rename(acc.msisdn, text); renaming = false }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun AllowanceRow(a: Allowance) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(a.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text("${num(a.remaining)} / ${num(a.total)} ${a.unit}")
        }
        val total = a.total
        val rem = a.remaining
        val p = if (total != null && rem != null && total > 0) (rem / total).toFloat().coerceIn(0f, 1f) else 0f
        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
        Text(
            "ينتهي: ${a.expiry}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun num(v: Double?): String =
    if (v == null) "—" else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

// ------------------------------------------------------------ Dialogs

@Composable
private fun Dialogs(vm: AppViewModel) {
    vm.notice?.let { n ->
        AlertDialog(
            onDismissRequest = { vm.notice = null },
            title = { Text(n.title) },
            text = { Text(n.body) },
            confirmButton = { TextButton(onClick = { vm.notice = null }) { Text("حسنًا") } },
        )
    }
    vm.confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.confirm = null },
            title = { Text(c.title) },
            text = { Text(c.body) },
            confirmButton = {
                TextButton(onClick = { vm.confirm = null; c.onYes() }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { vm.confirm = null }) { Text("إلغاء") } },
        )
    }
    vm.boxes?.let { list ->
        AlertDialog(
            onDismissRequest = { vm.boxes = null },
            title = { Text("الصناديق المتاحة (${list.size})") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    list.forEachIndexed { i, b ->
                        if (i > 0) HorizontalDivider()
                        Text(
                            "صندوق ${i + 1} · ينتهي ${b.expiry}",
                            Modifier.fillMaxWidth().clickable { vm.askRedeem(b) }.padding(vertical = 14.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.boxes = null }) { Text("إغلاق") } },
        )
    }
}
