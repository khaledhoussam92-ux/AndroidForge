package com.offers.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.CookieHandler
import java.net.CookieManager
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class AuthRequired : Exception("انتهت الجلسة، سجّل الدخول من جديد")
class ApiError(message: String) : Exception(message)

data class Resp(val code: Int, val headers: Map<String, String>, val text: String) {
    val ok get() = code in 200..299
    fun json(): Any? {
        val t = text.trim()
        return try {
            when {
                t.startsWith("{") -> JSONObject(t)
                t.startsWith("[") -> JSONArray(t)
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}

data class Allowance(
    val name: String,
    val code: String,
    val total: Double?,
    val remaining: Double?,
    val unit: String,
    val expiry: String,
)

data class SnakeBox(val uuid: String, val expiry: String)
data class Gift(val availableNow: Boolean, val text: String)
data class Outcome(val ok: Boolean, val title: String, val message: String)

object Api {
    private const val BASE = "https://apis.ooredoo.dz"
    private const val BFF = "$BASE/api/ooredoo-bff"
    private const val TOKEN_URL = "$BASE/api/auth/realms/myooredoo/protocol/openid-connect/token"
    private const val TOKEN_PATH = "/api/auth/realms/myooredoo/protocol/openid-connect/token"
    private const val SNAKE_PATH = "/api/ooredoo-bff/gamification/power-snake"
    private const val GIFT_PLAY_PATH = "/api/ooredoo-bff/gamification/play"
    private const val GIFT_STATUS_PATH = "/api/ooredoo-bff/gamification/status"
    private const val PURCHASE_PATH = "/api/ooredoo-bff/cvm/dynamic-bundle-purchase"
    private const val BYOP_PATH = "/api/ooredoo-bff/bundle/purchase/byop"
    private const val ACTIVE_PACKAGES_PATH = "/api/ooredoo-bff/bundle/getActivePackages"
    private const val ALLOCATIONS_PATH = "/api/ooredoo-bff/cvm/getCvmAllocations"

    private const val CLIENT_ID = "myooredoo-app"
    private const val X_SIGNATURE = "ee41e0dcab1ac6840c6d83cba9dcbe1d4b24074fdab16718ae12f48950080114"
    private const val X_VERSION = "1.5.21"
    private const val USER_AGENT = "Dart/3.11 (dart:io)"

    init {
        if (CookieHandler.getDefault() == null) CookieHandler.setDefault(CookieManager())
    }

    fun newInstanceId() = UUID.randomUUID().toString() + System.currentTimeMillis()

    // ---------- headers / http ----------

    private fun platformSig(deviceId: String): String {
        val raw = """{"platform":"android","is-physical-device":true,"device-id":"$deviceId"}"""
        return Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    private fun fingerprint(iid: String, msisdn: String, ts: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(ts.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal((ts + iid + msisdn).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun headers(
        acc: Account,
        contentType: String = "application/json",
        path: String? = null,
        method: String? = null,
    ): MutableMap<String, String> {
        val ts = System.currentTimeMillis().toString()
        val psig = platformSig(acc.instanceId)
        val h = linkedMapOf(
            "User-Agent" to USER_AGENT,
            "Accept" to "application/json",
            "Content-Type" to contentType,
            "x-msisdn" to acc.msisdn,
            "x-device-fingerprint" to fingerprint(acc.instanceId, acc.msisdn, ts),
            "x-platform-origin" to "mobile-android",
            "x-correlation-id" to UUID.randomUUID().toString() + System.currentTimeMillis(),
            "platform" to "android",
            "x-version" to X_VERSION,
            "x-signature" to X_SIGNATURE,
            "x-platform-info" to psig,
            "x-platform-data-signature" to psig,
            "x-timestamp" to ts,
            "x-instance-id" to acc.instanceId,
            "x-force-update" to "true",
        )
        if (path != null) h["x-path"] = path
        if (method != null) h["x-method"] = method.uppercase()
        return h
    }

    private fun authHeaders(acc: Account, nonce: Pair<String, String>? = null,
                            contentType: String = "application/json"): MutableMap<String, String> {
        val h = headers(acc, contentType)
        h["Authorization"] = "Bearer " + acc.accessToken
        if (nonce != null) {
            h["x-nonce-id"] = nonce.first
            h["x-chronos-id"] = nonce.second
        }
        return h
    }

    private fun call(method: String, url: String, h: Map<String, String>,
                     body: String? = null, timeoutMs: Int = 30_000): Resp {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            h.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (method == "POST") {
                val bytes = (body ?: "").toByteArray(Charsets.UTF_8)
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(bytes.size)
                conn.outputStream.use { it.write(bytes) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val hs = HashMap<String, String>()
            conn.headerFields.forEach { (k, v) ->
                if (k != null && v.isNotEmpty()) hs[k.lowercase()] = v.last()
            }
            return Resp(code, hs, text)
        } finally {
            conn.disconnect()
        }
    }

    // ---------- auth ----------

    private fun checkpoint(acc: Account, targetPath: String, targetMethod: String): Pair<String, String> {
        val h = headers(acc, "application/json; charset=utf-8", targetPath, targetMethod)
        val r = call("POST", "$BFF/checkpoint/token", h, "{}", 25_000)
        if (r.code != 200 && r.code != 202) throw ApiError("رفض الخادم الطلب (${r.code})")
        val nonce = r.headers["x-nonce-id"]
        val chronos = r.headers["x-chronos-id"]
        if (nonce == null || chronos == null) throw ApiError("استجابة غير متوقعة من الخادم")
        return nonce to chronos
    }

    private class TokenResult(val tokens: JSONObject?, val smsSent: Boolean)

    private fun tokenRequest(acc: Account, nonce: Pair<String, String>,
                             otp: String? = null, refresh: String? = null): TokenResult {
        val h = headers(acc, "application/x-www-form-urlencoded; charset=utf-8")
        h["Accept"] = "*/*"
        h["x-nonce-id"] = nonce.first
        h["x-chronos-id"] = nonce.second
        val form = linkedMapOf("client_id" to CLIENT_ID)
        if (refresh != null) {
            form["grant_type"] = "refresh_token"
            form["refresh_token"] = refresh
        } else {
            form["grant_type"] = "password"
            form["username"] = acc.msisdn
            if (otp != null) form["otp"] = otp
        }
        val body = form.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        val r = call("POST", TOKEN_URL, h, body, 25_000)
        val o = r.json() as? JSONObject
        if (r.code == 200 && o != null) return TokenResult(o, false)
        if (otp == null && refresh == null && (r.code == 400 || r.code == 403)) return TokenResult(null, true)
        throw ApiError(if (otp != null) "رمز التحقق غير صحيح أو منتهي (${r.code})" else "رفض الخادم الطلب (${r.code})")
    }

    private fun applyTokens(acc: Account, t: JSONObject): Account {
        val now = System.currentTimeMillis() / 1000
        return acc.copy(
            accessToken = t.optString("access_token", acc.accessToken),
            refreshToken = t.optString("refresh_token", acc.refreshToken),
            accessExp = now + t.optLong("expires_in", 0),
            refreshExp = now + t.optLong("refresh_expires_in", 0),
        )
    }

    /** يرسل رمز OTP. يعيد الحساب إذا سُجّل الدخول مباشرة، أو null إذا أُرسل الرمز. */
    fun requestOtp(acc: Account): Account? {
        val cp = checkpoint(acc, TOKEN_PATH, "POST")
        val r = tokenRequest(acc, cp)
        val t = r.tokens
        return if (t != null && t.has("access_token")) applyTokens(acc, t) else null
    }

    fun verifyOtp(acc: Account, otp: String): Account {
        val cp = checkpoint(acc, TOKEN_PATH, "POST")
        val t = tokenRequest(acc, cp, otp = otp).tokens
        if (t == null || !t.has("access_token")) throw ApiError("لم يُرجع الخادم رمز الدخول")
        return applyTokens(acc, t)
    }

    /** يعيد نفس الكائن إذا كانت الجلسة صالحة، أو حسابًا محدَّثًا بعد التجديد. */
    fun ensureSession(acc: Account): Account {
        val now = System.currentTimeMillis() / 1000
        if (acc.accessToken.isNotEmpty() && now < acc.accessExp - 60) return acc
        if (acc.refreshToken.isNotEmpty() && now < acc.refreshExp - 60) {
            try {
                val cp = checkpoint(acc, TOKEN_PATH, "POST")
                val t = tokenRequest(acc, cp, refresh = acc.refreshToken).tokens
                if (t != null && t.has("access_token")) return applyTokens(acc, t)
            } catch (e: ApiError) {
                // يسقط إلى طلب تسجيل دخول جديد
            }
        }
        throw AuthRequired()
    }

    private fun checkAuth(r: Resp) {
        if (r.code == 401 || r.code == 403) throw AuthRequired()
    }

    // ---------- read ----------

    fun balance(acc: Account): String {
        val r = call("GET", "$BASE$ACTIVE_PACKAGES_PATH?msisdn=${acc.msisdn}", authHeaders(acc), timeoutMs = 20_000)
        checkAuth(r)
        val o = r.json() as? JSONObject
        if (!r.ok || o == null) throw ApiError("تعذّر جلب الرصيد")
        val b = o.opt("accountBalance")
        if (b == null || b == JSONObject.NULL || b.toString().isBlank()) throw ApiError("الرصيد غير متوفر")
        return b.toString().trim()
    }

    fun allocations(acc: Account): List<Allowance> {
        val r = call("GET", BASE + ALLOCATIONS_PATH, authHeaders(acc))
        checkAuth(r)
        if (!r.ok) throw ApiError("تعذّر جلب العروض النشطة")
        return extractItems(r.json()).flatMap { allowances(it) }
    }

    fun giftStatus(acc: Account): Gift {
        val r = call("GET", BASE + GIFT_STATUS_PATH, authHeaders(acc))
        checkAuth(r)
        val o = r.json() as? JSONObject
        if (!r.ok || o == null) return Gift(false, "غير معروفة")
        val last = parseInstant(o.optString("lastPlayedTime", ""))
        return when {
            last != null -> {
                val remaining = 24 * 3600 - (System.currentTimeMillis() - last) / 1000
                if (remaining > 0) Gift(false, "بعد " + duration(remaining)) else Gift(true, "متاحة الآن")
            }
            o.has("played") && !o.optBoolean("played", true) -> Gift(true, "متاحة الآن")
            o.optBoolean("played", false) -> Gift(false, "تم اللعب")
            else -> Gift(false, "غير معروفة")
        }
    }

    fun boxes(acc: Account): List<SnakeBox> {
        val r = call("GET", "$BASE$SNAKE_PATH?status=AVAILABLE", authHeaders(acc))
        checkAuth(r)
        val items = (r.json() as? JSONObject)?.optJSONArray("items")
        if (!r.ok || items == null) throw ApiError("تعذّر جلب الصناديق")
        val out = ArrayList<SnakeBox>()
        for (i in 0 until items.length()) {
            val it = items.optJSONObject(i) ?: continue
            val id = it.optString("uuid", "")
            val st = it.optString("status", "AVAILABLE").uppercase()
            if (id.isNotEmpty() && st == "AVAILABLE") out.add(SnakeBox(id, fmtDateTime(it.optString("expiryDate", ""))))
        }
        return out
    }

    // ---------- actions ----------

    fun playGift(acc: Account): Outcome {
        val cp = checkpoint(acc, GIFT_PLAY_PATH, "GET")
        val r = call("GET", BASE + GIFT_PLAY_PATH, authHeaders(acc, cp), timeoutMs = 35_000)
        val o = r.json() as? JSONObject
        val name = o?.optString("giftName", "").orEmpty()
        if (r.ok && name.isNotEmpty()) {
            val sb = StringBuilder("الهدية: $name")
            if (o!!.has("validityHour")) sb.append("\nالصلاحية: ${o.opt("validityHour")} ساعة")
            return Outcome(true, "تم استلام الهدية", sb.toString())
        }
        checkAuth(r)
        return Outcome(false, "لا توجد هدية", "لا توجد هدية متاحة الآن.")
    }

    fun redeemBox(acc: Account, uuid: String): Outcome {
        val r = call("POST", "$BASE$SNAKE_PATH/$uuid/redeem", authHeaders(acc), "", 35_000)
        val o = r.json() as? JSONObject
        if (r.ok && o != null) {
            val assigned = o.optJSONObject("assignedReward")
            val reward = assigned?.optJSONObject("reward")
            if (assigned != null && reward != null && assigned.optString("type").uppercase() == "DATA") {
                val amount = reward.opt("usage-value")?.toString() ?: "?"
                val unit = reward.optString("usage-unit", "")
                val validity = if (reward.has("validity")) reward.opt("validity").toString() else null
                val vu = when (reward.optString("validity-unit").uppercase()) {
                    "D" -> "يوم"; "H" -> "ساعة"; "M" -> "دقيقة"; else -> ""
                }
                val v = if (validity != null) "$validity $vu".trim() else "غير محددة"
                return Outcome(true, "تم فتح الصندوق", "المكافأة: $amount $unit".trim() + "\nالصلاحية: $v")
            }
            return Outcome(true, "تم فتح الصندوق", "لم تُعرف تفاصيل المكافأة.")
        }
        checkAuth(r)
        val msg = o?.optString("message", "").orEmpty().uppercase()
        return when {
            "EXPIRED" in msg -> Outcome(false, "تعذّر الفتح", "انتهت صلاحية هذا الصندوق.")
            "ALREADY" in msg || "REDEEMED" in msg -> Outcome(false, "تعذّر الفتح", "تم فتح هذا الصندوق من قبل.")
            else -> Outcome(false, "تعذّر الفتح", "تعذّر فتح الصندوق، حاول لاحقًا.")
        }
    }

    fun purchaseBundle(acc: Account, bundleCode: String): Outcome {
        val cp = checkpoint(acc, PURCHASE_PATH, "POST")
        val h = authHeaders(acc, cp, "application/json; charset=utf-8")
        val body = JSONObject().put("bundleCode", bundleCode).toString()
        return purchaseOutcome(call("POST", BFF + "/cvm/dynamic-bundle-purchase", h, body, 35_000))
    }

    fun purchaseYoutube(acc: Account): Outcome {
        val cp = checkpoint(acc, BYOP_PATH, "POST")
        val h = authHeaders(acc, cp, "application/json; charset=utf-8")
        val body = JSONObject()
            .put("validity", "Monthly")
            .put("limitedBundleDetails", JSONArray())
            .put("unlimitedBundleDetails", JSONArray().put("YT"))
            .toString()
        return purchaseOutcome(call("POST", BASE + BYOP_PATH, h, body, 35_000))
    }

    private fun purchaseOutcome(r: Resp): Outcome {
        val b = r.json() as? JSONObject
        val code = b?.optString("code", "").orEmpty().uppercase()
        val msgCode = b?.optString("message", "").orEmpty().uppercase()
        val msg = msgCode.lowercase()
        val codes = setOf("DYNAMIC_CREDIT_LIMIT_NOT_ENOUGH", "INSUFFICIENT_BALANCE", "INSUFFICIENT_CREDIT")
        val insufficient = code in codes || msgCode in codes ||
            listOf("not enough", "insufficient", "رصيدك غير كافي", "ليس لديك رصيد").any { it in msg }
        return when {
            insufficient -> Outcome(false, "الرصيد غير كافٍ", "رصيدك الحالي لا يكفي لتفعيل هذا العرض.")
            r.ok -> Outcome(true, "تم إرسال الطلب", "تم قبول طلب التفعيل. تحقق من رصيدك وعروضك النشطة.")
            r.code == 401 || r.code == 403 -> throw AuthRequired()
            else -> Outcome(false, "تعذّر التفعيل", "لم يكتمل الطلب، حاول لاحقًا.")
        }
    }

    // ---------- parsing helpers ----------

    private fun walk(v: Any?, out: MutableList<JSONObject>) {
        when (v) {
            is JSONObject -> {
                out.add(v)
                val keys = v.keys()
                while (keys.hasNext()) walk(v.opt(keys.next()), out)
            }
            is JSONArray -> for (i in 0 until v.length()) walk(v.opt(i), out)
        }
    }

    private fun norm(s: String) = s.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }

    private fun getCi(o: JSONObject, vararg names: String): Any? {
        val wanted = names.map { norm(it) }.toSet()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (norm(k) !in wanted) continue
            val v = o.opt(k)
            if (v == null || v == JSONObject.NULL) continue
            if (v is String && v.isEmpty()) continue
            if (v is JSONArray && v.length() == 0) continue
            if (v is JSONObject && v.length() == 0) continue
            return v
        }
        return null
    }

    private fun toNum(v: Any?): Double? = v?.toString()?.replace(",", ".")?.trim()?.toDoubleOrNull()

    private fun extractItems(body: Any?): List<Any?> {
        fun arr(a: JSONArray) = (0 until a.length()).map { a.opt(it) }
        fun listIn(o: JSONObject): JSONArray? {
            for (k in listOf("items", "allocations", "offers", "data", "results")) {
                o.optJSONArray(k)?.let { return it }
            }
            return null
        }
        return when (body) {
            is JSONArray -> arr(body)
            is JSONObject -> {
                val direct = listIn(body)
                if (direct != null) return arr(direct)
                when (val p = body.opt("payload")) {
                    is JSONArray -> arr(p)
                    is JSONObject -> listIn(p)?.let { arr(it) } ?: listOf(p)
                    else -> if (body.length() > 0) listOf(body) else emptyList()
                }
            }
            else -> emptyList()
        }
    }

    private fun allowances(item: Any?): List<Allowance> {
        val ds = ArrayList<JSONObject>().also { walk(item, it) }
        var code: String? = null
        var name: String? = null
        var expiry: String? = null
        for (o in ds) {
            if (code == null) code = getCi(o, "code", "bundleCode")?.toString()
            if (name == null) name = getCi(o, "name", "offerName", "bundleName")?.toString()
            if (expiry == null) expiry = getCi(o, "expire-at", "expiryDate", "expirationDate", "endDate")?.toString()
        }
        val rows = ArrayList<Allowance>()
        val dataTypes = setOf("data", "internet")
        for (o in ds) {
            val usageType = getCi(o, "usage-type", "usageType")?.toString()
            val c = getCi(o, "code")?.toString()
            val total = getCi(o, "usage-value", "usageValue")
            val unit = getCi(o, "usage-unit", "usageUnit")?.toString()
            val remaining = getCi(o, "available-amount", "availableAmount", "remaining", "remainingVolume")
            if (total == null || unit == null || remaining == null) continue
            if (usageType != null && usageType.lowercase() !in dataTypes) continue
            if (c != null && c.lowercase() !in dataTypes && usageType == null) continue
            rows.add(
                Allowance(
                    name = name ?: code ?: "عرض نشط",
                    code = code ?: c ?: "—",
                    total = toNum(total),
                    remaining = toNum(remaining),
                    unit = unit.uppercase(),
                    expiry = fmtDate(expiry),
                )
            )
        }
        return rows
    }

    private inline fun <T> attempt(f: () -> T): T? = try { f() } catch (e: Exception) { null }

    private fun parseInstant(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val t = s.trim()
        attempt { return OffsetDateTime.parse(t).toInstant().toEpochMilli() }
        attempt { return LocalDateTime.parse(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }
        return null
    }

    private fun fmtDate(s: String?): String {
        if (s.isNullOrBlank()) return "—"
        val t = s.trim()
        val out = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        attempt { return OffsetDateTime.parse(t).atZoneSameInstant(ZoneId.systemDefault()).format(out) }
        attempt { return LocalDateTime.parse(t).format(out) }
        attempt { return LocalDateTime.parse(t, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")).format(out) }
        attempt { return LocalDateTime.parse(t, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).format(out) }
        attempt { return LocalDate.parse(t).format(out) }
        return t
    }

    private fun fmtDateTime(s: String?): String {
        val ms = parseInstant(s) ?: return "غير معروف"
        return java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.US))
    }

    private fun duration(totalSeconds: Long): String {
        val s = maxOf(0L, totalSeconds)
        return "%02d:%02d:%02d".format(Locale.US, s / 3600, (s % 3600) / 60, s % 60)
    }
}
