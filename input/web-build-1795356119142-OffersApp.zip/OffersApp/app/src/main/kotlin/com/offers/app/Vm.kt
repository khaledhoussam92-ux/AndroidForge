package com.offers.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.io.IOException

sealed interface Screen {
    data object Home : Screen
    data class Add(val prefill: String = "") : Screen
    data class Detail(val msisdn: String) : Screen
}

data class Notice(val title: String, val body: String)
class Confirm(val title: String, val body: String, val onYes: () -> Unit)
data class DetailState(
    val loading: Boolean = false,
    val balance: String? = null,
    val allowances: List<Allowance>? = null,
    val gift: Gift? = null,
    val error: String? = null,
)

data class BundleItem(val title: String, val desc: String, val price: String, val code: String?)

val BUNDLES = listOf(
    BundleItem("1 جيغا", "صالحة 24 ساعة", "30 دج", "BTL_24H_SMART_30DZD_1Go"),
    BundleItem("2 جيغا", "صالحة 24 ساعة", "50 دج", "BTL_24H_SMART_50DZD_2Go"),
    BundleItem("يوتيوب", "شهري · يوتيوب فقط", "200 دج", null),
)

fun normalizeMsisdn(raw: String): String? {
    var v = raw.trim().replace("+", "").filter { !it.isWhitespace() }
    if (v.startsWith("0") && v.length == 10) v = "213" + v.substring(1)
    return if (Regex("213\\d{9}").matches(v)) v else null
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var accounts by mutableStateOf(store.load())
        private set
    var screen: Screen by mutableStateOf(Screen.Home)
    var busy by mutableStateOf(false)
        private set
    var notice by mutableStateOf<Notice?>(null)
    var confirm by mutableStateOf<Confirm?>(null)
    var boxes by mutableStateOf<List<SnakeBox>?>(null)
    var detail by mutableStateOf(DetailState())
        private set

    // مسار إضافة رقم
    var otpStep by mutableStateOf(false)
        private set
    private var pending: Account? = null

    // ---------- navigation ----------

    fun goHome() {
        screen = Screen.Home
        otpStep = false
        pending = null
    }

    fun startAdd(prefill: String = "") {
        otpStep = false
        pending = null
        screen = Screen.Add(prefill)
    }

    fun back() {
        if (screen is Screen.Add && otpStep) otpStep = false else goHome()
    }

    fun open(msisdn: String) {
        detail = DetailState()
        screen = Screen.Detail(msisdn)
        refreshDetail()
    }

    // ---------- accounts ----------

    @Synchronized
    private fun upsert(a: Account) {
        val l = accounts.toMutableList()
        val i = l.indexOfFirst { it.msisdn == a.msisdn }
        if (i >= 0) l[i] = a else l.add(a)
        accounts = l
        store.save(l)
    }

    fun rename(msisdn: String, label: String) {
        accounts.firstOrNull { it.msisdn == msisdn }?.let { upsert(it.copy(label = label.trim())) }
    }

    fun askDelete(acc: Account) {
        confirm = Confirm("حذف الرقم", "سيتم حذف ${acc.title} وجلسته من هذا الجهاز.") {
            val l = accounts.filter { it.msisdn != acc.msisdn }
            accounts = l
            store.save(l)
        }
    }

    private fun session(msisdn: String): Account {
        val acc = accounts.firstOrNull { it.msisdn == msisdn } ?: throw AuthRequired()
        val fresh = Api.ensureSession(acc)
        if (fresh !== acc) upsert(fresh)
        return fresh
    }

    private fun expired(msisdn: String) {
        notice = Notice("انتهت الجلسة", "سجّل الدخول من جديد برمز التحقق.")
        startAdd(msisdn.removePrefix("213").let { "0$it" })
    }

    private fun errText(e: Exception) = when (e) {
        is IOException -> "تحقق من اتصال الإنترنت وحاول مجددًا."
        else -> e.message ?: "حدث خطأ غير متوقع."
    }

    // ---------- login ----------

    fun sendOtp(rawNumber: String, label: String) {
        val m = normalizeMsisdn(rawNumber)
        if (m == null) {
            notice = Notice("رقم غير صالح", "أدخل الرقم بالشكل 05xxxxxxxx")
            return
        }
        val acc = (accounts.firstOrNull { it.msisdn == m } ?: Account(m, Api.newInstanceId()))
            .let { if (label.isNotBlank()) it.copy(label = label.trim()) else it }
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            try {
                val logged = Api.requestOtp(acc)
                if (logged != null) {
                    upsert(logged)
                    open(m)
                } else {
                    pending = acc
                    otpStep = true
                }
            } catch (e: Exception) {
                notice = Notice("تعذّر إرسال الرمز", errText(e))
            } finally {
                busy = false
            }
        }
    }

    fun verifyOtp(code: String) {
        val acc = pending ?: return
        val otp = code.trim()
        if (!Regex("\\d{4,8}").matches(otp)) {
            notice = Notice("رمز غير صالح", "أدخل الرمز المكوّن من 4 إلى 8 أرقام.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            try {
                val logged = Api.verifyOtp(acc, otp)
                upsert(logged)
                pending = null
                otpStep = false
                open(logged.msisdn)
            } catch (e: Exception) {
                notice = Notice("فشل التحقق", errText(e))
            } finally {
                busy = false
            }
        }
    }

    // ---------- detail ----------

    fun refreshDetail() {
        val m = (screen as? Screen.Detail)?.msisdn ?: return
        viewModelScope.launch(Dispatchers.IO) {
            detail = detail.copy(loading = true, error = null)
            try {
                val acc = session(m)
                coroutineScope {
                    val b = async { runCatching { Api.balance(acc) } }
                    val a = async { runCatching { Api.allocations(acc) } }
                    val g = async { runCatching { Api.giftStatus(acc) } }
                    val rb = b.await()
                    val ra = a.await()
                    val rg = g.await()
                    val failures = listOf(rb.exceptionOrNull(), ra.exceptionOrNull(), rg.exceptionOrNull())
                    if (failures.any { it is AuthRequired }) throw AuthRequired()
                    detail = DetailState(
                        loading = false,
                        balance = rb.getOrNull() ?: detail.balance,
                        allowances = ra.getOrNull() ?: detail.allowances,
                        gift = rg.getOrNull() ?: detail.gift,
                        error = if (failures.all { it != null }) "تعذّر تحديث البيانات" else null,
                    )
                }
            } catch (e: AuthRequired) {
                detail = detail.copy(loading = false)
                expired(m)
            } catch (e: Exception) {
                detail = detail.copy(loading = false, error = errText(e))
            }
        }
    }

    private fun act(block: (Account) -> Unit) {
        val m = (screen as? Screen.Detail)?.msisdn ?: return
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            try {
                block(session(m))
            } catch (e: AuthRequired) {
                expired(m)
            } catch (e: Exception) {
                notice = Notice("تعذّر تنفيذ الطلب", errText(e))
            } finally {
                busy = false
            }
        }
    }

    private fun report(o: Outcome) {
        notice = Notice(o.title, o.message)
        refreshDetail()
    }

    fun askBuy(item: BundleItem) {
        confirm = Confirm("تأكيد التفعيل", "${item.title} · ${item.desc} · ${item.price}") {
            act { acc ->
                report(if (item.code != null) Api.purchaseBundle(acc, item.code) else Api.purchaseYoutube(acc))
            }
        }
    }

    fun askGift() {
        confirm = Confirm("الهدية اليومية", "هل تريد تجربة الحظ والحصول على هدية؟") {
            act { acc -> report(Api.playGift(acc)) }
        }
    }

    fun loadBoxes() {
        act { acc ->
            val list = Api.boxes(acc)
            if (list.isEmpty()) {
                notice = Notice("الصناديق", "لا توجد صناديق متاحة حاليًا.")
            } else {
                boxes = list
            }
        }
    }

    fun askRedeem(box: SnakeBox) {
        boxes = null
        confirm = Confirm("فتح الصندوق", "هل تريد فتح هذا الصندوق؟") {
            act { acc -> report(Api.redeemBox(acc, box.uuid)) }
        }
    }
}
