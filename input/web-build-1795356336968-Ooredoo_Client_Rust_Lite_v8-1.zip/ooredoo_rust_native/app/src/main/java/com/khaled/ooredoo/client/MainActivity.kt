package com.khaled.ooredoo.client

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("ooredoo_local", Context.MODE_PRIVATE) }
    private val accounts = mutableListOf<JSONObject>()
    private var selected: JSONObject? = null
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private val red = 0xFFD71920.toInt()
    private val ink = 0xFF202124.toInt()
    private val muted = 0xFF687078.toInt()
    private val paper = 0xFFF5F6F8.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = -1
        window.navigationBarColor = -1
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        loadAccounts(); showHome()
    }

    private fun loadAccounts() {
        accounts.clear()
        try { val arr = JSONArray(prefs.getString("accounts", "[]")); for (i in 0 until arr.length()) accounts.add(arr.getJSONObject(i)) } catch (_: Exception) {}
    }
    private fun saveAccounts() { val arr = JSONArray(); accounts.forEach { arr.put(it) }; prefs.edit().putString("accounts", arr.toString()).apply() }
    private fun call(action: String, account: JSONObject?, extra: JSONObject = JSONObject(), done: (JSONObject) -> Unit) {
        val payload = JSONObject(); if (account != null) payload.put("account", account); val keys=extra.keys(); while(keys.hasNext()){val k=keys.next();payload.put(k,extra.get(k))}
        worker.execute {
            val result = try { JSONObject(NativeBridge.nativeCall(action, payload.toString())) } catch (e: Exception) { JSONObject().put("ok",false).put("error",e.message ?: "Native error") }
            runOnUiThread { done(result) }
        }
    }
    private fun shell(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(paper) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(18),dp(20),dp(14)); setBackgroundColor(-1) }
        header.addView(TextView(this).apply { text=title; textSize=24f; setTextColor(ink); typeface=Typeface.DEFAULT_BOLD })
        if (subtitle != null) header.addView(TextView(this).apply { text=subtitle; textSize=13f; setTextColor(muted); setPadding(0,dp(4),0,0) })
        root.addView(header)
        val scroll=ScrollView(this); body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(28)) }; scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun showHome() {
        selected=null; shell("Ooredoo Client", "إدارة أرقامك وخدماتك في مكان واحد")
        if (accounts.isEmpty()) {
            val empty=card(); empty.gravity=Gravity.CENTER; empty.setPadding(dp(22),dp(34),dp(22),dp(34))
            empty.addView(TextView(this).apply { text="لا توجد أرقام محفوظة"; textSize=18f; typeface=Typeface.DEFAULT_BOLD; setTextColor(ink); gravity=Gravity.CENTER })
            empty.addView(TextView(this).apply { text="أضف رقم Ooredoo للبدء ومتابعة عروضك"; textSize=14f; setTextColor(muted); gravity=Gravity.CENTER; setPadding(0,dp(8),0,dp(8)) })
            body.addView(empty)
        } else accounts.forEach { account ->
            val row=card(); row.orientation=LinearLayout.HORIZONTAL; row.gravity=Gravity.CENTER_VERTICAL
            val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            info.addView(TextView(this).apply { text=prettyPhone(account.optString("msisdn")); textSize=18f; typeface=Typeface.DEFAULT_BOLD; setTextColor(ink) })
            info.addView(TextView(this).apply { text=if(account.optString("access_token").isNotEmpty()||account.optString("refresh_token").isNotEmpty()) "حساب محفوظ" else "يتطلب تسجيل الدخول"; textSize=12f; setTextColor(muted); setPadding(0,dp(4),0,0) })
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply { text="›"; textSize=28f; setTextColor(red) })
            row.setOnClickListener { openAccount(account) }
            row.setOnLongClickListener { confirmDelete(account); true }
            body.addView(row)
        }
        val add=button("＋  إضافة رقم جديد", red); add.setOnClickListener { addNumberDialog() }
        body.addView(add,LinearLayout.LayoutParams(-1,dp(54)).apply { topMargin=dp(12) })
        body.addView(TextView(this).apply { text="اضغط مطولاً على رقم لحذفه"; textSize=12f; setTextColor(muted); gravity=Gravity.CENTER; setPadding(0,dp(12),0,0) })
    }
    private fun addNumberDialog() {
        val input=EditText(this).apply { hint="05xxxxxxxx"; inputType=3; textSize=17f }
        AlertDialog.Builder(this).setTitle("إضافة رقم Ooredoo").setMessage("أدخل رقم الهاتف لإرسال رمز التحقق").setView(input)
            .setNegativeButton("إلغاء",null).setPositiveButton("إرسال الرمز",null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val phone=input.text.toString().trim(); if(phone.isEmpty()){input.error="أدخل رقم الهاتف";return@setOnClickListener}
                    d.dismiss(); loading("جارٍ طلب رمز OTP...")
                    call("request_otp",null,JSONObject().put("phone",phone)) { res ->
                        hideLoading()
                        if(!res.optBoolean("ok")){error(res.optString("error"));return@call}
                        val acc=res.optJSONObject("data")?.optJSONObject("account") ?: run {error("استجابة غير مكتملة");return@call}
                        otpDialog(acc)
                    }
                } }; d.show() }
    }
    private fun otpDialog(account: JSONObject) {
        val input=EditText(this).apply { hint="رمز OTP"; inputType=2; textSize=20f; gravity=Gravity.CENTER }
        AlertDialog.Builder(this).setTitle("تأكيد الرقم").setMessage("أدخل رمز التحقق الذي وصلك عبر SMS").setView(input)
            .setNegativeButton("إلغاء",null).setPositiveButton("تأكيد",null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val otp=input.text.toString().trim(); if(otp.length !in 4..8){input.error="رمز غير صالح";return@setOnClickListener}
                    d.dismiss(); loading("جارٍ التحقق...")
                    call("verify_otp",account,JSONObject().put("otp",otp)) { res ->
                        hideLoading(); if(!res.optBoolean("ok")){error(res.optString("error"));return@call}
                        val saved=res.optJSONObject("data")?.optJSONObject("account") ?: account
                        upsert(saved); saveAccounts(); showHome(); toast("تم حفظ الرقم بنجاح")
                    }
                } }; d.show() }
    }
    private fun upsert(a:JSONObject){ val n=a.optString("msisdn"); val i=accounts.indexOfFirst{it.optString("msisdn")==n}; if(i>=0)accounts[i]=a else accounts.add(a) }
    private fun confirmDelete(a:JSONObject){ AlertDialog.Builder(this).setTitle("حذف الرقم").setMessage("هل تريد حذف ${prettyPhone(a.optString("msisdn"))} والجلسة المحفوظة؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف"){_,_->accounts.removeAll{it.optString("msisdn")==a.optString("msisdn")};saveAccounts();showHome()}.show() }

    private fun openAccount(a:JSONObject) {
        selected=a; shell(prettyPhone(a.optString("msisdn")),"لوحة الحساب · كل الخدمات في صفحة واحدة")
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val refresh=button("تحديث",red); refresh.setOnClickListener { loadDashboard(a) }
        val back=button("الأرقام",0xFF50565C.toInt()); back.setOnClickListener { showHome() }
        actions.addView(back,LinearLayout.LayoutParams(0,dp(46),1f).apply{rightMargin=dp(6)})
        actions.addView(refresh,LinearLayout.LayoutParams(0,dp(46),1f).apply{leftMargin=dp(6)})
        body.addView(actions); loadDashboard(a)
    }
    private fun loadDashboard(a:JSONObject) {
        loading("جارٍ تحميل الرصيد والعروض...")
        call("dashboard",a) { res -> hideLoading(); if(!res.optBoolean("ok")){error(res.optString("error"));return@call}
            val data=res.optJSONObject("data") ?: JSONObject(); val updated=data.optJSONObject("account") ?: a; upsert(updated);saveAccounts()
            body.removeViews(1, (body.childCount-1).coerceAtLeast(0))
            section("الرصيد")
            val bal=data.opt("balance"); val balanceCard=card()
            balanceCard.addView(TextView(this).apply { text=if(bal==null||bal==JSONObject.NULL) "غير متاح" else "$bal دج"; textSize=27f; typeface=Typeface.DEFAULT_BOLD; setTextColor(red) })
            balanceCard.addView(TextView(this).apply { text="الرصيد الحالي"; textSize=12f; setTextColor(muted) }); body.addView(balanceCard)
            section("العروض واستهلاك الإنترنت")
            val offers=data.optJSONArray("offers") ?: JSONArray()
            if(offers.length()==0) body.addView(note("لا توجد تفاصيل عروض متاحة حالياً أو أن صيغة الاستجابة غير معروفة."))
            for(i in 0 until offers.length()) { val o=offers.optJSONObject(i)?:continue; val c=card()
                c.addView(TextView(this).apply{text=o.optString("name","عرض الإنترنت");textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ink)})
                val rem=o.opt("remaining"); val total=o.opt("total"); val unit=o.optString("unit")
                c.addView(TextView(this).apply{text="المتبقي: ${value(rem)} $unit   •   الإجمالي: ${value(total)} $unit";textSize=13f;setTextColor(muted);setPadding(0,dp(7),0,0)})
                c.addView(TextView(this).apply{text="المستهلك: ${value(o.opt("consumed"))} $unit   •   الانتهاء: ${o.optString("expiry","غير محدد")}";textSize=12f;setTextColor(muted);setPadding(0,dp(5),0,0)})
                body.addView(c)
            }
            section("الخدمات")
            val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val r1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; val r2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            addGridButton(r1,"شراء 1GB", "purchase_bundle",a,"BTL_24H_SMART_30DZD_1Go")
            addGridButton(r1,"شراء 2GB", "purchase_bundle",a,"BTL_24H_SMART_50DZD_2Go")
            addGridButton(r2,"باقة YouTube", "purchase_youtube",a,null)
            addGridButton(r2,"الهدية اليومية", "play_gift",a,null)
            grid.addView(r1);grid.addView(r2);body.addView(grid)
            val snake=button("Power Snake – الصناديق المتاحة",0xFF353B43.toInt()); snake.setOnClickListener{runAction("snake_list",a,null)};body.addView(snake,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(8)})
            val gift=button("حالة الهدية اليومية",0xFF353B43.toInt());gift.setOnClickListener{runAction("gift_status",a,null)};body.addView(gift,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(8)})
        }
    }
    private fun addGridButton(row:LinearLayout,label:String,action:String,a:JSONObject,code:String?){ val b=button(label,red);b.setOnClickListener{ if(action=="purchase_bundle") confirmAction("تأكيد الشراء","هل تريد شراء $label؟") {runAction(action,a,code)} else runAction(action,a,null) };row.addView(b,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(3),dp(4),dp(3),dp(4))}) }
    private fun runAction(action:String,a:JSONObject,code:String?){ loading("جارٍ تنفيذ الطلب..."); val ex=JSONObject();if(code!=null){if(action=="snake_redeem")ex.put("uuid",code) else ex.put("code",code)};call(action,a,ex){r->hideLoading();if(!r.optBoolean("ok")){error(r.optString("error"));return@call};val d=r.optJSONObject("data")?:JSONObject();d.optJSONObject("account")?.let{upsert(it);saveAccounts()};val items=d.optJSONArray("items")
            if(action=="snake_list" && items!=null && items.length()>0){
                val labels=ArrayList<String>(); val ids=ArrayList<String>()
                for(i in 0 until items.length()){val box=items.optJSONObject(i)?:continue;val id=box.optString("uuid");if(id.isNotBlank()){ids.add(id);labels.add("صندوق ${i+1} · ${box.optString("expiry","غير معروف")}")}}
                if(ids.isNotEmpty()){AlertDialog.Builder(this).setTitle("صناديق Power Snake").setItems(labels.toTypedArray()){_,which->confirmAction("فتح الصندوق","هل تريد فتح هذا الصندوق؟"){runAction("snake_redeem",a,ids[which])}}.setNegativeButton("إغلاق",null).show();return@call}
            }
            val result=d.opt("result")?:d.opt("items")?:d;AlertDialog.Builder(this).setTitle("نتيجة الطلب").setMessage(result.toString()).setPositiveButton("حسناً",null).show()} }
    private fun confirmAction(title:String,msg:String,yes:()->Unit){AlertDialog.Builder(this).setTitle(title).setMessage(msg).setNegativeButton("إلغاء",null).setPositiveButton("متابعة"){_,_->yes()}.show()}
    private var loadingDialog:AlertDialog?=null
    private fun loading(s:String){loadingDialog?.dismiss();loadingDialog=AlertDialog.Builder(this).setMessage(s).setCancelable(false).create();loadingDialog?.show()}
    private fun hideLoading(){loadingDialog?.dismiss();loadingDialog=null}
    private fun error(s:String){AlertDialog.Builder(this).setTitle("تعذر إكمال العملية").setMessage(s).setPositiveButton("حسناً",null).show()}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));setBackgroundColor(-1);elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)}}
    private fun button(label:String,color:Int)=Button(this).apply{text=label;textSize=14f;isAllCaps=false;setTextColor(-1);setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));minHeight=dp(44);stateListAnimator=null}
    private fun section(s:String){body.addView(TextView(this).apply{text=s;textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(ink);setPadding(dp(2),dp(16),0,dp(9))})}
    private fun note(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(muted);setPadding(dp(12),dp(12),dp(12),dp(12))}
    private fun value(v:Any?):String=if(v==null||v==JSONObject.NULL) "—" else v.toString()
    private fun prettyPhone(s:String)=if(s.startsWith("213")&&s.length==12) "0${s.substring(3)}" else s
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){worker.shutdown();super.onDestroy()}
}
