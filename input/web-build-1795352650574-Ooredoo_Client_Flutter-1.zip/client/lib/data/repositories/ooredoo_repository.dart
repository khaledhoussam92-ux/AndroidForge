import '../../core/network/ooredoo_api.dart';
import '../../core/utils/helpers.dart';
import '../models/models.dart';
import '../services/session_store.dart';

/// Session logic: login_or_reuse + refresh, and an authenticated-call wrapper.
class OoredooRepository {
  OoredooRepository(this.api, this.store);
  final OoredooApi api;
  final SessionStore store;
  Future<String?>? _refreshing; // single-flight refresh (refresh tokens may rotate)

  Creds _creds(String m, Account a, [String? token]) =>
      Creds(m, a.instanceId, OoredooApi.platformSignature(a.instanceId), token);

  Future<void> _storeTokens(String m, Account a, Map<String, dynamic> t) async {
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    a.accessToken = (t['access_token'] as String?) ?? a.accessToken;
    a.refreshToken = (t['refresh_token'] as String?) ?? a.refreshToken;
    a.accessExp = now + toInt(t['expires_in']);
    a.refreshExp = now + toInt(t['refresh_expires_in']);
    await store.save(m, a);
  }

  /// Steps 4-11: reuse -> refresh -> request OTP.
  Future<LoginStep> start(String msisdn) async {
    final a = await store.getOrCreate(msisdn);
    if (a.hasValidAccess) return LoginStep.ready;
    if (a.hasValidRefresh && await _tryRefresh(msisdn) != null) return LoginStep.ready;
    return requestOtp(msisdn);
  }

  Future<LoginStep> requestOtp(String msisdn) async {
    final a = await store.getOrCreate(msisdn);
    final c = _creds(msisdn, a);
    final (nonce, chronos) = await api.checkpoint(c);
    final r = await api.tokenRequest(c, nonce, chronos);
    if (r.tokens != null) {
      if (r.tokens!['access_token'] == null) {
        throw ApiException(ApiErrorKind.server, 'Server did not return an access token.');
      }
      await _storeTokens(msisdn, a, r.tokens!);
      return LoginStep.ready;
    }
    return LoginStep.otp;
  }

  /// Steps 12-14: fresh checkpoint, then verify OTP.
  Future<void> verifyOtp(String msisdn, String otp) async {
    final a = await store.getOrCreate(msisdn);
    final c = _creds(msisdn, a);
    final (nonce, chronos) = await api.checkpoint(c);
    final r = await api.tokenRequest(c, nonce, chronos, otp: otp);
    final t = r.tokens;
    if (t == null || t['access_token'] == null) {
      throw ApiException(ApiErrorKind.server, 'Server did not return an access token.');
    }
    await _storeTokens(msisdn, a, t);
  }

  Future<String?> _tryRefresh(String msisdn) =>
      _refreshing ??= _doRefresh(msisdn).whenComplete(() => _refreshing = null);

  Future<String?> _doRefresh(String msisdn) async {
    final a = await store.get(msisdn);
    if (a == null || !a.hasValidRefresh) return null;
    try {
      final c = _creds(msisdn, a);
      final (nonce, chronos) = await api.checkpoint(c);
      final r = await api.tokenRequest(c, nonce, chronos, refreshToken: a.refreshToken);
      final t = r.tokens;
      if (t != null && t['access_token'] != null) {
        await _storeTokens(msisdn, a, t);
        return t['access_token'] as String;
      }
    } catch (_) {}
    return null;
  }

  /// Runs [call] with a valid token; refreshes once on 401/403.
  Future<T> authed<T>(String msisdn, Future<T> Function(Creds c) call) async {
    final a = await store.get(msisdn);
    ApiException expired() => ApiException(ApiErrorKind.sessionExpired, 'Session expired');
    if (a == null) throw expired();
    final token = a.hasValidAccess ? a.accessToken : await _tryRefresh(msisdn);
    if (token == null) throw expired();
    try {
      return await call(_creds(msisdn, a, token));
    } on ApiException catch (e) {
      if (e.kind != ApiErrorKind.sessionExpired) rethrow;
      final t = await _tryRefresh(msisdn);
      final a2 = await store.get(msisdn);
      if (t == null || a2 == null) throw expired();
      return call(_creds(msisdn, a2, t));
    }
  }

  Future<void> invalidate(String msisdn) => store.clearTokens(msisdn);
}
