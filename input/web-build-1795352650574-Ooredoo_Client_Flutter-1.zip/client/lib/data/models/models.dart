import '../../core/utils/helpers.dart';

enum ApiErrorKind { network, sessionExpired, server }

class ApiException implements Exception {
  ApiException(this.kind, this.message, {this.statusCode});
  final ApiErrorKind kind;
  final String message;
  final int? statusCode;
  @override
  String toString() => message;
}

class Creds {
  const Creds(this.msisdn, this.iid, this.psig, [this.token]);
  final String msisdn;
  final String iid;
  final String psig;
  final String? token;
}

class Account {
  Account({
    required this.instanceId,
    this.accessToken,
    this.refreshToken,
    this.accessExp = 0,
    this.refreshExp = 0,
  });
  String instanceId;
  String? accessToken;
  String? refreshToken;
  int accessExp;
  int refreshExp;

  static int get _now => DateTime.now().millisecondsSinceEpoch ~/ 1000;
  bool get hasValidAccess => accessToken != null && _now < accessExp - 60;
  bool get hasValidRefresh => refreshToken != null && _now < refreshExp - 60;

  Map<String, dynamic> toJson() => {
        'instance_id': instanceId,
        'access_token': accessToken,
        'refresh_token': refreshToken,
        'access_expires_at': accessExp,
        'refresh_expires_at': refreshExp,
      };

  factory Account.fromJson(Map<String, dynamic> j) => Account(
        instanceId: j['instance_id'] as String,
        accessToken: j['access_token'] as String?,
        refreshToken: j['refresh_token'] as String?,
        accessExp: toInt(j['access_expires_at']),
        refreshExp: toInt(j['refresh_expires_at']),
      );
}

class TokenResult {
  const TokenResult({this.tokens, this.smsSent = false});
  final Map<String, dynamic>? tokens;
  final bool smsSent;
}

enum LoginStep { ready, otp }

class OfferCard {
  const OfferCard({
    required this.name,
    this.code,
    required this.unit,
    required this.totalText,
    required this.remainingText,
    this.consumedText,
    this.totalNum,
    this.remainingNum,
    this.consumedNum,
    this.expiry,
  });
  final String name;
  final String? code;
  final String unit;
  final String totalText;
  final String remainingText;
  final String? consumedText;
  final double? totalNum;
  final double? remainingNum;
  final double? consumedNum;
  final String? expiry;

  /// Fraction consumed (0..1) or null when unknown.
  double? get usedFraction {
    if (totalNum == null || totalNum == 0 || consumedNum == null) return null;
    return (consumedNum! / totalNum!).clamp(0.0, 1.0);
  }
}

enum GiftKind { available, cooldown, playedUnknown, unknown }

class GiftStatus {
  const GiftStatus(this.kind, [this.availableAt]);
  final GiftKind kind;
  final DateTime? availableAt;
}

class GiftResult {
  const GiftResult(this.name, this.validityHour, this.playedTime);
  final String name;
  final dynamic validityHour;
  final String? playedTime;
}

class SnakeBox {
  const SnakeBox(this.uuid, this.expiry, this.status);
  final String uuid;
  final DateTime? expiry;
  final String status;
}

enum RedeemKind { success, unrecognized, expired, already, failed }

class RedeemOutcome {
  const RedeemOutcome(this.kind, {this.amount, this.unit, this.validity, this.validityUnit});
  final RedeemKind kind;
  final String? amount;
  final String? unit;
  final String? validity;
  final String? validityUnit; // D / H / M
}

enum PurchaseOutcome { accepted, insufficient, failed }
