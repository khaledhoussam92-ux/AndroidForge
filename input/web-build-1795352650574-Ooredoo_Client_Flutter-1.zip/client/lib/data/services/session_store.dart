import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../core/network/ooredoo_api.dart';
import '../models/models.dart';

/// Accounts/tokens live only in Android Keystore-backed secure storage.
class SessionStore {
  SessionStore(this._s);
  final FlutterSecureStorage _s;
  static const _kAccounts = 'accounts';
  static const _kCurrent = 'current_msisdn';

  Future<Map<String, dynamic>> _all() async {
    try {
      final raw = await _s.read(key: _kAccounts);
      if (raw == null) return {};
      final v = jsonDecode(raw);
      return v is Map<String, dynamic> ? v : {};
    } catch (_) {
      return {};
    }
  }

  Future<void> _write(Map<String, dynamic> m) => _s.write(key: _kAccounts, value: jsonEncode(m));

  Future<Account?> get(String msisdn) async {
    final a = (await _all())[msisdn];
    return a is Map<String, dynamic> && a['instance_id'] != null ? Account.fromJson(a) : null;
  }

  Future<Account> getOrCreate(String msisdn) async {
    final existing = await get(msisdn);
    if (existing != null) return existing;
    final a = Account(instanceId: OoredooApi.newInstanceId());
    await save(msisdn, a);
    return a;
  }

  Future<void> save(String msisdn, Account a) async {
    final m = await _all();
    m[msisdn] = a.toJson();
    await _write(m);
  }

  Future<void> delete(String msisdn) async {
    final m = await _all();
    m.remove(msisdn);
    await _write(m);
  }

  /// Logout: drop tokens but keep the Instance ID for this number.
  Future<void> clearTokens(String msisdn) async {
    final a = await get(msisdn);
    if (a == null) return;
    a
      ..accessToken = null
      ..refreshToken = null
      ..accessExp = 0
      ..refreshExp = 0;
    await save(msisdn, a);
  }

  Future<String?> currentMsisdn() => _s.read(key: _kCurrent);
  Future<void> setCurrent(String? m) =>
      m == null ? _s.delete(key: _kCurrent) : _s.write(key: _kCurrent, value: m);
}
