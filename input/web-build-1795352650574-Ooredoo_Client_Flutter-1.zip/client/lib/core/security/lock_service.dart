import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// App lock. Only a salted SHA-256 digest is embedded; the password itself
/// never appears in the code, UI, logs or SharedPreferences.
/// Note: a client-side lock is a deterrent only, not strong protection.
class LockService {
  LockService(this._storage);
  final FlutterSecureStorage _storage;

  static const _salt = 'ooredoo.client.lock.v1:';
  static const _digest = 'be4469da1fa2c6482921ad5b90e1f448274618be68e07b24b7d24dd7b673ebc9';
  static const _flag = 'app_unlocked';

  Future<bool> isUnlocked() async => (await _storage.read(key: _flag)) == '1';

  Future<bool> verifyAndStore(String input) async {
    final h = sha256.convert(utf8.encode('$_salt$input')).toString();
    if (!_constEq(h, _digest)) return false;
    await _storage.write(key: _flag, value: '1');
    return true;
  }

  bool _constEq(String a, String b) {
    if (a.length != b.length) return false;
    var r = 0;
    for (var i = 0; i < a.length; i++) {
      r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return r == 0;
  }
}
