class Api {
  static const base = 'https://apis.ooredoo.dz';
  static const bff = '$base/api/ooredoo-bff';
  static const tokenPath = '/api/auth/realms/myooredoo/protocol/openid-connect/token';
  static const tokenUrl = '$base$tokenPath';
  static const snakePath = '/api/ooredoo-bff/gamification/power-snake';
  static const giftPlayPath = '/api/ooredoo-bff/gamification/play';
  static const giftStatusPath = '/api/ooredoo-bff/gamification/status';
  static const purchasePath = '/api/ooredoo-bff/cvm/dynamic-bundle-purchase';
  static const byopPurchasePath = '/api/ooredoo-bff/bundle/purchase/byop';
  static const activePackagesPath = '/api/ooredoo-bff/bundle/getActivePackages';
  static const cvmAllocationsPath = '/api/ooredoo-bff/cvm/getCvmAllocations';
  static const balanceRefreshSeconds = 60;

  static const clientId = 'myooredoo-app';
  static const xSignature = 'ee41e0dcab1ac6840c6d83cba9dcbe1d4b24074fdab16718ae12f48950080114';
  static const xVersion = '1.5.21';
  static const userAgent = 'Dart/3.11 (dart:io)';
}

class Pkg {
  const Pkg({
    required this.id,
    required this.title,
    required this.validityKey,
    required this.price,
    this.bundleCode,
    this.youtube = false,
  });
  final String id;
  final String title;
  final String validityKey; // l10n key
  final int price;
  final String? bundleCode;
  final bool youtube;
}

const packages = <Pkg>[
  Pkg(id: '1gb', title: '1 GB', validityKey: 'h24', price: 30, bundleCode: 'BTL_24H_SMART_30DZD_1Go'),
  Pkg(id: '2gb', title: '2 GB', validityKey: 'h24', price: 50, bundleCode: 'BTL_24H_SMART_50DZD_2Go'),
  Pkg(id: 'yt', title: 'YouTube', validityKey: 'monthly', price: 200, youtube: true),
];
