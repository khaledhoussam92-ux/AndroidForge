import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/repositories/ooredoo_repository.dart';
import '../data/services/session_store.dart';
import 'network/ooredoo_api.dart';
import 'security/lock_service.dart';

final prefsProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError());

final _secureProvider = Provider<FlutterSecureStorage>(
    (ref) => const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true)));

final apiProvider = Provider<OoredooApi>((ref) => OoredooApi());
final storeProvider = Provider<SessionStore>((ref) => SessionStore(ref.watch(_secureProvider)));
final lockServiceProvider = Provider<LockService>((ref) => LockService(ref.watch(_secureProvider)));
final repoProvider = Provider<OoredooRepository>(
    (ref) => OoredooRepository(ref.watch(apiProvider), ref.watch(storeProvider)));
