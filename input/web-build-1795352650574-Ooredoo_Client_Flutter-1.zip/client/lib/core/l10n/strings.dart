import 'package:flutter/material.dart';

class S {
  S(this.locale);
  final Locale locale;
  static const delegate = _SDelegate();
  static S of(BuildContext c) => Localizations.of<S>(c, S)!;

  String t(String k) => _d[locale.languageCode]?[k] ?? _d['en']![k] ?? k;
  String f(String k, Map<String, String> args) {
    var s = t(k);
    args.forEach((key, v) => s = s.replaceAll('{$key}', v));
    return s;
  }
}

class _SDelegate extends LocalizationsDelegate<S> {
  const _SDelegate();
  @override
  bool isSupported(Locale l) => const ['ar', 'en', 'fr'].contains(l.languageCode);
  @override
  Future<S> load(Locale l) async => S(l);
  @override
  bool shouldReload(covariant LocalizationsDelegate<S> old) => false;
}

const Map<String, Map<String, String>> _d = {
  'en': {
    'lock_title': 'App protection', 'lock_hint': 'Enter the password to continue', 'password': 'Password',
    'unlock': 'Unlock', 'wrong_password': 'Incorrect password',
    'sign_in': 'Sign in', 'phone': 'Phone number', 'invalid_phone': 'Enter number as 05xxxxxxxx or 2135xxxxxxxx',
    'send_otp': 'Send code', 'otp': 'Verification code', 'invalid_otp': 'Invalid code format (4-8 digits)',
    'verify': 'Verify', 'resend': 'Resend code', 'resend_in': 'Resend in {s}s', 'otp_sent': 'Enter the code sent by SMS',
    'login_rejected': 'The server rejected the request. Check the code and try again.', 'change_number': 'Change number',
    'dashboard': 'Home', 'account': 'Account', 'logged_in': 'Signed in', 'server_ok': 'Server reachable',
    'server_down': 'Server unreachable', 'server_unknown': 'Checking…', 'last_update': 'Last update', 'refresh': 'Refresh',
    'balance': 'Balance', 'balance_unavailable': 'Balance unavailable', 'auto_refresh': 'Auto-refresh every 60s',
    'internet': 'Internet usage', 'offers_count': 'Active offers', 'total': 'Total', 'consumed': 'Consumed',
    'remaining': 'Remaining', 'expires': 'Expires', 'no_offers': 'No active data allowances found.',
    'quick_actions': 'Quick actions', 'power_snake': 'Power Snake', 'buy_1gb': 'Buy 1GB', 'buy_2gb': 'Buy 2GB',
    'youtube': 'YouTube bundle', 'daily_gift': 'Daily gift', 'active_offers': 'Active offers', 'packages': 'Packages',
    'settings': 'Settings', 'confirm': 'Confirm', 'cancel': 'Cancel', 'ok': 'OK', 'buy': 'Buy', 'play': 'Play',
    'open_box': 'Open box', 'confirm_buy': 'Confirm purchase', 'confirm_open': 'Open this box?',
    'confirm_play': 'Play for a gift?', 'h24': '24 hours', 'monthly': 'Monthly', 'price': 'Price', 'code': 'Code',
    'unlimited_yt': 'Unlimited bundle: YT', 'validity': 'Validity',
    'purchase_accepted': 'The server accepted the purchase request. Check your balance and bundle status.',
    'insufficient': 'Your balance is insufficient.', 'purchase_failed': 'Purchase could not be completed. Please try again later.',
    'session_expired': 'Session expired. Please sign in again.', 'network_error': 'Connection error. Check your internet.',
    'failed': 'Something went wrong. Please try again.', 'no_boxes': 'You have no boxes available.',
    'box': 'Box', 'box_expires': 'Expires', 'status': 'Status', 'available': 'Available',
    'box_opened': 'Box opened successfully!', 'reward': 'Reward', 'box_expired': 'This box has expired.',
    'box_already': 'This box has already been opened.', 'box_unrecognized': 'Box opened, but the reward details were not recognized.',
    'box_failed': 'Could not open this box. Please try again later.', 'select_box': 'Select a box first',
    'gift_now': 'Available now', 'gift_in': 'Available in', 'gift_played': 'Played (time unavailable)',
    'gift_unknown': 'Status unknown', 'gift_unavailable': 'Gift status unavailable', 'gift_received': 'Gift received successfully',
    'gift_name': 'Gift', 'received_at': 'Received at', 'hours_n': '{n} hour(s)', 'no_gift': 'No gift is available right now.',
    'u_d': 'day(s)', 'u_h': 'hour(s)', 'u_m': 'minute(s)', 'not_specified': 'Not specified',
    'logout': 'Sign out', 'delete_account': 'Delete saved account', 'logout_q': 'Sign out of this account?',
    'delete_q': 'Delete this account and its saved session from the device?', 'theme': 'Theme', 'language': 'Language',
    'light': 'Light', 'dark': 'Dark', 'system': 'System', 'retry': 'Retry', 'back_exit': 'Press back again to exit',
  },
  'ar': {
    'lock_title': 'حماية التطبيق', 'lock_hint': 'أدخل كلمة المرور للمتابعة', 'password': 'كلمة المرور',
    'unlock': 'فتح', 'wrong_password': 'كلمة المرور غير صحيحة',
    'sign_in': 'تسجيل الدخول', 'phone': 'رقم الهاتف', 'invalid_phone': 'أدخل الرقم بصيغة 05xxxxxxxx أو 2135xxxxxxxx',
    'send_otp': 'إرسال الرمز', 'otp': 'رمز التحقق', 'invalid_otp': 'صيغة الرمز غير صحيحة (4-8 أرقام)',
    'verify': 'تحقق', 'resend': 'إعادة إرسال الرمز', 'resend_in': 'إعادة الإرسال بعد {s} ث', 'otp_sent': 'أدخل الرمز المرسل عبر SMS',
    'login_rejected': 'رفض الخادم الطلب. تحقق من الرمز وأعد المحاولة.', 'change_number': 'تغيير الرقم',
    'dashboard': 'الرئيسية', 'account': 'الحساب', 'logged_in': 'تم تسجيل الدخول', 'server_ok': 'الخادم متصل',
    'server_down': 'تعذر الوصول للخادم', 'server_unknown': 'جارٍ الفحص…', 'last_update': 'آخر تحديث', 'refresh': 'تحديث',
    'balance': 'الرصيد', 'balance_unavailable': 'الرصيد غير متاح', 'auto_refresh': 'تحديث تلقائي كل 60 ثانية',
    'internet': 'استهلاك الإنترنت', 'offers_count': 'العروض النشطة', 'total': 'الإجمالي', 'consumed': 'المستهلك',
    'remaining': 'المتبقي', 'expires': 'ينتهي', 'no_offers': 'لا توجد عروض إنترنت نشطة.',
    'quick_actions': 'اختصارات سريعة', 'power_snake': 'Power Snake', 'buy_1gb': 'شراء 1GB', 'buy_2gb': 'شراء 2GB',
    'youtube': 'باقة YouTube', 'daily_gift': 'الهدية اليومية', 'active_offers': 'العروض النشطة', 'packages': 'الباقات',
    'settings': 'الإعدادات', 'confirm': 'تأكيد', 'cancel': 'إلغاء', 'ok': 'حسناً', 'buy': 'شراء', 'play': 'العب',
    'open_box': 'فتح الصندوق', 'confirm_buy': 'تأكيد الشراء', 'confirm_open': 'هل تريد فتح هذا الصندوق؟',
    'confirm_play': 'هل تريد اللعب للحصول على هدية؟', 'h24': '24 ساعة', 'monthly': 'شهري', 'price': 'السعر', 'code': 'الرمز',
    'unlimited_yt': 'باقة غير محدودة: YT', 'validity': 'الصلاحية',
    'purchase_accepted': 'قبل الخادم طلب الشراء. تحقق من رصيدك وحالة الباقة.',
    'insufficient': 'رصيدك غير كافٍ.', 'purchase_failed': 'تعذر إتمام الشراء. حاول لاحقاً.',
    'session_expired': 'انتهت الجلسة. سجّل الدخول مجدداً.', 'network_error': 'خطأ في الاتصال. تحقق من الإنترنت.',
    'failed': 'حدث خطأ. حاول مجدداً.', 'no_boxes': 'لا توجد صناديق متاحة.',
    'box': 'صندوق', 'box_expires': 'ينتهي', 'status': 'الحالة', 'available': 'متاح',
    'box_opened': 'تم فتح الصندوق بنجاح!', 'reward': 'المكافأة', 'box_expired': 'انتهت صلاحية هذا الصندوق.',
    'box_already': 'تم فتح هذا الصندوق مسبقاً.', 'box_unrecognized': 'تم فتح الصندوق لكن تفاصيل المكافأة غير معروفة.',
    'box_failed': 'تعذر فتح الصندوق. حاول لاحقاً.', 'select_box': 'اختر صندوقاً أولاً',
    'gift_now': 'متاحة الآن', 'gift_in': 'متاحة بعد', 'gift_played': 'تم اللعب (الوقت غير متاح)',
    'gift_unknown': 'الحالة غير معروفة', 'gift_unavailable': 'حالة الهدية غير متاحة', 'gift_received': 'تم استلام الهدية بنجاح',
    'gift_name': 'الهدية', 'received_at': 'وقت الاستلام', 'hours_n': '{n} ساعة', 'no_gift': 'لا توجد هدية متاحة حالياً.',
    'u_d': 'يوم', 'u_h': 'ساعة', 'u_m': 'دقيقة', 'not_specified': 'غير محدد',
    'logout': 'تسجيل الخروج', 'delete_account': 'حذف الحساب المحفوظ', 'logout_q': 'تسجيل الخروج من هذا الحساب؟',
    'delete_q': 'حذف هذا الحساب وجلسته المحفوظة من الجهاز؟', 'theme': 'المظهر', 'language': 'اللغة',
    'light': 'فاتح', 'dark': 'داكن', 'system': 'النظام', 'retry': 'إعادة المحاولة', 'back_exit': 'اضغط رجوع مرة أخرى للخروج',
  },
  'fr': {
    'lock_title': "Protection de l'application", 'lock_hint': 'Entrez le mot de passe pour continuer', 'password': 'Mot de passe',
    'unlock': 'Déverrouiller', 'wrong_password': 'Mot de passe incorrect',
    'sign_in': 'Connexion', 'phone': 'Numéro de téléphone', 'invalid_phone': 'Format : 05xxxxxxxx ou 2135xxxxxxxx',
    'send_otp': 'Envoyer le code', 'otp': 'Code de vérification', 'invalid_otp': 'Format invalide (4 à 8 chiffres)',
    'verify': 'Vérifier', 'resend': 'Renvoyer le code', 'resend_in': 'Renvoyer dans {s}s', 'otp_sent': 'Entrez le code reçu par SMS',
    'login_rejected': 'Le serveur a refusé la requête. Vérifiez le code.', 'change_number': 'Changer de numéro',
    'dashboard': 'Accueil', 'account': 'Compte', 'logged_in': 'Connecté', 'server_ok': 'Serveur joignable',
    'server_down': 'Serveur injoignable', 'server_unknown': 'Vérification…', 'last_update': 'Dernière mise à jour', 'refresh': 'Actualiser',
    'balance': 'Solde', 'balance_unavailable': 'Solde indisponible', 'auto_refresh': 'Actualisation auto toutes les 60 s',
    'internet': 'Consommation Internet', 'offers_count': 'Offres actives', 'total': 'Total', 'consumed': 'Consommé',
    'remaining': 'Restant', 'expires': 'Expire le', 'no_offers': "Aucune offre data active.",
    'quick_actions': 'Actions rapides', 'power_snake': 'Power Snake', 'buy_1gb': 'Acheter 1 Go', 'buy_2gb': 'Acheter 2 Go',
    'youtube': 'Pack YouTube', 'daily_gift': 'Cadeau quotidien', 'active_offers': 'Offres actives', 'packages': 'Forfaits',
    'settings': 'Paramètres', 'confirm': 'Confirmer', 'cancel': 'Annuler', 'ok': 'OK', 'buy': 'Acheter', 'play': 'Jouer',
    'open_box': 'Ouvrir la boîte', 'confirm_buy': "Confirmer l'achat", 'confirm_open': 'Ouvrir cette boîte ?',
    'confirm_play': 'Jouer pour un cadeau ?', 'h24': '24 heures', 'monthly': 'Mensuel', 'price': 'Prix', 'code': 'Code',
    'unlimited_yt': 'Pack illimité : YT', 'validity': 'Validité',
    'purchase_accepted': "Le serveur a accepté la demande d'achat. Vérifiez votre solde et le statut du forfait.",
    'insufficient': 'Solde insuffisant.', 'purchase_failed': "L'achat n'a pas pu aboutir. Réessayez plus tard.",
    'session_expired': 'Session expirée. Reconnectez-vous.', 'network_error': 'Erreur de connexion. Vérifiez Internet.',
    'failed': 'Une erreur est survenue. Réessayez.', 'no_boxes': 'Aucune boîte disponible.',
    'box': 'Boîte', 'box_expires': 'Expire', 'status': 'Statut', 'available': 'Disponible',
    'box_opened': 'Boîte ouverte avec succès !', 'reward': 'Récompense', 'box_expired': 'Cette boîte a expiré.',
    'box_already': 'Cette boîte a déjà été ouverte.', 'box_unrecognized': 'Boîte ouverte, détails de la récompense non reconnus.',
    'box_failed': "Impossible d'ouvrir cette boîte. Réessayez plus tard.", 'select_box': "Sélectionnez d'abord une boîte",
    'gift_now': 'Disponible maintenant', 'gift_in': 'Disponible dans', 'gift_played': 'Déjà joué (heure indisponible)',
    'gift_unknown': 'Statut inconnu', 'gift_unavailable': 'Statut du cadeau indisponible', 'gift_received': 'Cadeau reçu avec succès',
    'gift_name': 'Cadeau', 'received_at': 'Reçu le', 'hours_n': '{n} heure(s)', 'no_gift': "Aucun cadeau disponible pour l'instant.",
    'u_d': 'jour(s)', 'u_h': 'heure(s)', 'u_m': 'minute(s)', 'not_specified': 'Non précisé',
    'logout': 'Se déconnecter', 'delete_account': 'Supprimer le compte enregistré', 'logout_q': 'Se déconnecter de ce compte ?',
    'delete_q': "Supprimer ce compte et sa session de l'appareil ?", 'theme': 'Thème', 'language': 'Langue',
    'light': 'Clair', 'dark': 'Sombre', 'system': 'Système', 'retry': 'Réessayer', 'back_exit': 'Appuyez encore pour quitter',
  },
};
