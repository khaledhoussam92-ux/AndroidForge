import 'dart:convert';

import 'package:cookie_jar/cookie_jar.dart';
import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:uuid/uuid.dart';

import '../../data/models/models.dart';
import '../constants/api_constants.dart';
import '../utils/helpers.dart';

/// Port of the Python HTTP engine. Every request builds fresh headers
/// (timestamp, fingerprint, correlation id); nonce/chronos are single use.
class OoredooApi {
  OoredooApi()
      : _dio = Dio(BaseOptions(
          connectTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 35),
          responseType: ResponseType.plain,
          validateStatus: (_) => true,
        )) {
    _dio.interceptors.add(CookieManager(CookieJar())); // like requests.Session
  }

  final Dio _dio;
  static const _uuid = Uuid();

  // ---------- crypto / header helpers (1:1 with Python) ----------
  static String newInstanceId() => '${_uuid.v4()}${DateTime.now().millisecondsSinceEpoch}';
  static String correlationId() => '${_uuid.v4()}${DateTime.now().millisecondsSinceEpoch}';

  static String platformSignature(String deviceId) => base64Encode(utf8.encode(jsonEncode({
        'platform': 'android',
        'is-physical-device': true,
        'device-id': deviceId,
      })));

  static String fingerprint(String iid, String msisdn, String ts) =>
      Hmac(sha256, utf8.encode(ts)).convert(utf8.encode('$ts$iid$msisdn')).toString();

  Map<String, String> commonHeaders(Creds c,
      {String contentType = 'application/json', String? path, String? method}) {
    final ts = DateTime.now().millisecondsSinceEpoch.toString();
    final h = <String, String>{
      'User-Agent': Api.userAgent,
      'Connection': 'Keep-Alive',
      'Accept': 'application/json',
      'Accept-Encoding': 'gzip',
      'Content-Type': contentType,
      'x-msisdn': c.msisdn,
      'x-device-fingerprint': fingerprint(c.iid, c.msisdn, ts),
      'x-platform-origin': 'mobile-android',
      'x-correlation-id': correlationId(),
      'platform': 'android',
      'x-version': Api.xVersion,
      'x-signature': Api.xSignature,
      'x-platform-info': c.psig,
      'x-platform-data-signature': c.psig,
      'x-timestamp': ts,
      'x-instance-id': c.iid,
      'x-force-update': 'true',
    };
    if (path != null) h['x-path'] = path;
    if (method != null) h['x-method'] = method.toUpperCase();
    return h;
  }

  Map<String, String> _h(Creds c,
      {String contentType = 'application/json', String? nonce, String? chronos}) {
    final h = commonHeaders(c, contentType: contentType);
    if (c.token != null) h['Authorization'] = 'Bearer ${c.token}';
    if (nonce != null) h['x-nonce-id'] = nonce;
    if (chronos != null) h['x-chronos-id'] = chronos;
    return h;
  }

  // ---------- transport ----------
  Future<Response<String>> _send(String method, String url,
      {required Map<String, String> headers,
      Object? data,
      Map<String, dynamic>? query,
      Duration? timeout}) async {
    try {
      return await _dio.request<String>(url,
          data: data,
          queryParameters: query,
          options: Options(method: method, headers: headers, receiveTimeout: timeout));
    } on DioException catch (e) {
      throw ApiException(ApiErrorKind.network, e.message ?? 'Network error');
    }
  }

  dynamic _json(Response<String> r) {
    try {
      final v = jsonDecode(r.data ?? '');
      return (v is Map || v is List) ? v : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  bool _ok(Response r) => (r.statusCode ?? 0) >= 200 && (r.statusCode ?? 0) < 300;
  bool _auth(Response r) => r.statusCode == 401 || r.statusCode == 403;

  ApiException _expired() => ApiException(ApiErrorKind.sessionExpired, 'Session expired');
  ApiException _server(String m, [int? code]) => ApiException(ApiErrorKind.server, m, statusCode: code);

  // ---------- authentication ----------
  Future<(String, String)> checkpoint(Creds c,
      {String targetPath = Api.tokenPath, String targetMethod = 'POST'}) async {
    final h = commonHeaders(c,
        contentType: 'application/json; charset=utf-8', path: targetPath, method: targetMethod);
    final r = await _send('POST', '${Api.bff}/checkpoint/token', headers: h, data: '{}', timeout: const Duration(seconds: 25));
    if (r.statusCode != 200 && r.statusCode != 202) {
      throw _server('Checkpoint rejected (${r.statusCode})', r.statusCode);
    }
    final nonce = r.headers.value('x-nonce-id');
    final chronos = r.headers.value('x-chronos-id');
    if (nonce == null || chronos == null) {
      throw _server('Checkpoint response did not contain x-nonce-id / x-chronos-id.');
    }
    return (nonce, chronos);
  }

  Future<TokenResult> tokenRequest(Creds c, String nonce, String chronos,
      {String? otp, String? refreshToken}) async {
    final h = commonHeaders(c, contentType: 'application/x-www-form-urlencoded; charset=utf-8');
    h['Accept'] = '*/*';
    h['x-nonce-id'] = nonce;
    h['x-chronos-id'] = chronos;
    final form = <String, String>{'client_id': Api.clientId};
    if (refreshToken != null && refreshToken.isNotEmpty) {
      form['grant_type'] = 'refresh_token';
      form['refresh_token'] = refreshToken;
    } else {
      form['grant_type'] = 'password';
      form['username'] = c.msisdn;
      if (otp != null && otp.isNotEmpty) form['otp'] = otp;
    }
    final r = await _send('POST', Api.tokenUrl,
        headers: h, data: Uri(queryParameters: form).query, timeout: const Duration(seconds: 25));
    final body = _json(r);
    if (r.statusCode == 200 && body is Map<String, dynamic>) return TokenResult(tokens: body);
    final first = (otp == null || otp.isEmpty) && (refreshToken == null || refreshToken.isEmpty);
    if (first && (r.statusCode == 400 || r.statusCode == 403)) return const TokenResult(smsSent: true);
    throw _server('Token endpoint rejected (${r.statusCode})', r.statusCode);
  }

  // ---------- balance ----------
  Future<String> fetchBalance(Creds c) async {
    final r = await _send('GET', '${Api.base}${Api.activePackagesPath}',
        headers: _h(c), query: {'msisdn': c.msisdn}, timeout: const Duration(seconds: 20));
    if (_auth(r)) throw _expired();
    final body = _json(r);
    if (!_ok(r) || body is! Map) throw _server('Balance unavailable', r.statusCode);
    final raw = body['accountBalance'];
    if (raw == null || '$raw'.trim().isEmpty) throw _server('Balance not returned');
    return '$raw'.trim();
  }

  // ---------- daily gift ----------
  Future<GiftStatus> giftStatus(Creds c) async {
    final r = await _send('GET', '${Api.base}${Api.giftStatusPath}', headers: _h(c));
    if (_auth(r)) throw _expired();
    final body = _json(r);
    if (!_ok(r) || body is! Map) throw _server('Gift status unavailable', r.statusCode);
    final last = parseIso(body['lastPlayedTime']);
    if (last != null) {
      final avail = last.add(const Duration(hours: 24));
      return avail.isAfter(DateTime.now())
          ? GiftStatus(GiftKind.cooldown, avail)
          : const GiftStatus(GiftKind.available);
    }
    if (body['played'] == false) return const GiftStatus(GiftKind.available);
    if (body['played'] == true) return const GiftStatus(GiftKind.playedUnknown);
    return const GiftStatus(GiftKind.unknown);
  }

  /// Returns null when no gift is available.
  Future<GiftResult?> playGift(Creds c) async {
    final (nonce, chronos) =
        await checkpoint(c, targetPath: Api.giftPlayPath, targetMethod: 'GET');
    final r = await _send('GET', '${Api.base}${Api.giftPlayPath}',
        headers: _h(c, nonce: nonce, chronos: chronos), timeout: const Duration(seconds: 35));
    if (_auth(r)) throw _expired();
    final body = _json(r);
    if (_ok(r) && body is Map && body['giftName'] != null && '${body['giftName']}'.isNotEmpty) {
      return GiftResult('${body['giftName']}', body['validityHour'], body['playedTime']?.toString());
    }
    return null;
  }

  // ---------- power snake ----------
  Future<List<SnakeBox>> snakeBoxes(Creds c) async {
    final r = await _send('GET', '${Api.base}${Api.snakePath}',
        headers: _h(c), query: {'status': 'AVAILABLE'});
    if (_auth(r)) throw _expired();
    final body = _json(r);
    if (!_ok(r) || body is! Map) throw _server('Could not retrieve Power Snake boxes.', r.statusCode);
    final items = body['items'];
    if (items is! List) throw _server('The server returned an unexpected box list.');
    final out = <SnakeBox>[];
    for (final it in items) {
      if (it is Map && it['uuid'] != null && '${it['uuid']}'.isNotEmpty) {
        final st = '${it['status'] ?? 'AVAILABLE'}'.toUpperCase();
        if (st == 'AVAILABLE') out.add(SnakeBox('${it['uuid']}', parseIso(it['expiryDate']), st));
      }
    }
    return out;
  }

  Future<RedeemOutcome> redeemBox(Creds c, String uuid) async {
    final r = await _send('POST', '${Api.base}${Api.snakePath}/$uuid/redeem',
        headers: _h(c), timeout: const Duration(seconds: 35));
    final body = _json(r);
    if (_ok(r) && body is Map) {
      final assigned = body['assignedReward'] is Map ? body['assignedReward'] as Map : {};
      final reward = assigned['reward'] is Map ? assigned['reward'] as Map : {};
      if ('${assigned['type'] ?? ''}'.toUpperCase() == 'DATA' && reward.isNotEmpty) {
        return RedeemOutcome(RedeemKind.success,
            amount: '${reward['usage-value'] ?? '?'}',
            unit: '${reward['usage-unit'] ?? ''}',
            validity: reward['validity']?.toString(),
            validityUnit: '${reward['validity-unit'] ?? ''}'.toUpperCase());
      }
      return const RedeemOutcome(RedeemKind.unrecognized);
    }
    if (_auth(r)) throw _expired();
    final msg = body is Map ? '${body['message'] ?? ''}'.toUpperCase() : '';
    if (msg.contains('EXPIRED')) return const RedeemOutcome(RedeemKind.expired);
    if (msg.contains('ALREADY') || msg.contains('REDEEMED')) return const RedeemOutcome(RedeemKind.already);
    return const RedeemOutcome(RedeemKind.failed);
  }

  // ---------- purchases ----------
  Future<PurchaseOutcome> purchase(Creds c, Pkg p) async {
    final path = p.youtube ? Api.byopPurchasePath : Api.purchasePath;
    final (nonce, chronos) = await checkpoint(c, targetPath: path, targetMethod: 'POST');
    final headers = _h(c, contentType: 'application/json; charset=utf-8', nonce: nonce, chronos: chronos);
    final payload = p.youtube
        ? {'validity': 'Monthly', 'limitedBundleDetails': [], 'unlimitedBundleDetails': ['YT']}
        : {'bundleCode': p.bundleCode};
    final url = p.youtube ? '${Api.base}${Api.byopPurchasePath}' : '${Api.bff}/cvm/dynamic-bundle-purchase';
    final r = await _send('POST', url,
        headers: headers, data: jsonEncode(payload), timeout: const Duration(seconds: 35));
    final body = _json(r);
    final code = body is Map ? '${body['code'] ?? ''}'.toUpperCase() : '';
    final msgCode = body is Map ? '${body['message'] ?? ''}'.toUpperCase() : '';
    final msg = msgCode.toLowerCase();
    const codes = {'DYNAMIC_CREDIT_LIMIT_NOT_ENOUGH', 'INSUFFICIENT_BALANCE', 'INSUFFICIENT_CREDIT'};
    final insufficient = codes.contains(code) ||
        codes.contains(msgCode) ||
        ['not enough', 'insufficient', 'رصيدك غير كافي', 'ليس لديك رصيد'].any(msg.contains);
    if (insufficient) return PurchaseOutcome.insufficient;
    if (_ok(r)) return PurchaseOutcome.accepted;
    if (_auth(r)) throw _expired();
    return PurchaseOutcome.failed;
  }

  // ---------- active offers ----------
  Future<dynamic> cvmAllocations(Creds c) async {
    final r = await _send('GET', '${Api.base}${Api.cvmAllocationsPath}', headers: _h(c));
    if (!_ok(r)) {
      if (_auth(r)) throw _expired();
      throw _server('Could not retrieve active offers.', r.statusCode);
    }
    return _json(r);
  }
}
