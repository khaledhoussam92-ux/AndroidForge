import '../../data/models/models.dart';

// Faithful port of the Python helpers: _normal_key, _walk_offer_dicts,
// _get_ci, _number, _offer_data_rows, display_cvm_allocations.

String _normalKey(Object? v) => v.toString().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

bool _empty(dynamic v) =>
    v == null || v == '' || (v is List && v.isEmpty) || (v is Map && v.isEmpty);

Iterable<Map<String, dynamic>> _walkOfferDicts(dynamic value) sync* {
  if (value is Map<String, dynamic>) {
    yield value;
    for (final c in value.values) {
      yield* _walkOfferDicts(c);
    }
  } else if (value is List) {
    for (final c in value) {
      yield* _walkOfferDicts(c);
    }
  }
}

dynamic _getCi(dynamic obj, List<String> names) {
  if (obj is! Map) return null;
  final wanted = names.map(_normalKey).toSet();
  for (final e in obj.entries) {
    if (wanted.contains(_normalKey(e.key)) && !_empty(e.value)) return e.value;
  }
  return null;
}

double? _number(dynamic v) => double.tryParse(v.toString().replaceAll(',', '.').trim());

String _fmtGb(dynamic value, dynamic unit) {
  final n = _number(value);
  final u = (unit == null || '$unit'.isEmpty ? 'GB' : '$unit').toUpperCase();
  return n == null ? '$value' : '${n.toStringAsFixed(2)} $u';
}

String _fmtExpiry(dynamic expiry) {
  final t = expiry.toString().trim();
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})').firstMatch(t);
  return m == null ? t : '${m.group(3)}-${m.group(2)}-${m.group(1)}';
}

List<OfferCard> _offerDataRows(dynamic item) {
  final dicts = _walkOfferDicts(item).toList();
  dynamic offerCode, offerName, expiry;
  for (final o in dicts) {
    offerCode ??= _getCi(o, ['code', 'bundleCode']);
    offerName ??= _getCi(o, ['name', 'offerName', 'bundleName']);
    expiry ??= _getCi(o, ['expire-at', 'expiryDate', 'expirationDate', 'endDate']);
  }
  final rows = <OfferCard>[];
  for (final o in dicts) {
    final usageType = _getCi(o, ['usage-type', 'usageType']);
    final code = _getCi(o, ['code']);
    final total = _getCi(o, ['usage-value', 'usageValue']);
    final unit = _getCi(o, ['usage-unit', 'usageUnit']);
    final remaining = _getCi(o, ['available-amount', 'availableAmount', 'remaining', 'remainingVolume']);
    if (total == null || unit == null || remaining == null) continue;
    if (usageType != null && !['data', 'internet'].contains(usageType.toString().toLowerCase())) continue;
    if (code != null && !['data', 'internet'].contains(code.toString().toLowerCase()) && usageType == null) continue;
    final t = _number(total);
    final r = _number(remaining);
    final consumed = (t != null && r != null) ? (t - r < 0 ? 0.0 : t - r) : null;
    rows.add(OfferCard(
      name: (offerName ?? offerCode ?? 'Active offer').toString(),
      code: (offerCode ?? code)?.toString(),
      unit: unit.toString().toUpperCase(),
      totalText: _fmtGb(total, unit),
      remainingText: _fmtGb(remaining, unit),
      consumedText: consumed == null ? null : _fmtGb(consumed, unit),
      totalNum: t,
      remainingNum: r,
      consumedNum: consumed,
      expiry: expiry == null ? null : _fmtExpiry(expiry),
    ));
  }
  return rows;
}

List<OfferCard> parseCvmAllocations(dynamic body) {
  List<dynamic> items;
  if (body is List) {
    items = body;
  } else if (body is Map) {
    List<dynamic>? found;
    const keys = ['items', 'allocations', 'offers', 'data', 'results'];
    for (final k in keys) {
      if (body[k] is List) {
        found = body[k] as List;
        break;
      }
    }
    if (found == null) {
      final p = body['payload'];
      if (p is List) {
        found = p;
      } else if (p is Map) {
        for (final k in keys) {
          if (p[k] is List) {
            found = p[k] as List;
            break;
          }
        }
        found ??= [p];
      } else {
        found = body.isNotEmpty ? [body] : [];
      }
    }
    items = found;
  } else {
    items = [];
  }
  final out = <OfferCard>[];
  final seen = <String>{};
  for (final it in items) {
    for (final c in _offerDataRows(it)) {
      final key = '${c.name}|${c.code}|${c.totalText}|${c.remainingText}|${c.expiry}';
      if (seen.add(key)) out.add(c);
    }
  }
  return out;
}
