/// Port of normalize_msisdn: accepts 05xxxxxxxx / 2135xxxxxxxx (with optional +/spaces).
String? normalizeMsisdn(String input) {
  var v = input.trim().replaceAll('+', '').replaceAll(RegExp(r'\s+'), '');
  if (v.startsWith('0') && v.length == 10) v = '213${v.substring(1)}';
  return RegExp(r'^213\d{9}$').hasMatch(v) ? v : null;
}

String maskPhone(String m) => m.length < 4 ? m : '******${m.substring(m.length - 4)}';

String two(int n) => n.toString().padLeft(2, '0');

String fmtDateTime(DateTime d) =>
    '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';

String fmtTime(DateTime d) => '${two(d.hour)}:${two(d.minute)}:${two(d.second)}';

String fmtDuration(Duration d) {
  final s = d.inSeconds < 0 ? 0 : d.inSeconds;
  return '${two(s ~/ 3600)}:${two((s % 3600) ~/ 60)}:${two(s % 60)}';
}

/// Port of parse_datetime: ISO string; timezone-less values are local time.
DateTime? parseIso(dynamic v) {
  if (v is! String || v.trim().isEmpty) return null;
  final d = DateTime.tryParse(v.trim());
  return d?.toLocal();
}

int toInt(dynamic v) => v is num ? v.toInt() : (int.tryParse('$v') ?? 0);
