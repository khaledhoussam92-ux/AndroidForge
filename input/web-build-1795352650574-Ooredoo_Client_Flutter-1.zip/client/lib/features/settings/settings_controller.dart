import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/providers.dart';

class AppSettings {
  const AppSettings(this.themeMode, this.locale);
  final ThemeMode themeMode;
  final Locale? locale; // null = system
}

class SettingsController extends StateNotifier<AppSettings> {
  SettingsController(this._p) : super(_load(_p));
  final SharedPreferences _p;

  static AppSettings _load(SharedPreferences p) {
    final t = switch (p.getString('theme')) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    final l = p.getString('lang');
    return AppSettings(t, (l == null || l.isEmpty) ? null : Locale(l));
  }

  void setTheme(ThemeMode m) {
    _p.setString('theme', m.name);
    state = AppSettings(m, state.locale);
  }

  void setLocale(Locale? l) {
    _p.setString('lang', l?.languageCode ?? '');
    state = AppSettings(state.themeMode, l);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsController, AppSettings>((ref) => SettingsController(ref.watch(prefsProvider)));
