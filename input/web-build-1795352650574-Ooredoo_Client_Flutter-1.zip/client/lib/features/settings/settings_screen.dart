import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../shared/widgets/widgets.dart';
import '../authentication/auth_controller.dart';
import 'settings_controller.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final st = ref.watch(settingsProvider);
    final ctrl = ref.read(settingsProvider.notifier);
    final lang = st.locale?.languageCode ?? 'system';
    return Scaffold(
      appBar: AppBar(title: Text(s.t('settings'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.t('theme'), style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            SegmentedButton<ThemeMode>(
              showSelectedIcon: false,
              segments: [
                ButtonSegment(value: ThemeMode.system, label: Text(s.t('system'))),
                ButtonSegment(value: ThemeMode.light, label: Text(s.t('light'))),
                ButtonSegment(value: ThemeMode.dark, label: Text(s.t('dark'))),
              ],
              selected: {st.themeMode},
              onSelectionChanged: (v) => ctrl.setTheme(v.first),
            ),
            const SizedBox(height: 20),
            Text(s.t('language'), style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            SegmentedButton<String>(
              showSelectedIcon: false,
              segments: [
                ButtonSegment(value: 'system', label: Text(s.t('system'))),
                const ButtonSegment(value: 'ar', label: Text('العربية')),
                const ButtonSegment(value: 'en', label: Text('EN')),
                const ButtonSegment(value: 'fr', label: Text('FR')),
              ],
              selected: {lang},
              onSelectionChanged: (v) => ctrl.setLocale(v.first == 'system' ? null : Locale(v.first)),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          icon: const Icon(Icons.logout_rounded),
          label: Text(s.t('logout')),
          onPressed: () async {
            final ok = await confirmDialog(context, title: s.t('logout'), body: s.t('logout_q'), confirmLabel: s.t('logout'));
            if (!ok || !context.mounted) return;
            Navigator.of(context).popUntil((r) => r.isFirst);
            ref.read(authProvider.notifier).logout();
          },
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(foregroundColor: Theme.of(context).colorScheme.error),
          icon: const Icon(Icons.delete_forever_rounded),
          label: Text(s.t('delete_account')),
          onPressed: () async {
            final ok = await confirmDialog(context, title: s.t('delete_account'), body: s.t('delete_q'), confirmLabel: s.t('delete_account'));
            if (!ok || !context.mounted) return;
            Navigator.of(context).popUntil((r) => r.isFirst);
            ref.read(authProvider.notifier).deleteAccount();
          },
        ),
      ]),
    );
  }
}
