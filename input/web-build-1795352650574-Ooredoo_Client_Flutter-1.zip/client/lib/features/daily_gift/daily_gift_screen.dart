import 'dart:async';

import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/providers.dart';
import '../../core/utils/helpers.dart';
import '../../data/models/models.dart';
import '../../shared/widgets/widgets.dart';
import '../authentication/auth_controller.dart';
import '../dashboard/dashboard_controller.dart';

class DailyGiftScreen extends ConsumerStatefulWidget {
  const DailyGiftScreen({super.key});
  @override
  ConsumerState<DailyGiftScreen> createState() => _DailyGiftScreenState();
}

class _DailyGiftScreenState extends ConsumerState<DailyGiftScreen> {
  Timer? _tick;
  bool _busy = false;
  bool _refetchedAtZero = false;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final g = ref.read(dashboardProvider).gift;
      if (g?.kind == GiftKind.cooldown && g!.availableAt != null) {
        if (!g.availableAt!.isAfter(DateTime.now())) {
          if (!_refetchedAtZero) {
            _refetchedAtZero = true;
            ref.read(dashboardProvider.notifier).refreshGift();
          }
        } else {
          _refetchedAtZero = false;
          setState(() {}); // only ticks while a countdown is running
        }
      }
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _play() async {
    final s = S.of(context);
    if (_busy) return;
    final ok = await confirmDialog(context, title: s.t('daily_gift'), body: s.t('confirm_play'), confirmLabel: s.t('play'));
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final m = ref.read(authProvider).msisdn!;
    try {
      final r = await ref.read(repoProvider).authed(m, (c) => ref.read(apiProvider).playGift(c));
      if (!mounted) return;
      if (r != null) {
        final lines = <String>[
          '${s.t('gift_name')}: ${r.name}',
          if (r.validityHour != null) '${s.t('validity')}: ${s.f('hours_n', {'n': '${r.validityHour}'})}',
          if (r.playedTime != null && r.playedTime!.isNotEmpty) '${s.t('received_at')}: ${r.playedTime}',
        ];
        await infoDialog(context, icon: Icons.card_giftcard_rounded, title: s.t('gift_received'), body: lines.join('\n'));
      } else {
        showSnack(context, s.t('no_gift'), error: true);
      }
    } catch (e) {
      if (e is ApiException && e.kind == ApiErrorKind.sessionExpired) {
        ref.read(authProvider.notifier).sessionExpired();
      }
      if (mounted) showSnack(context, errMsg(context, e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
      // Status refreshes automatically after every attempt.
      ref.read(dashboardProvider.notifier).refreshGift();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final d = ref.watch(dashboardProvider);
    final g = d.gift;
    String title;
    String? big;
    IconData icon = Icons.card_giftcard_rounded;
    if (g == null && d.giftLoading) {
      title = '';
    } else if (g == null) {
      title = s.t('gift_unavailable');
    } else {
      switch (g.kind) {
        case GiftKind.available:
          title = s.t('gift_now');
        case GiftKind.cooldown:
          title = s.t('gift_in');
          big = fmtDuration(g.availableAt!.difference(DateTime.now()));
          icon = Icons.hourglass_bottom_rounded;
        case GiftKind.playedUnknown:
          title = s.t('gift_played');
        case GiftKind.unknown:
          title = s.t('gift_unknown');
      }
    }
    return RefreshIndicator(
      onRefresh: ref.read(dashboardProvider.notifier).refreshGift,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          color: cs.primaryContainer,
          padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 20),
          child: Column(children: [
            Icon(icon, size: 72, color: cs.onPrimaryContainer),
            const SizedBox(height: 16),
            if (g == null && d.giftLoading)
              const Skeleton(width: 160, height: 28)
            else
              Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: cs.onPrimaryContainer)),
            if (big != null)
              Directionality(
                textDirection: TextDirection.ltr,
                child: Text(big, style: TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: cs.onPrimaryContainer, fontFeatures: const [FontFeature.tabularFigures()])),
              ),
          ]),
        ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: _busy ? null : _play,
          icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Icon(Icons.play_arrow_rounded),
          label: Text(s.t('play')),
        ),
        if (d.giftFailed && g == null) EmptyState(icon: Icons.cloud_off_rounded, text: s.t('network_error'), onRetry: ref.read(dashboardProvider.notifier).refreshGift),
      ]),
    );
  }
}
