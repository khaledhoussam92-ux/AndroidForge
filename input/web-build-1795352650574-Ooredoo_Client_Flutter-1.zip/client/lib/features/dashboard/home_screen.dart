import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../active_offers/active_offers_screen.dart';
import '../daily_gift/daily_gift_screen.dart';
import '../packages/packages_screen.dart';
import '../power_snake/power_snake_screen.dart';
import '../settings/settings_screen.dart';
import 'dashboard_controller.dart';
import 'dashboard_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // No background polling: pause the 60s timer when the app is not visible.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final c = ref.read(dashboardProvider.notifier);
    if (state == AppLifecycleState.resumed) {
      c.start();
      c.refreshAll();
    } else if (state == AppLifecycleState.paused) {
      c.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final tab = ref.watch(tabProvider);
    final titles = [s.t('dashboard'), s.t('packages'), s.t('power_snake'), s.t('daily_gift'), s.t('active_offers')];
    return PopScope(
      canPop: tab == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) ref.read(tabProvider.notifier).state = 0;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(tab == 0 ? 'Ooredoo Client' : titles[tab]),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_rounded),
              tooltip: s.t('settings'),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
        body: IndexedStack(index: tab, children: const [
          DashboardScreen(),
          PackagesScreen(),
          PowerSnakeScreen(),
          DailyGiftScreen(),
          ActiveOffersScreen(),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) {
            HapticFeedback.selectionClick();
            ref.read(tabProvider.notifier).state = i;
          },
          destinations: [
            NavigationDestination(icon: const Icon(Icons.dashboard_outlined), selectedIcon: const Icon(Icons.dashboard_rounded), label: titles[0]),
            NavigationDestination(icon: const Icon(Icons.shopping_bag_outlined), selectedIcon: const Icon(Icons.shopping_bag_rounded), label: titles[1]),
            NavigationDestination(icon: const Icon(Icons.pest_control_rodent_outlined), selectedIcon: const Icon(Icons.pest_control_rodent_rounded), label: 'Snake'),
            NavigationDestination(icon: const Icon(Icons.card_giftcard_outlined), selectedIcon: const Icon(Icons.card_giftcard_rounded), label: titles[3]),
            NavigationDestination(icon: const Icon(Icons.local_offer_outlined), selectedIcon: const Icon(Icons.local_offer_rounded), label: titles[4]),
          ],
        ),
      ),
    );
  }
}
