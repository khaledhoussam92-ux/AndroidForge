import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/api_constants.dart';
import '../../core/l10n/strings.dart';
import '../../core/utils/helpers.dart';
import '../../data/models/models.dart';
import '../../shared/widgets/widgets.dart';
import '../authentication/auth_controller.dart';
import '../packages/purchase_flow.dart';
import 'dashboard_controller.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(dashboardProvider);
    final ctrl = ref.read(dashboardProvider.notifier);
    final msisdn = ref.watch(authProvider.select((a) => a.msisdn)) ?? '';
    return RefreshIndicator(
      onRefresh: ctrl.refreshAll,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          _AccountCard(msisdn: msisdn, d: d, onRefresh: ctrl.refreshAll),
          const SizedBox(height: 12),
          _BalanceCard(d: d, onRefresh: ctrl.refreshBalance),
          const SizedBox(height: 12),
          _InternetCard(d: d),
          const SizedBox(height: 20),
          _QuickActions(),
        ],
      ),
    );
  }
}

class _AccountCard extends StatelessWidget {
  const _AccountCard({required this.msisdn, required this.d, required this.onRefresh});
  final String msisdn;
  final DashState d;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final busy = d.balanceLoading || d.offersLoading || d.giftLoading;
    final server = d.serverOk == null ? s.t('server_unknown') : (d.serverOk! ? s.t('server_ok') : s.t('server_down'));
    final serverColor = d.serverOk == false ? cs.error : cs.primary;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 24, backgroundColor: cs.primaryContainer, child: Icon(Icons.person_rounded, color: cs.onPrimaryContainer)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.t('account'), style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
              Directionality(textDirection: TextDirection.ltr, child: Text(maskPhone(msisdn), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
            ]),
          ),
          IconButton.filledTonal(
            onPressed: busy ? null : onRefresh,
            tooltip: s.t('refresh'),
            icon: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Icon(Icons.refresh_rounded),
          ),
        ]),
        const SizedBox(height: 14),
        Wrap(spacing: 8, runSpacing: 8, children: [
          Chip(avatar: const Icon(Icons.verified_user_rounded, size: 18), label: Text(s.t('logged_in'))),
          Chip(avatar: Icon(Icons.cloud_done_rounded, size: 18, color: serverColor), label: Text(server)),
        ]),
        if (d.lastUpdate != null) ...[
          const SizedBox(height: 8),
          Text('${s.t('last_update')}: ${fmtDateTime(d.lastUpdate!)}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
        ],
      ]),
    );
  }
}

class _BalanceCard extends StatelessWidget {
  const _BalanceCard({required this.d, required this.onRefresh});
  final DashState d;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    return AppCard(
      color: cs.primaryContainer,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_wallet_rounded, color: cs.onPrimaryContainer),
          const SizedBox(width: 8),
          Expanded(child: Text(s.t('balance'), style: TextStyle(color: cs.onPrimaryContainer, fontWeight: FontWeight.w700))),
          if (d.balanceLoading) const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)),
          IconButton(onPressed: d.balanceLoading ? null : onRefresh, icon: Icon(Icons.refresh_rounded, color: cs.onPrimaryContainer)),
        ]),
        const SizedBox(height: 4),
        if (d.balance == null && d.balanceLoading)
          const Skeleton(width: 160, height: 44)
        else if (d.balance == null)
          Text(s.t('balance_unavailable'), style: TextStyle(fontSize: 20, color: cs.onPrimaryContainer))
        else
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text('${d.balance} DA', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: cs.onPrimaryContainer)),
          ),
        const SizedBox(height: 6),
        Text(
          d.balanceAt != null ? '${s.t('last_update')}: ${fmtTime(d.balanceAt!)}  •  ${s.t('auto_refresh')}' : s.t('auto_refresh'),
          style: TextStyle(color: cs.onPrimaryContainer.withOpacity(0.75), fontSize: 12),
        ),
        if (d.balanceFailed && d.balance != null)
          Text(s.t('balance_unavailable'), style: TextStyle(color: cs.error, fontSize: 12)),
      ]),
    );
  }
}

class _InternetCard extends StatelessWidget {
  const _InternetCard({required this.d});
  final DashState d;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final offers = d.offers;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.network_cell_rounded, color: cs.primary),
          const SizedBox(width: 8),
          Text(s.t('internet'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 14),
        if (offers == null && d.offersLoading) ...[
          const Skeleton(height: 22), const SizedBox(height: 10), const Skeleton(width: 220),
        ] else if (offers == null)
          EmptyState(icon: Icons.cloud_off_rounded, text: s.t('network_error'))
        else if (offers.isEmpty)
          Text(s.t('no_offers'), style: TextStyle(color: cs.onSurfaceVariant))
        else ...[
          Text('${s.t('offers_count')}: ${offers.length}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ..._totals(context, offers),
          const SizedBox(height: 12),
          for (final o in offers) _OfferRow(o: o),
        ],
      ]),
    );
  }

  List<Widget> _totals(BuildContext context, List<OfferCard> offers) {
    final s = S.of(context);
    if (offers.map((o) => o.unit).toSet().length != 1 ||
        offers.any((o) => o.totalNum == null || o.remainingNum == null)) {
      return [];
    }
    final u = offers.first.unit;
    final total = offers.fold<double>(0, (a, o) => a + o.totalNum!);
    final rem = offers.fold<double>(0, (a, o) => a + o.remainingNum!);
    final used = total - rem < 0 ? 0.0 : total - rem;
    String f(double v) => '${v.toStringAsFixed(2)} $u';
    return [
      const SizedBox(height: 8),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Wrap(spacing: 16, runSpacing: 4, children: [
          Text('${s.t('total')}: ${f(total)}'),
          Text('${s.t('consumed')}: ${f(used)}'),
          Text('${s.t('remaining')}: ${f(rem)}'),
        ]),
      ),
    ];
  }
}

class _OfferRow extends StatelessWidget {
  const _OfferRow({required this.o});
  final OfferCard o;
  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(o.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        ProgressBar(value: o.usedFraction),
        const SizedBox(height: 4),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Text('${s.t('remaining')} ${o.remainingText} / ${o.totalText}'
              '${o.expiry != null ? '  •  ${s.t('expires')} ${o.expiry}' : ''}',
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        ),
      ]),
    );
  }
}

class _QuickActions extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final tab = ref.read(tabProvider.notifier);
    final items = <(IconData, String, VoidCallback)>[
      (Icons.pest_control_rodent_rounded, s.t('power_snake'), () => tab.state = 2),
      (Icons.looks_one_rounded, s.t('buy_1gb'), () => confirmAndBuy(context, ref, packages[0])),
      (Icons.looks_two_rounded, s.t('buy_2gb'), () => confirmAndBuy(context, ref, packages[1])),
      (Icons.smart_display_rounded, s.t('youtube'), () => confirmAndBuy(context, ref, packages[2])),
      (Icons.card_giftcard_rounded, s.t('daily_gift'), () => tab.state = 3),
      (Icons.local_offer_rounded, s.t('active_offers'), () => tab.state = 4),
    ];
    final cs = Theme.of(context).colorScheme;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Text(s.t('quick_actions'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(height: 12),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.5,
        children: [
          for (final it in items)
            Material(
              color: cs.secondaryContainer,
              borderRadius: BorderRadius.circular(28),
              child: InkWell(
                borderRadius: BorderRadius.circular(28),
                onTap: it.$3,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Icon(it.$1, size: 30, color: cs.onSecondaryContainer),
                    Text(it.$2, style: TextStyle(fontWeight: FontWeight.w700, color: cs.onSecondaryContainer)),
                  ]),
                ),
              ),
            ),
        ],
      ),
    ]);
  }
}
