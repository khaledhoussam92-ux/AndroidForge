import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/api_constants.dart';
import '../../core/providers.dart';
import '../../core/utils/offer_parser.dart';
import '../../data/models/models.dart';
import '../authentication/auth_controller.dart';

final tabProvider = StateProvider<int>((ref) => 0);

class DashState {
  const DashState({
    this.balance,
    this.balanceAt,
    this.balanceLoading = false,
    this.balanceFailed = false,
    this.offers,
    this.offersLoading = false,
    this.offersFailed = false,
    this.gift,
    this.giftLoading = false,
    this.giftFailed = false,
    this.serverOk,
    this.lastUpdate,
  });
  final String? balance;
  final DateTime? balanceAt;
  final bool balanceLoading, balanceFailed;
  final List<OfferCard>? offers;
  final bool offersLoading, offersFailed;
  final GiftStatus? gift;
  final bool giftLoading, giftFailed;
  final bool? serverOk;
  final DateTime? lastUpdate;

  DashState copyWith({
    String? balance,
    DateTime? balanceAt,
    bool? balanceLoading,
    bool? balanceFailed,
    List<OfferCard>? offers,
    bool? offersLoading,
    bool? offersFailed,
    GiftStatus? gift,
    bool? giftLoading,
    bool? giftFailed,
    bool? serverOk,
    DateTime? lastUpdate,
  }) =>
      DashState(
        balance: balance ?? this.balance,
        balanceAt: balanceAt ?? this.balanceAt,
        balanceLoading: balanceLoading ?? this.balanceLoading,
        balanceFailed: balanceFailed ?? this.balanceFailed,
        offers: offers ?? this.offers,
        offersLoading: offersLoading ?? this.offersLoading,
        offersFailed: offersFailed ?? this.offersFailed,
        gift: gift ?? this.gift,
        giftLoading: giftLoading ?? this.giftLoading,
        giftFailed: giftFailed ?? this.giftFailed,
        serverOk: serverOk ?? this.serverOk,
        lastUpdate: lastUpdate ?? this.lastUpdate,
      );
}

class DashboardController extends StateNotifier<DashState> {
  DashboardController(this._ref, this.msisdn) : super(const DashState()) {
    if (msisdn.isNotEmpty) {
      refreshAll();
      start();
    }
  }
  final Ref _ref;
  final String msisdn;
  Timer? _timer;
  bool _b = false, _o = false, _g = false; // in-flight guards (no duplicate requests)

  /// 60s balance auto-refresh; stopped while the app is in the background.
  void start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: Api.balanceRefreshSeconds), (_) => refreshBalance());
  }

  void stop() => _timer?.cancel();

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> refreshAll() => Future.wait([refreshBalance(), refreshOffers(), refreshGift()]);

  void _onError(Object e) {
    if (e is ApiException) {
      if (e.kind == ApiErrorKind.sessionExpired) {
        _ref.read(authProvider.notifier).sessionExpired();
      } else if (e.kind == ApiErrorKind.network && mounted) {
        state = state.copyWith(serverOk: false);
      }
    }
  }

  Future<void> refreshBalance() async {
    if (_b) return;
    _b = true;
    state = state.copyWith(balanceLoading: true);
    try {
      final v = await _ref.read(repoProvider).authed(msisdn, (c) => _ref.read(apiProvider).fetchBalance(c));
      if (!mounted) return;
      final now = DateTime.now();
      state = state.copyWith(
          balance: v, balanceAt: now, balanceFailed: false, balanceLoading: false, serverOk: true, lastUpdate: now);
    } catch (e) {
      _onError(e);
      if (mounted) state = state.copyWith(balanceFailed: true, balanceLoading: false);
    } finally {
      _b = false;
    }
  }

  Future<void> refreshOffers() async {
    if (_o) return;
    _o = true;
    state = state.copyWith(offersLoading: true);
    try {
      final body = await _ref.read(repoProvider).authed(msisdn, (c) => _ref.read(apiProvider).cvmAllocations(c));
      if (!mounted) return;
      final now = DateTime.now();
      state = state.copyWith(
          offers: parseCvmAllocations(body), offersFailed: false, offersLoading: false, serverOk: true, lastUpdate: now);
    } catch (e) {
      _onError(e);
      if (mounted) state = state.copyWith(offersFailed: true, offersLoading: false);
    } finally {
      _o = false;
    }
  }

  Future<void> refreshGift() async {
    if (_g) return;
    _g = true;
    state = state.copyWith(giftLoading: true);
    try {
      final g = await _ref.read(repoProvider).authed(msisdn, (c) => _ref.read(apiProvider).giftStatus(c));
      if (!mounted) return;
      state = state.copyWith(gift: g, giftFailed: false, giftLoading: false, serverOk: true);
    } catch (e) {
      _onError(e);
      if (mounted) state = state.copyWith(giftFailed: true, giftLoading: false);
    } finally {
      _g = false;
    }
  }
}

final dashboardProvider = StateNotifierProvider<DashboardController, DashState>((ref) {
  final a = ref.watch(authProvider);
  final m = a.status == AuthStatus.loggedIn ? (a.msisdn ?? '') : '';
  return DashboardController(ref, m);
});
