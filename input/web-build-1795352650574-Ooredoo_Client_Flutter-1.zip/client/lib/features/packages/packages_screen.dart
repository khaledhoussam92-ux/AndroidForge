import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/api_constants.dart';
import '../../core/l10n/strings.dart';
import '../../shared/widgets/widgets.dart';
import 'purchase_flow.dart';

class PackagesScreen extends ConsumerWidget {
  const PackagesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final busy = ref.watch(purchaseBusyProvider);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      for (final p in packages)
        Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: AppCard(
            color: p.youtube ? cs.tertiaryContainer : cs.surfaceContainerHigh,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(20)),
                  child: Icon(p.youtube ? Icons.smart_display_rounded : Icons.wifi_rounded, color: cs.onPrimary),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(p.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text('${p.price} DZD', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.primary)),
                ),
              ]),
              const SizedBox(height: 14),
              _line(context, Icons.schedule_rounded, '${s.t('validity')}: ${s.t(p.validityKey)}'),
              _line(context, Icons.qr_code_2_rounded,
                  p.youtube ? s.t('unlimited_yt') : '${s.t('code')}: ${p.bundleCode}'),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: busy ? null : () => confirmAndBuy(context, ref, p),
                icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Icon(Icons.shopping_cart_checkout_rounded),
                label: Text('${s.t('buy')} • ${p.price} DZD'),
              ),
            ]),
          ),
        ),
    ]);
  }

  Widget _line(BuildContext context, IconData i, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(children: [
          Icon(i, size: 18, color: Theme.of(context).colorScheme.onSurfaceVariant),
          const SizedBox(width: 8),
          Expanded(child: Directionality(textDirection: TextDirection.ltr, child: Align(alignment: AlignmentDirectional.centerStart, child: Text(t)))),
        ]),
      );
}
