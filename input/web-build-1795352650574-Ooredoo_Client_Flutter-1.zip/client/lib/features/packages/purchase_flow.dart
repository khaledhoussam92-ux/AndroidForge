import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/api_constants.dart';
import '../../core/l10n/strings.dart';
import '../../core/providers.dart';
import '../../data/models/models.dart';
import '../../shared/widgets/widgets.dart';
import '../authentication/auth_controller.dart';
import '../dashboard/dashboard_controller.dart';

final purchaseBusyProvider = StateProvider<bool>((ref) => false);

/// Confirmation -> checkpoint -> purchase. "Success" is only reported when
/// the server answered with a 2xx status.
Future<void> confirmAndBuy(BuildContext context, WidgetRef ref, Pkg p) async {
  final s = S.of(context);
  if (ref.read(purchaseBusyProvider)) return;
  final ok = await confirmDialog(
    context,
    title: s.t('confirm_buy'),
    body: '${p.title} • ${s.t(p.validityKey)} • ${p.price} DZD',
    confirmLabel: s.t('buy'),
  );
  if (!ok || !context.mounted) return;
  final busy = ref.read(purchaseBusyProvider.notifier);
  if (busy.state) return;
  busy.state = true;
  final m = ref.read(authProvider).msisdn;
  try {
    final r = await ref.read(repoProvider).authed(m!, (c) => ref.read(apiProvider).purchase(c, p));
    if (!context.mounted) return;
    switch (r) {
      case PurchaseOutcome.accepted:
        await infoDialog(context, icon: Icons.check_circle_rounded, title: p.title, body: s.t('purchase_accepted'));
        final d = ref.read(dashboardProvider.notifier);
        d.refreshBalance();
        d.refreshOffers();
      case PurchaseOutcome.insufficient:
        showSnack(context, s.t('insufficient'), error: true);
      case PurchaseOutcome.failed:
        showSnack(context, s.t('purchase_failed'), error: true);
    }
  } catch (e) {
    if (e is ApiException && e.kind == ApiErrorKind.sessionExpired) {
      ref.read(authProvider.notifier).sessionExpired();
    }
    if (context.mounted) showSnack(context, errMsg(context, e), error: true);
  } finally {
    busy.state = false;
  }
}
