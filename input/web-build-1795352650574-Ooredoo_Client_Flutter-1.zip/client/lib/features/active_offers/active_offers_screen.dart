import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../shared/widgets/widgets.dart';
import '../dashboard/dashboard_controller.dart';

class ActiveOffersScreen extends ConsumerWidget {
  const ActiveOffersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final d = ref.watch(dashboardProvider);
    final ctrl = ref.read(dashboardProvider.notifier);
    final offers = d.offers;
    Widget body;
    if (offers == null && d.offersLoading) {
      body = const Padding(padding: EdgeInsets.all(16), child: SkeletonCards(count: 3));
    } else if (offers == null) {
      body = EmptyState(icon: Icons.cloud_off_rounded, text: s.t('network_error'), onRetry: ctrl.refreshOffers);
    } else if (offers.isEmpty) {
      body = EmptyState(icon: Icons.local_offer_outlined, text: s.t('no_offers'));
    } else {
      body = Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(children: [
          for (final o in offers)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(Icons.wifi_rounded, color: cs.primary),
                    const SizedBox(width: 8),
                    Expanded(child: Text(o.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                  ]),
                  if (o.code != null) ...[
                    const SizedBox(height: 6),
                    Directionality(textDirection: TextDirection.ltr, child: Text('${s.t('code')}: ${o.code}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12))),
                  ],
                  const SizedBox(height: 14),
                  ProgressBar(value: o.usedFraction),
                  const SizedBox(height: 12),
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: Wrap(spacing: 18, runSpacing: 6, children: [
                      _kv(context, s.t('total'), o.totalText),
                      _kv(context, s.t('remaining'), o.remainingText),
                      if (o.consumedText != null) _kv(context, s.t('consumed'), o.consumedText!),
                      if (o.expiry != null) _kv(context, s.t('expires'), o.expiry!),
                    ]),
                  ),
                ]),
              ),
            ),
        ]),
      );
    }
    return RefreshIndicator(
      onRefresh: ctrl.refreshOffers,
      child: ListView(physics: const AlwaysScrollableScrollPhysics(), children: [body]),
    );
  }

  Widget _kv(BuildContext c, String k, String v) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(k, style: TextStyle(fontSize: 12, color: Theme.of(c).colorScheme.onSurfaceVariant)),
        Text(v, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
      ]);
}
