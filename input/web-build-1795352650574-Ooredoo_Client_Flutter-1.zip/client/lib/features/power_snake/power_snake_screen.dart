import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/providers.dart';
import '../../core/utils/helpers.dart';
import '../../data/models/models.dart';
import '../../shared/widgets/widgets.dart';
import '../authentication/auth_controller.dart';
import '../dashboard/dashboard_controller.dart';

final snakeBoxesProvider = FutureProvider.autoDispose<List<SnakeBox>>((ref) async {
  final m = ref.watch(authProvider.select((a) => a.status == AuthStatus.loggedIn ? a.msisdn : null));
  if (m == null) return [];
  try {
    return await ref.read(repoProvider).authed(m, (c) => ref.read(apiProvider).snakeBoxes(c));
  } on ApiException catch (e) {
    if (e.kind == ApiErrorKind.sessionExpired) ref.read(authProvider.notifier).sessionExpired();
    rethrow;
  }
});

class PowerSnakeScreen extends ConsumerStatefulWidget {
  const PowerSnakeScreen({super.key});
  @override
  ConsumerState<PowerSnakeScreen> createState() => _PowerSnakeScreenState();
}

class _PowerSnakeScreenState extends ConsumerState<PowerSnakeScreen> {
  String? _selected;
  bool _busy = false;

  Future<void> _open(List<SnakeBox> boxes) async {
    final s = S.of(context);
    if (_busy) return;
    final box = boxes.where((b) => b.uuid == _selected).firstOrNull;
    if (box == null) {
      showSnack(context, s.t('select_box'), error: true);
      return;
    }
    final ok = await confirmDialog(context,
        title: s.t('open_box'),
        body: '${s.t('confirm_open')}\n${s.t('box_expires')}: ${box.expiry == null ? '—' : fmtDateTime(box.expiry!)}',
        confirmLabel: s.t('open_box'));
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final m = ref.read(authProvider).msisdn!;
    try {
      final r = await ref.read(repoProvider).authed(m, (c) => ref.read(apiProvider).redeemBox(c, box.uuid));
      if (!mounted) return;
      switch (r.kind) {
        case RedeemKind.success:
          const names = {'D': 'u_d', 'H': 'u_h', 'M': 'u_m'};
          final vText = r.validity == null
              ? s.t('not_specified')
              : '${r.validity} ${names[r.validityUnit] != null ? s.t(names[r.validityUnit]!) : (r.validityUnit ?? '')}';
          await infoDialog(context,
              icon: Icons.celebration_rounded,
              title: s.t('box_opened'),
              body: '${s.t('reward')}: ${r.amount} ${r.unit}\n${s.t('validity')}: $vText'.trim());
        case RedeemKind.unrecognized:
          showSnack(context, s.t('box_unrecognized'));
        case RedeemKind.expired:
          showSnack(context, s.t('box_expired'), error: true);
        case RedeemKind.already:
          showSnack(context, s.t('box_already'), error: true);
        case RedeemKind.failed:
          showSnack(context, s.t('box_failed'), error: true);
      }
      _selected = null;
      ref.invalidate(snakeBoxesProvider);
      ref.read(dashboardProvider.notifier).refreshOffers();
    } catch (e) {
      if (e is ApiException && e.kind == ApiErrorKind.sessionExpired) {
        ref.read(authProvider.notifier).sessionExpired();
      }
      if (mounted) showSnack(context, errMsg(context, e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final async = ref.watch(snakeBoxesProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.refresh(snakeBoxesProvider.future),
      child: async.when(
        loading: () => ListView(padding: const EdgeInsets.all(16), children: const [SkeletonCards(count: 3)]),
        error: (e, _) => ListView(children: [
          const SizedBox(height: 60),
          EmptyState(icon: Icons.error_outline_rounded, text: errMsg(context, e), onRetry: () => ref.invalidate(snakeBoxesProvider)),
        ]),
        data: (boxes) {
          if (boxes.isEmpty) {
            return ListView(children: [const SizedBox(height: 60), EmptyState(icon: Icons.inventory_2_outlined, text: s.t('no_boxes'))]);
          }
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
            for (var i = 0; i < boxes.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(28),
                  onTap: () => setState(() => _selected = boxes[i].uuid),
                  child: AppCard(
                    color: _selected == boxes[i].uuid ? cs.primaryContainer : null,
                    child: Row(children: [
                      Icon(Icons.inventory_2_rounded, size: 34, color: cs.primary),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${s.t('box')} ${i + 1}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text('${s.t('box_expires')}: ${boxes[i].expiry == null ? '—' : fmtDateTime(boxes[i].expiry!)}'),
                        ]),
                      ),
                      Chip(label: Text(s.t('available'))),
                      Radio<String>(value: boxes[i].uuid, groupValue: _selected, onChanged: (v) => setState(() => _selected = v)),
                    ]),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: (_busy || _selected == null) ? null : () => _open(boxes),
              icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Icon(Icons.lock_open_rounded),
              label: Text(s.t('open_box')),
            ),
          ]);
        },
      ),
    );
  }
}
