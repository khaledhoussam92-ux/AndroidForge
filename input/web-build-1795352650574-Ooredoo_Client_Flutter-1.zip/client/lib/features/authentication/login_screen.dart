import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/providers.dart';
import '../../core/utils/helpers.dart';
import '../../data/models/models.dart';
import '../../shared/widgets/widgets.dart';
import 'auth_controller.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _phone = TextEditingController();
  final _otp = TextEditingController();
  bool _otpStep = false, _busy = false;
  int _cooldown = 0;
  Timer? _timer;
  String? _msisdn;

  @override
  void initState() {
    super.initState();
    final m = ref.read(authProvider).msisdn;
    if (m != null) _phone.text = '0${m.substring(3)}';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _phone.dispose();
    _otp.dispose();
    super.dispose();
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => _cooldown = 60);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _cooldown--);
      if (_cooldown <= 0) t.cancel();
    });
  }

  Future<void> _sendOtp({bool resend = false}) async {
    if (_busy) return;
    final s = S.of(context);
    final m = resend ? _msisdn : normalizeMsisdn(_phone.text);
    if (m == null) {
      showSnack(context, s.t('invalid_phone'), error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      final repo = ref.read(repoProvider);
      final step = resend ? await repo.requestOtp(m) : await repo.start(m);
      if (!mounted) return;
      _msisdn = m;
      if (step == LoginStep.ready) {
        await ref.read(authProvider.notifier).loggedIn(m);
        return;
      }
      setState(() => _otpStep = true);
      _startCooldown();
      showSnack(context, s.t('otp_sent'));
    } catch (e) {
      if (mounted) showSnack(context, _msg(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _msg(Object e) {
    final s = S.of(context);
    if (e is ApiException && e.kind == ApiErrorKind.server) return s.t('login_rejected');
    return errMsg(context, e);
  }

  Future<void> _verify() async {
    if (_busy) return;
    final s = S.of(context);
    final otp = _otp.text.trim();
    if (!RegExp(r'^\d{4,8}$').hasMatch(otp)) {
      showSnack(context, s.t('invalid_otp'), error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      await ref.read(repoProvider).verifyOtp(_msisdn!, otp);
      if (!mounted) return;
      await ref.read(authProvider.notifier).loggedIn(_msisdn!);
    } catch (e) {
      if (mounted) showSnack(context, _msg(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final cs = Theme.of(context).colorScheme;
    final spinner = const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5));
    return PopScope(
      canPop: !_otpStep,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _otpStep = false);
      },
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Container(
                      width: 88,
                      height: 88,
                      decoration: BoxDecoration(color: cs.primary, borderRadius: BorderRadius.circular(30)),
                      child: Icon(Icons.sim_card_rounded, size: 44, color: cs.onPrimary),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(s.t('sign_in'), style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 28),
                  if (!_otpStep) ...[
                    TextField(
                      controller: _phone,
                      keyboardType: TextInputType.phone,
                      textDirection: TextDirection.ltr,
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))],
                      onSubmitted: (_) => _sendOtp(),
                      decoration: InputDecoration(
                        labelText: s.t('phone'),
                        hintText: '05xxxxxxxx',
                        prefixIcon: const Icon(Icons.phone_android_rounded),
                      ),
                    ),
                    const SizedBox(height: 20),
                    FilledButton(onPressed: _busy ? null : () => _sendOtp(), child: _busy ? spinner : Text(s.t('send_otp'))),
                  ] else ...[
                    Text('${s.t('otp_sent')}\n${maskPhone(_msisdn ?? '')}', style: TextStyle(color: cs.onSurfaceVariant)),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _otp,
                      keyboardType: TextInputType.number,
                      textDirection: TextDirection.ltr,
                      maxLength: 8,
                      style: const TextStyle(fontSize: 24, letterSpacing: 6, fontWeight: FontWeight.w700),
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      onSubmitted: (_) => _verify(),
                      decoration: InputDecoration(labelText: s.t('otp'), counterText: '', prefixIcon: const Icon(Icons.password_rounded)),
                    ),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _busy ? null : _verify, child: _busy ? spinner : Text(s.t('verify'))),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: (_busy || _cooldown > 0) ? null : () => _sendOtp(resend: true),
                      child: Text(_cooldown > 0 ? s.f('resend_in', {'s': '$_cooldown'}) : s.t('resend')),
                    ),
                    TextButton(
                      onPressed: _busy ? null : () => setState(() => _otpStep = false),
                      child: Text(s.t('change_number')),
                    ),
                  ],
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
