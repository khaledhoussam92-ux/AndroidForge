import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';

enum AuthStatus { booting, locked, loggedOut, loggedIn }

class AuthState {
  const AuthState(this.status, [this.msisdn]);
  final AuthStatus status;
  final String? msisdn;
}

class AuthController extends StateNotifier<AuthState> {
  AuthController(this._ref) : super(const AuthState(AuthStatus.booting)) {
    _init();
  }
  final Ref _ref;

  Future<void> _init() async {
    if (!await _ref.read(lockServiceProvider).isUnlocked()) {
      state = const AuthState(AuthStatus.locked);
      return;
    }
    await _resume();
  }

  Future<void> _resume() async {
    final store = _ref.read(storeProvider);
    final m = await store.currentMsisdn();
    if (m != null) {
      final a = await store.get(m);
      if (a != null && (a.hasValidAccess || a.hasValidRefresh)) {
        state = AuthState(AuthStatus.loggedIn, m);
        return;
      }
    }
    state = AuthState(AuthStatus.loggedOut, m);
  }

  Future<bool> unlock(String password) async {
    final ok = await _ref.read(lockServiceProvider).verifyAndStore(password);
    if (ok) await _resume();
    return ok;
  }

  Future<void> loggedIn(String msisdn) async {
    await _ref.read(storeProvider).setCurrent(msisdn);
    state = AuthState(AuthStatus.loggedIn, msisdn);
  }

  /// Tokens rejected and refresh impossible: drop them, ask for a new OTP.
  Future<void> sessionExpired() async {
    if (state.status != AuthStatus.loggedIn) return;
    final m = state.msisdn;
    if (m != null) await _ref.read(repoProvider).invalidate(m);
    state = AuthState(AuthStatus.loggedOut, m);
  }

  Future<void> logout() async {
    final m = state.msisdn;
    if (m != null) await _ref.read(repoProvider).invalidate(m);
    await _ref.read(storeProvider).setCurrent(null);
    state = AuthState(AuthStatus.loggedOut, m);
  }

  Future<void> deleteAccount() async {
    final m = state.msisdn;
    final store = _ref.read(storeProvider);
    if (m != null) await store.delete(m);
    await store.setCurrent(null);
    state = const AuthState(AuthStatus.loggedOut);
  }
}

final authProvider = StateNotifierProvider<AuthController, AuthState>((ref) => AuthController(ref));
