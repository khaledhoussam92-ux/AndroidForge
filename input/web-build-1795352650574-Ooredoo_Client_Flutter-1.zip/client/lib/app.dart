import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/l10n/strings.dart';
import 'core/theme/app_theme.dart';
import 'features/authentication/auth_controller.dart';
import 'features/authentication/lock_screen.dart';
import 'features/authentication/login_screen.dart';
import 'features/dashboard/home_screen.dart';
import 'features/settings/settings_controller.dart';

class OoredooApp extends ConsumerWidget {
  const OoredooApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final status = ref.watch(authProvider.select((a) => a.status));
    final Widget home = switch (status) {
      AuthStatus.booting => const Scaffold(body: Center(child: CircularProgressIndicator())),
      AuthStatus.locked => const LockScreen(),
      AuthStatus.loggedOut => const LoginScreen(),
      AuthStatus.loggedIn => const HomeScreen(),
    };
    return MaterialApp(
      title: 'Ooredoo Client',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: settings.themeMode,
      locale: settings.locale,
      supportedLocales: const [Locale('ar'), Locale('en'), Locale('fr')],
      localizationsDelegates: const [
        S.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 350),
        child: KeyedSubtree(key: ValueKey(status), child: home),
      ),
    );
  }
}
