import 'package:flutter/material.dart';

import '../../core/l10n/strings.dart';
import '../../data/models/models.dart';

class AppCard extends StatelessWidget {
  const AppCard({super.key, required this.child, this.color, this.padding = const EdgeInsets.all(20)});
  final Widget child;
  final Color? color;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(color: color ?? cs.surfaceContainerHigh, borderRadius: BorderRadius.circular(28)),
      child: child,
    );
  }
}

class Skeleton extends StatefulWidget {
  const Skeleton({super.key, this.width = double.infinity, this.height = 18});
  final double width, height;
  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: Tween(begin: 0.35, end: 0.9).animate(_c),
        child: Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
}

class SkeletonCards extends StatelessWidget {
  const SkeletonCards({super.key, this.count = 3});
  final int count;
  @override
  Widget build(BuildContext context) => Column(children: [
        for (var i = 0; i < count; i++)
          const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Skeleton(width: 140, height: 20),
                SizedBox(height: 14),
                Skeleton(),
                SizedBox(height: 10),
                Skeleton(width: 200),
              ]),
            ),
          ),
      ]);
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text, this.onRetry});
  final IconData icon;
  final String text;
  final VoidCallback? onRetry;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 64, color: cs.outline),
        const SizedBox(height: 12),
        Text(text, textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 16)),
        if (onRetry != null) ...[
          const SizedBox(height: 16),
          FilledButton.tonal(
            style: FilledButton.styleFrom(minimumSize: const Size(140, 48)),
            onPressed: onRetry,
            child: Text(S.of(context).t('retry')),
          ),
        ],
      ]),
    );
  }
}

class ProgressBar extends StatelessWidget {
  const ProgressBar({super.key, required this.value});
  final double? value;
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: LinearProgressIndicator(value: value, minHeight: 10),
      );
}

void showSnack(BuildContext context, String msg, {bool error = false}) {
  final cs = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: TextStyle(color: error ? cs.onErrorContainer : null)),
      backgroundColor: error ? cs.errorContainer : null,
    ));
}

Future<bool> confirmDialog(BuildContext context,
    {required String title, required String body, required String confirmLabel}) async {
  final s = S.of(context);
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(s.t('cancel'))),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
          onPressed: () => Navigator.pop(c, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return r ?? false;
}

Future<void> infoDialog(BuildContext context, {required IconData icon, required String title, String? body}) =>
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        icon: Icon(icon, size: 40),
        title: Text(title, textAlign: TextAlign.center),
        content: body == null ? null : Text(body),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: Text(S.of(context).t('ok')))],
      ),
    );

String errMsg(BuildContext context, Object e) {
  final s = S.of(context);
  if (e is ApiException) {
    switch (e.kind) {
      case ApiErrorKind.network:
        return s.t('network_error');
      case ApiErrorKind.sessionExpired:
        return s.t('session_expired');
      case ApiErrorKind.server:
        return s.t('failed');
    }
  }
  return s.t('failed');
}
