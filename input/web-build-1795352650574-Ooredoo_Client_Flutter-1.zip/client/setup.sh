#!/usr/bin/env bash
# Generates the Android platform files, then builds the APK.
set -e
cd "$(dirname "$0")"
TMP=$(mktemp -d)
mv lib "$TMP/lib"; mv pubspec.yaml "$TMP/pubspec.yaml"
flutter create --org com.khaled.ooredoo --project-name client --platforms android .
rm -rf lib; mv "$TMP/lib" lib; mv "$TMP/pubspec.yaml" pubspec.yaml
rm -f test/widget_test.dart
M=android/app/src/main/AndroidManifest.xml
grep -q 'permission.INTERNET' "$M" || sed -i '0,/<application/s##<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' "$M"
sed -i 's#android:label="[^"]*"#android:label="Ooredoo Client"#' "$M"
# flutter_secure_storage needs minSdk 23
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i -E 's/minSdk(Version)?( =)? *flutter\.minSdkVersion/minSdk = 23/' "$f"
done
flutter pub get
flutter analyze
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
