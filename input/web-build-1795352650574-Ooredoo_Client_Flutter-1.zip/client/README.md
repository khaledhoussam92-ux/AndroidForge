# Ooredoo Client (Flutter)

تحويل سكربت Python إلى تطبيق Android. لم يُبنَ هذا المشروع ولم يُختبر في بيئة الإنشاء (لا يوجد Flutter SDK هناك)،
لذلك شغّل التحليل والبناء على جهازك.

## البناء
المتطلبات: Flutter stable 3.27 أو أحدث، وAndroid SDK.

    ./setup.sh

يقوم السكربت بـ: `flutter create` (اسم الحزمة `com.khaled.ooredoo.client`) ← إضافة صلاحية INTERNET وضبط minSdk 23
← `flutter pub get` ← `flutter analyze` ← `flutter build apk --release`.
الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## البنية
`core/` (constants, theme, network, security, utils, l10n) · `data/` (models, repositories, services) ·
`features/` (authentication, dashboard, power_snake, packages, daily_gift, active_offers, settings) · `shared/widgets`.

## ملاحظات
- كلمة مرور القفل مخزّنة كبصمة SHA-256 مملّحة فقط داخل `lock_service.dart`، وحالة الفتح في Secure Storage.
  هذا القفل رادع بسيط، ويمكن تجاوزه بفك تجميع التطبيق.
- التصميم Material 3 (ألوان Ooredoo الحمراء، بطاقات مستديرة). لا توجد مكتبة رسمية باسم "Expressive" في Flutter stable.
- مؤقت إعادة إرسال OTP ثابت 60 ثانية لأن الخادم لا يعيد قيمة في الاستجابة.
- لم تُضف Local Notifications (غير مطلوبة لأي وظيفة في السكربت).
- يُعلن عن نجاح الشراء فقط عند رد 2xx من الخادم، وبصيغة "قبل الخادم الطلب".
- استخدمه فقط مع رقم تملكه أو مخوّل باستخدامه.
