package com.khaled.ooredoo.client

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
