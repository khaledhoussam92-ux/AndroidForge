class ApiConstants {
  static const base = 'https://apis.ooredoo.dz';
  static const bff = '$base/api/ooredoo-bff';
  static const tokenUrl = '$base/api/auth/realms/myooredoo/protocol/openid-connect/token';
  static const tokenPath = '/api/auth/realms/myooredoo/protocol/openid-connect/token';
  static const snakePath = '/api/ooredoo-bff/gamification/power-snake';
  static const giftPlayPath = '/api/ooredoo-bff/gamification/play';
  static const giftStatusPath = '/api/ooredoo-bff/gamification/status';
  static const purchasePath = '/api/ooredoo-bff/cvm/dynamic-bundle-purchase';
  static const byopPath = '/api/ooredoo-bff/bundle/purchase/byop';
  static const activePackagesPath = '/api/ooredoo-bff/bundle/getActivePackages';
  static const offersPath = '/api/ooredoo-bff/cvm/getCvmAllocations';
  static const clientId = 'myooredoo-app';
  static const signature = 'ee41e0dcab1ac6840c6d83cba9dcbe1d4b24074fdab16718ae12f48950080114';
  static const version = '1.5.21';
  static const userAgent = 'Dart/3.11 (dart:io)';
}
