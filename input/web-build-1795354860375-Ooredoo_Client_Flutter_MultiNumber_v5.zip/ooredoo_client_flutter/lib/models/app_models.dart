class OoredooAccount {
  OoredooAccount({required this.msisdn, required this.instanceId, this.accessToken, this.refreshToken, this.accessExpiresAt = 0, this.refreshExpiresAt = 0});
  final String msisdn;
  final String instanceId;
  String? accessToken;
  String? refreshToken;
  int accessExpiresAt;
  int refreshExpiresAt;
  Map<String, dynamic> toJson() => {'msisdn': msisdn, 'instanceId': instanceId, 'accessToken': accessToken, 'refreshToken': refreshToken, 'accessExpiresAt': accessExpiresAt, 'refreshExpiresAt': refreshExpiresAt};
  factory OoredooAccount.fromJson(Map<String, dynamic> j) => OoredooAccount(msisdn: j['msisdn'], instanceId: j['instanceId'], accessToken: j['accessToken'], refreshToken: j['refreshToken'], accessExpiresAt: j['accessExpiresAt'] ?? 0, refreshExpiresAt: j['refreshExpiresAt'] ?? 0);
}

class DataAllowance {
  DataAllowance({required this.name, required this.code, required this.total, required this.unit, required this.remaining, required this.consumed, required this.expiry});
  final String name, code, unit, expiry;
  final double? total, remaining, consumed;
}

class SnakeBox {
  SnakeBox({required this.uuid, required this.status, required this.expiry});
  final String uuid, status, expiry;
}
