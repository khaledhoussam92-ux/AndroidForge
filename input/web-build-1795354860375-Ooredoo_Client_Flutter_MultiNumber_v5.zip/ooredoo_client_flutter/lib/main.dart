import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'models/app_models.dart';
import 'services/ooredoo_api.dart';

const _red = Color(0xFFE60000);
const _accountsKey = 'saved_ooredoo_numbers';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await OoredooApi.instance.initialize();
  runApp(const OoredooApp());
}

class OoredooApp extends StatefulWidget {
  const OoredooApp({super.key});
  @override
  State<OoredooApp> createState() => _OoredooAppState();
}

class _OoredooAppState extends State<OoredooApp> {
  ThemeMode _mode = ThemeMode.system;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => _mode = p.getBool('darkMode') == true ? ThemeMode.dark : ThemeMode.light);
    });
  }

  Future<void> _setDark(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('darkMode', value);
    if (mounted) setState(() => _mode = value ? ThemeMode.dark : ThemeMode.light);
  }

  ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: _red, brightness: brightness);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF101014) : const Color(0xFFF6F6F8),
      appBarTheme: const AppBarTheme(centerTitle: false, scrolledUnderElevation: 0),
      cardTheme: CardThemeData(
        elevation: 0,
        color: dark ? const Color(0xFF1D1D23) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(minimumSize: const Size(0, 50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Ooredoo Client',
        themeMode: _mode,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        home: AppGate(onTheme: _setDark),
      );
}

class AppGate extends StatefulWidget {
  const AppGate({super.key, required this.onTheme});
  final ValueChanged<bool> onTheme;
  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  final _secure = const FlutterSecureStorage();
  bool? _unlocked;

  @override
  void initState() {
    super.initState();
    _secure.read(key: 'app_unlocked').then((v) {
      if (mounted) setState(() => _unlocked = v == 'true');
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_unlocked == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!_unlocked!) {
      return LockScreen(onUnlock: () async {
        await _secure.write(key: 'app_unlocked', value: 'true');
        if (mounted) setState(() => _unlocked = true);
      });
    }
    return AccountsHome(onTheme: widget.onTheme);
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key, required this.onUnlock});
  final VoidCallback onUnlock;
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _controller = TextEditingController();
  bool _show = false;
  String? _error;
  static const _passwordHash = '9aa5b6bf87b7bdb92617a221bc5d3999bf3dd108c0203546a60de296c197692f';

  void _check() {
    final hash = sha256.convert(utf8.encode(_controller.text)).toString();
    if (hash == _passwordHash) {
      widget.onUnlock();
    } else {
      setState(() => _error = 'كلمة المرور غير صحيحة');
      _controller.clear();
    }
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: Center(child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
            _BrandMark(size: 76),
            const SizedBox(height: 26),
            Text('مرحباً بك', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8), const Text('أدخل رمز الحماية للمتابعة'),
            const SizedBox(height: 24),
            TextField(controller: _controller, obscureText: !_show, autofocus: true, onSubmitted: (_) => _check(), decoration: InputDecoration(
              labelText: 'رمز الحماية', errorText: _error, prefixIcon: const Icon(Icons.lock_outline),
              suffixIcon: IconButton(onPressed: () => setState(() => _show = !_show), icon: Icon(_show ? Icons.visibility_off : Icons.visibility)),
            )),
            const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton(onPressed: _check, child: const Text('فتح التطبيق'))),
          ])),
        ))),
      );
}

class _BrandMark extends StatelessWidget {
  const _BrandMark({this.size = 42});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(color: _red, borderRadius: BorderRadius.circular(size * .32)),
        alignment: Alignment.center,
        child: Text('O', style: TextStyle(color: Colors.white, fontSize: size * .62, fontWeight: FontWeight.w900)),
      );
}

class AccountsHome extends StatefulWidget {
  const AccountsHome({super.key, required this.onTheme});
  final ValueChanged<bool> onTheme;
  @override
  State<AccountsHome> createState() => _AccountsHomeState();
}

class _AccountsHomeState extends State<AccountsHome> {
  List<String> _numbers = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadNumbers(); }

  Future<void> _loadNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() { _numbers = prefs.getStringList(_accountsKey) ?? []; _loading = false; });
  }

  String _display(String number) => number.startsWith('213') && number.length == 12 ? '0${number.substring(3)}' : number;

  Future<void> _addNumber() async {
    final result = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const AddAccountScreen()));
    if (result == null) return;
    final prefs = await SharedPreferences.getInstance();
    final updated = [...(prefs.getStringList(_accountsKey) ?? [])];
    if (!updated.contains(result)) updated.add(result);
    await prefs.setStringList(_accountsKey, updated);
    if (mounted) setState(() => _numbers = updated);
  }

  Future<void> _openNumber(String number) async {
    try {
      await OoredooApi.instance.restore(number);
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => AccountDetailsScreen(number: number, onTheme: widget.onTheme)));
    } catch (e) {
      if (!mounted) return;
      final retry = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
        title: const Text('تعذر فتح الحساب'),
        content: Text(e.toString().replaceFirst('Exception: ', '')),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('تسجيل الدخول'))],
      ));
      if (retry == true && mounted) {
        final result = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => AddAccountScreen(initialPhone: _display(number))));
        if (result != null) await _openNumber(result);
      }
    }
  }

  Future<void> _removeNumber(String number) async {
    final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('حذف الرقم'), content: Text('هل تريد إزالة ${_display(number)} وبيانات جلسته من هذا الجهاز؟'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))],
    ));
    if (yes != true) return;
    await OoredooApi.instance.removeStoredAccount(number);
    final prefs = await SharedPreferences.getInstance();
    final updated = [...(prefs.getStringList(_accountsKey) ?? [])]..remove(number);
    await prefs.setStringList(_accountsKey, updated);
    if (mounted) setState(() => _numbers = updated);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Row(children: [const _BrandMark(), const SizedBox(width: 10), Text('Ooredoo Client', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))]),
          actions: [PopupMenuButton<String>(onSelected: (v) { if (v == 'dark') widget.onTheme(Theme.of(context).brightness != Brightness.dark); }, itemBuilder: (_) => [PopupMenuItem(value: 'dark', child: Row(children: [const Icon(Icons.contrast), const SizedBox(width: 10), Text(Theme.of(context).brightness == Brightness.dark ? 'الوضع الفاتح' : 'الوضع الداكن')]))])]),
        floatingActionButton: FloatingActionButton.extended(onPressed: _addNumber, icon: const Icon(Icons.add), label: const Text('إضافة رقم')),
        body: _loading ? const Center(child: CircularProgressIndicator()) : _numbers.isEmpty
            ? _EmptyAccounts(onAdd: _addNumber)
            : RefreshIndicator(onRefresh: _loadNumbers, child: ListView(padding: const EdgeInsets.fromLTRB(16, 18, 16, 100), children: [
                Text('أرقامك المحفوظة', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6), Text('اختر رقماً لعرض الرصيد والباقات والعروض الخاصة به.', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                const SizedBox(height: 18),
                ..._numbers.map((n) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Card(child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                  leading: Container(width: 46, height: 46, decoration: BoxDecoration(color: _red.withOpacity(.10), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.sim_card, color: _red)),
                  title: Text(_display(n), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                  subtitle: const Text('اضغط لعرض الحساب والخدمات'), trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'delete') _removeNumber(n); }, itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف الرقم'))]),
                  onTap: () => _openNumber(n),
                )))),
              ])),
      );
}

class _EmptyAccounts extends StatelessWidget {
  const _EmptyAccounts({required this.onAdd});
  final VoidCallback onAdd;
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 112, height: 112, decoration: BoxDecoration(color: _red.withOpacity(.08), shape: BoxShape.circle), child: const Icon(Icons.sim_card_download_outlined, size: 54, color: _red)),
    const SizedBox(height: 24), Text('لا توجد أرقام بعد', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('أضف رقم Ooredoo الخاص بك لعرض رصيده وباقاته وعروضه في مكان واحد.', textAlign: TextAlign.center),
    const SizedBox(height: 22), FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('إضافة أول رقم')),
  ])));
}

class AddAccountScreen extends StatefulWidget {
  const AddAccountScreen({super.key, this.initialPhone = ''});
  final String initialPhone;
  @override
  State<AddAccountScreen> createState() => _AddAccountScreenState();
}

class _AddAccountScreenState extends State<AddAccountScreen> {
  late final TextEditingController _phone = TextEditingController(text: widget.initialPhone);
  final _otp = TextEditingController();
  bool _otpMode = false;
  bool _busy = false;
  String? _error;

  Future<void> _submit() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      if (!_otpMode) {
        await OoredooApi.instance.requestOtp(_phone.text.trim());
        if (mounted) setState(() => _otpMode = true);
      } else {
        await OoredooApi.instance.verifyOtp(_otp.text.trim());
        final number = OoredooApi.instance.account!.msisdn;
        if (mounted) Navigator.of(context).pop(number);
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() { _phone.dispose(); _otp.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('إضافة رقم جديد')),
        body: SafeArea(child: Center(child: SingleChildScrollView(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 12), const _BrandMark(size: 64), const SizedBox(height: 26),
          Text(_otpMode ? 'تأكيد الرقم' : 'ربط حساب Ooredoo', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), Text(_otpMode ? 'أدخل رمز التحقق الذي وصلك برسالة SMS.' : 'أدخل رقم الهاتف ثم أكّد رمز OTP لإضافته إلى قائمة أرقامك.'),
          const SizedBox(height: 24),
          if (!_otpMode) TextField(controller: _phone, keyboardType: TextInputType.phone, inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))], decoration: const InputDecoration(labelText: 'رقم الهاتف', hintText: '05xxxxxxxx', prefixIcon: Icon(Icons.phone_android))),
          if (_otpMode) TextField(controller: _otp, keyboardType: TextInputType.number, maxLength: 8, autofocus: true, decoration: const InputDecoration(labelText: 'رمز OTP', prefixIcon: Icon(Icons.password))),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: _busy ? null : _submit, child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(_otpMode ? 'تأكيد وإضافة الرقم' : 'إرسال رمز OTP'))),
          if (_otpMode) Center(child: TextButton(onPressed: _busy ? null : () => setState(() { _otpMode = false; _otp.clear(); _error = null; }), child: const Text('تغيير رقم الهاتف'))),
        ])))))),
      );
}

class AccountDetailsScreen extends StatefulWidget {
  const AccountDetailsScreen({super.key, required this.number, required this.onTheme});
  final String number;
  final ValueChanged<bool> onTheme;
  @override
  State<AccountDetailsScreen> createState() => _AccountDetailsScreenState();
}

class _AccountDetailsScreenState extends State<AccountDetailsScreen> {
  String? _balance;
  DateTime? _balanceTime;
  List<DataAllowance> _offers = [];
  String _giftState = 'جارٍ التحقق';
  bool _loading = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _refreshAll();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) { _refreshBalance(silent: true); _refreshGift(silent: true); });
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  String get _displayNumber => widget.number.startsWith('213') ? '0${widget.number.substring(3)}' : widget.number;

  Future<void> _refreshAll() async {
    if (_loading) return;
    setState(() => _loading = true);
    await Future.wait([_refreshBalance(silent: true), _refreshOffers(silent: true), _refreshGift(silent: true)]);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _refreshBalance({bool silent = false}) async {
    try {
      final value = await OoredooApi.instance.fetchBalance();
      if (mounted) setState(() { _balance = value; _balanceTime = OoredooApi.instance.balanceUpdatedAt; });
    } catch (e) { if (!silent && mounted) _message(e.toString()); }
  }

  Future<void> _refreshOffers({bool silent = false}) async {
    try { final result = await OoredooApi.instance.fetchOffers(); if (mounted) setState(() => _offers = result); }
    catch (e) { if (!silent && mounted) _message(e.toString()); }
  }

  Future<void> _refreshGift({bool silent = false}) async {
    try {
      final result = await OoredooApi.instance.giftStatus();
      final last = DateTime.tryParse('${result['lastPlayedTime'] ?? ''}');
      if (last != null) {
        final left = const Duration(hours: 24) - DateTime.now().difference(last.toLocal());
        _giftState = left.isNegative ? 'متاحة الآن' : 'بعد ${left.inHours} س ${left.inMinutes % 60} د';
      } else { _giftState = result['played'] == false ? 'متاحة الآن' : 'الحالة غير معروفة'; }
      if (mounted) setState(() {});
    } catch (e) { _giftState = 'غير متاحة'; if (!silent && mounted) _message(e.toString()); if (mounted) setState(() {}); }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value.replaceFirst('Exception: ', ''))));
  }

  Future<bool> _confirm(String title, String body) async => await showDialog<bool>(context: context, builder: (c) => AlertDialog(
        title: Text(title), content: Text(body),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('تأكيد'))],
      )) ?? false;

  Future<void> _buy(String title, Future<void> Function() action) async {
    if (!await _confirm('تأكيد العملية', 'هل تريد تنفيذ $title؟')) return;
    try { await action(); if (mounted) _message('تم قبول الطلب من الخادم. تحقق من حالة الباقة.'); await _refreshAll(); }
    catch (e) { if (mounted) _message(e.toString()); }
  }

  Future<void> _playGift() async {
    if (!await _confirm('الهدية اليومية', 'هل تريد اللعب للحصول على الهدية اليومية؟')) return;
    try {
      final result = await OoredooApi.instance.playGift();
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('مبروك!'), content: Text('الهدية: ${result['giftName']}\nالصلاحية: ${result['validityHour'] ?? '—'} ساعة\nوقت الاستلام: ${result['playedTime'] ?? '—'}'), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))]));
      await _refreshGift();
    } catch (e) { if (mounted) _message(e.toString()); }
  }

  Future<void> _snake() async {
    try {
      final boxes = await OoredooApi.instance.fetchSnakeBoxes();
      if (!mounted) return;
      if (boxes.isEmpty) { _message('لا توجد صناديق متاحة حالياً'); return; }
      final selected = await showModalBottomSheet<SnakeBox>(context: context, showDragHandle: true, builder: (c) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('صناديق Power Snake', style: Theme.of(context).textTheme.titleLarge),
        ...boxes.map((b) => Card(child: ListTile(leading: const Icon(Icons.inventory_2_outlined), title: const Text('صندوق متاح'), subtitle: Text('ينتهي: ${b.expiry}'), onTap: () => Navigator.pop(c, b)))),
      ]));
      if (selected == null || !mounted) return;
      if (!await _confirm('فتح الصندوق', 'هل أنت متأكد من فتح الصندوق المحدد؟')) return;
      final result = await OoredooApi.instance.redeemSnake(selected.uuid);
      final assigned = result['assignedReward'];
      final reward = assigned is Map ? assigned['reward'] : null;
      final message = reward is Map ? '${reward['usage-value'] ?? ''} ${reward['usage-unit'] ?? ''} • الصلاحية ${reward['validity'] ?? '—'} ${reward['validity-unit'] ?? ''}' : 'تم فتح الصندوق، لكن تفاصيل المكافأة غير معروفة.';
      if (mounted) await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('نتيجة Power Snake'), content: Text(message), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))]));
    } catch (e) { if (mounted) _message(e.toString()); }
  }

  String _fmt(double? value) => value == null ? '—' : value.toStringAsFixed(2);
  String _remainingSummary() {
    final totals = <String, double>{};
    for (final offer in _offers) { if (offer.remaining != null) { final unit = offer.unit.toUpperCase(); totals[unit] = (totals[unit] ?? 0) + offer.remaining!; } }
    return totals.isEmpty ? '—' : totals.entries.map((e) => '${e.value.toStringAsFixed(2)} ${e.key}').join(' + ');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_displayNumber, style: const TextStyle(fontWeight: FontWeight.bold)), Text('تفاصيل الحساب', style: Theme.of(context).textTheme.labelMedium)]),
          actions: [IconButton(tooltip: 'تحديث الكل', onPressed: _refreshAll, icon: const Icon(Icons.refresh)), PopupMenuButton<String>(onSelected: (v) { if (v == 'dark') widget.onTheme(Theme.of(context).brightness != Brightness.dark); }, itemBuilder: (_) => [PopupMenuItem(value: 'dark', child: Text(Theme.of(context).brightness == Brightness.dark ? 'الوضع الفاتح' : 'الوضع الداكن'))])]),
        body: RefreshIndicator(onRefresh: _refreshAll, child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), children: [
          _sectionHeader('ملخص الحساب', Icons.account_circle_outlined),
          Card(color: Theme.of(context).colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Icon(Icons.account_balance_wallet_outlined), const SizedBox(width: 8), const Text('الرصيد الحالي'), const Spacer(), if (_loading) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) else IconButton(onPressed: _refreshBalance, icon: const Icon(Icons.refresh))]),
            Text(_balance == null ? '— DA' : '$_balance DA', style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontWeight: FontWeight.w900)),
            Text(_balanceTime == null ? 'لم يتم التحديث بعد' : 'آخر تحديث ${DateFormat('HH:mm:ss').format(_balanceTime!)}'),
          ]))),
          const SizedBox(height: 20),
          _sectionHeader('استهلاك الإنترنت', Icons.data_usage),
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Text('إجمالي المتبقي', style: TextStyle(fontWeight: FontWeight.w600)), const Spacer(), Text(_remainingSummary(), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold))]),
            const SizedBox(height: 10), if (_offers.isEmpty && _loading) const LinearProgressIndicator(),
            if (_offers.isEmpty && !_loading) const Text('لا توجد عروض بيانات نشطة أو تعذر جلبها.'),
            ..._offers.map(_allowanceTile),
            Align(alignment: AlignmentDirectional.centerEnd, child: TextButton.icon(onPressed: _refreshOffers, icon: const Icon(Icons.refresh), label: const Text('تحديث الاستهلاك'))),
          ]))),
          const SizedBox(height: 20),
          _sectionHeader('شراء الباقات', Icons.shopping_bag_outlined),
          _packageTile('1 GB', '24 ساعة', '30 دج', Icons.data_usage, () => _buy('باقة 1GB مقابل 30 دج', () => OoredooApi.instance.purchaseBundle('BTL_24H_SMART_30DZD_1Go'))),
          const SizedBox(height: 9),
          _packageTile('2 GB', '24 ساعة', '50 دج', Icons.cloud_download_outlined, () => _buy('باقة 2GB مقابل 50 دج', () => OoredooApi.instance.purchaseBundle('BTL_24H_SMART_50DZD_2Go'))),
          const SizedBox(height: 9),
          _packageTile('YouTube', 'شهرياً', '200 دج', Icons.smart_display_outlined, () => _buy('باقة YouTube مقابل 200 دج', OoredooApi.instance.purchaseYoutube)),
          const SizedBox(height: 20),
          _sectionHeader('الخدمات الإضافية', Icons.auto_awesome_outlined),
          Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.card_giftcard)), title: const Text('الهدية اليومية', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(_giftState), trailing: FilledButton.tonal(onPressed: _playGift, child: const Text('العب الآن')))),
          const SizedBox(height: 9),
          Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.sports_esports_outlined)), title: const Text('Power Snake', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('عرض الصناديق المتاحة واستلام المكافآت'), trailing: const Icon(Icons.chevron_right), onTap: _snake)),
          const SizedBox(height: 18),
          OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back), label: const Text('العودة إلى الأرقام المحفوظة')),
        ])),
      );

  Widget _sectionHeader(String title, IconData icon) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [Icon(icon, color: _red), const SizedBox(width: 9), Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))]));

  Widget _allowanceTile(DataAllowance item) => Padding(padding: const EdgeInsets.only(top: 17), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 7),
    Row(children: [Text('${_fmt(item.remaining)} ${item.unit} متبقي'), const Spacer(), Text('من ${_fmt(item.total)} ${item.unit}')]),
    const SizedBox(height: 7), ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(minHeight: 8, value: item.total != null && item.total! > 0 && item.remaining != null ? (item.remaining! / item.total!).clamp(0, 1) : null)),
    const SizedBox(height: 5), Text('المستهلك: ${_fmt(item.consumed)} ${item.unit}  •  الانتهاء: ${item.expiry}', style: Theme.of(context).textTheme.bodySmall),
  ]));

  Widget _packageTile(String title, String validity, String price, IconData icon, VoidCallback onTap) => Card(child: ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    leading: CircleAvatar(backgroundColor: _red.withOpacity(.10), child: Icon(icon, color: _red)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(validity),
    trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text(price, style: const TextStyle(fontWeight: FontWeight.bold, color: _red)), const Text('شراء', style: TextStyle(fontSize: 12))]),
    onTap: onTap,
  ));
}
