import 'package:flutter_test/flutter_test.dart';
import 'package:ooredoo_client/services/ooredoo_api.dart';

void main() {
  test('extracts allowance, remaining, consumed and expiry from nested CVM JSON', () {
    final parsed = OoredooApi.parseOffers({
      'offers': [
        {
          'Attributes': {
            'Code': 'BONUS_AZR_3D_data_5_GB',
            'Instances': [
              {'Attributes': {
                'Expire-At': '2026-11-24 23:59',
                'Allowances': [
                  {'Attributes': {
                    'Code': 'data', 'Usage-Value': '5', 'Usage-Unit': 'GB',
                    'Usage-Type': 'data', 'Available-Amount': '4.81'
                  }}
                ]
              }}
            ]
          }
        }
      ]
    });
    expect(parsed, hasLength(1));
    expect(parsed.single.total, 5);
    expect(parsed.single.remaining, 4.81);
    expect(parsed.single.consumed, closeTo(0.19, 0.000001));
    expect(parsed.single.expiry, '24-11-2026');
    expect(parsed.single.code, 'BONUS_AZR_3D_data_5_GB');
  });
}
