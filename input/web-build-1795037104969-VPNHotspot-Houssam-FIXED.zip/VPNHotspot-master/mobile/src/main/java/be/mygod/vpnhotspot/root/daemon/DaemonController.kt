package be.mygod.vpnhotspot.root.daemon

import android.net.LinkAddress
import android.net.LocalServerSocket
import android.os.ParcelFileDescriptor
import android.os.Process
import android.system.ErrnoException
import android.system.OsConstants
import androidx.collection.MutableLongObjectMap
import be.mygod.librootkotlinx.io.FileDescriptorByteReadChannel
import be.mygod.librootkotlinx.io.openReadChannel
import be.mygod.librootkotlinx.net.ALocalServerSocket
import be.mygod.librootkotlinx.net.ALocalSocket
import be.mygod.vpnhotspot.App.Companion.app
import be.mygod.vpnhotspot.io.drainLines
import be.mygod.vpnhotspot.io.isEBADF
import be.mygod.vpnhotspot.root.RootManager
import be.mygod.vpnhotspot.util.Services
import be.mygod.vpnhotspot.widget.SmartSnackbar
import dalvik.system.BaseDexClassLoader
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.readLineTo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ClosedReceiveChannelException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okio.ByteString.Companion.toByteString
import timber.log.Timber
import java.io.EOFException
import java.io.IOException
import kotlin.random.Random

object DaemonController {
    private const val BINARY_NAME = "vpnhotspotd"
    private val binaryFrameClassName get() = "${app.packageName}.$BINARY_NAME"

    private val lock = Mutex()
    private var socket: ALocalSocket? = null
    private var input: ByteReadChannel? = null
    private var output: ByteWriteChannel? = null
    private var readerJob: Job? = null
    private var nextCallId = 1L
    private val calls = MutableLongObjectMap<Call>()
    private var daemonStdioClosing = false
    private var daemonStdioEofReported = false
    private val logScope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private val stdoutLog = DaemonLog("stdout") { Timber.tag(BINARY_NAME).i(it) }
    private val stderrLog = DaemonLog("stderr") { Timber.tag(BINARY_NAME).e(it) }
    private var daemonCommandAbiChecked = false

    /**
     * Android 10 bionic supports direct linker execution of uncompressed, page-aligned zip entries:
     * https://android.googlesource.com/platform/bionic/+/android-10.0.0_r7/linker/linker_main.cpp#663
     * Android 10 DexPathList returns zip native-library paths only for stored entries:
     * https://android.googlesource.com/platform/libcore/+/android-10.0.0_r1/dalvik/src/main/java/dalvik/system/DexPathList.java#884
     */
    private val daemonCommand by lazy {
        val path = (app.classLoader as BaseDexClassLoader).findLibrary(BINARY_NAME) ?: error("Daemon binary missing")
        listOf(if (Process.is64Bit()) "/system/bin/linker64" else "/system/bin/linker", path)
    }

    class SessionCall(val id: Long, val events: Flow<EventFrame>) {
        suspend fun close() = closeEventCall(id)
    }

    suspend fun startSession(config: SessionConfig): SessionCall {
        val call = eventCall(ClientEnvelope(start_session = StartSessionCommand(config)))
        try {
            val event = try {
                call.channel.receive()
            } catch (e: DaemonException) {
                throw e.withCurrentTrace()
            } catch (e: ClosedReceiveChannelException) {
                throw IOException("$BINARY_NAME call ${call.id} completed before event", e)
            }
            event.requireAck()
        } catch (e: Exception) {
            withContext(NonCancellable) { closeEventCall(call.id) }
            throw e
        }
        return SessionCall(call.id, eventFlow(call, cancelOnClose = false))
    }

    suspend fun replaceSession(sessionId: Long, config: SessionConfig) {
        request(ClientEnvelope(replace_session = ReplaceSessionCommand(sessionId, config))).requireAck()
    }

    suspend fun readTrafficCounters(): List<TrafficCounter> {
        val reply = request(ClientEnvelope(read_traffic_counters = ReadTrafficCountersCommand()))
        return reply.traffic_counters?.counters ?: throw IOException("Unexpected daemon reply $reply")
    }

    fun neighbourMonitor(): Flow<NeighbourMonitorUpdate> = flow {
        eventFlow(eventCall(ClientEnvelope(start_neighbour_monitor = StartNeighbourMonitorCommand()))).collect {
            emit(it.neighbour_monitor ?: throw IOException("Unexpected daemon event $it"))
        }
    }

    suspend fun replaceStaticAddresses(dev: String, addresses: Iterable<LinkAddress>) {
        request(ClientEnvelope(replace_static_addresses = ReplaceStaticAddressesCommand(
            dev = dev,
            addresses = addresses.map { address ->
                IpAddressEntry(address.address.address.toByteString(), address.prefixLength)
            },
        ))).requireAck()
    }

    suspend fun cleanRouting(ipv6NatPrefixSeed: String) {
        request(ClientEnvelope(clean_routing = CleanRoutingCommand(ipv6NatPrefixSeed))).requireAck()
    }

    private sealed class Call {
        class OneShot(val reply: CompletableDeferred<ReplyFrame>) : Call()
        class Event(val channel: Channel<EventFrame>) : Call()
    }

    private class EventCall(val id: Long, val channel: Channel<EventFrame>)

    private class DaemonStdioEofException(message: String) : EOFException(message)

    private suspend fun ensureDaemonLocked() {
        if (socket != null) return
        Timber.d("Starting $BINARY_NAME")
        val command = daemonCommand
        if (!daemonCommandAbiChecked) {
            DaemonAbi.check(command[1])
            daemonCommandAbiChecked = true
        }
        daemonStdioClosing = false
        daemonStdioEofReported = false
        val socketName = "be.mygod.vpnhotspot.${Process.myPid()}.${Random.nextLong().toHexString()}"
        var stdout: ParcelFileDescriptor? = null
        var stderr: ParcelFileDescriptor? = null
        try {
            stdout = stdoutLog.openPipe(logScope)
            stderr = stderrLog.openPipe(logScope)
            ALocalServerSocket(LocalServerSocket(socketName), Services.mainHandler).use { serverSocket ->
                RootManager.use { server ->
                    try {
                        server.execute(RunDaemon(command, socketName, stdout!!, stderr!!))
                    } finally {
                        try {
                            stdout?.close()
                        } catch (_: IOException) { }
                        try {
                            stderr?.close()
                        } catch (_: IOException) { }
                        stdout = null
                        stderr = null
                    }
                }
                var acceptedDaemon: ALocalSocket? = null
                while (acceptedDaemon == null) {
                    val accepted = serverSocket.accept()
                    var acceptedByDaemon = false
                    try {
                        val uid = accepted.socket.peerCredentials.uid
                        if (uid == 0) {
                            acceptedByDaemon = true
                            acceptedDaemon = accepted
                        } else Timber.w("Rejected $BINARY_NAME connection from uid=$uid")
                    } finally {
                        if (!acceptedByDaemon) try {
                            accepted.close()
                        } catch (e: IOException) {
                            Timber.w(e, "Failed to close rejected $BINARY_NAME connection")
                        }
                    }
                }
                socket = acceptedDaemon
                input = acceptedDaemon.openReadChannel()
                output = acceptedDaemon.openWriteChannel()
                startReaderLocked(input!!)
                Timber.d("Started $BINARY_NAME")
            }
        } catch (e: Exception) {
            try {
                stdout?.close()
            } catch (_: IOException) { }
            try {
                stderr?.close()
            } catch (_: IOException) { }
            closeConnectionLocked()
            throw e
        }
    }

    private suspend fun request(command: ClientEnvelope): ReplyFrame {
        var id = 0L
        val reply = lock.withLock {
            id = nextCallIdLocked()
            val reply = CompletableDeferred<ReplyFrame>()
            try {
                ensureDaemonLocked()
                calls[id] = Call.OneShot(reply)
                writeCommandLocked(id, command)
                Timber.d("Sent #$id: $command")
            } catch (e: Exception) {
                calls.remove(id)
                closeConnectionLocked()
                throw e
            }
            reply
        }
        try {
            return reply.await()
        } catch (e: DaemonException) {
            throw e.withCurrentTrace()
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                lock.withLock {
                    cancelCallLocked(id)
                    maybeShutdownLocked()
                }
            }
            throw e
        }
    }

    private suspend fun eventCall(command: ClientEnvelope): EventCall {
        val channel = Channel<EventFrame>(Channel.UNLIMITED)
        val id = lock.withLock {
            val id = nextCallIdLocked()
            try {
                ensureDaemonLocked()
                calls[id] = Call.Event(channel)
                writeCommandLocked(id, command)
                Timber.d("Sent #$id: $command")
                id
            } catch (e: Exception) {
                calls.remove(id)
                closeConnectionLocked()
                throw e
            }
        }
        return EventCall(id, channel)
    }

    private fun eventFlow(call: EventCall, cancelOnClose: Boolean = true) = flow {
        try {
            for (event in call.channel) emit(event)
        } catch (e: DaemonException) {
            throw e.withCurrentTrace()
        } finally {
            if (cancelOnClose) withContext(NonCancellable) { closeEventCall(call.id) }
        }
    }.buffer(Channel.UNLIMITED)

    private suspend fun closeEventCall(id: Long) = lock.withLock {
        cancelCallLocked(id)
        maybeShutdownLocked()
    }

    private fun nextCallIdLocked(): Long {
        while (calls.containsKey(nextCallId)) nextCallId = if (nextCallId == Long.MAX_VALUE) 1 else nextCallId + 1
        return nextCallId.also { nextCallId = if (it == Long.MAX_VALUE) 1 else it + 1 }
    }

    private fun startReaderLocked(input: ByteReadChannel) {
        readerJob = logScope.launch {
            try {
                while (currentCoroutineContext().isActive) {
                    val envelope = DaemonEnvelope.ADAPTER.decode(DaemonIpc.readFrame(input))
                    when {
                        envelope.reply != null -> {
                            val frame = envelope.reply
                            val id = frame.call_id.readCallId()
                            val reply = lock.withLock {
                                when (val call = calls[id]) {
                                    is Call.OneShot -> {
                                        calls.remove(id)
                                        maybeShutdownLocked()
                                        call.reply
                                    }
                                    else -> {
                                        Timber.w("Unexpected $BINARY_NAME reply for call $id")
                                        null
                                    }
                                }
                            }
                            reply?.complete(frame)
                        }
                        envelope.event != null -> {
                            val frame = envelope.event
                            val id = frame.call_id.readCallId()
                            val call = lock.withLock { calls[id] as? Call.Event }
                            if (call != null) {
                                val result = call.channel.trySend(frame)
                                if (result.isFailure) {
                                    result.exceptionOrNull()?.let { call.channel.close(it) }
                                    lock.withLock {
                                        if (calls[id] === call) {
                                            cancelCallLocked(id)
                                            maybeShutdownLocked()
                                        }
                                    }
                                }
                            } else Timber.w("Dropping event for unknown $BINARY_NAME call $id")
                        }
                        envelope.error != null -> {
                            val frame = envelope.error
                            val id = frame.call_id.readCallId()
                            val report = frame.report ?: throw IOException("Missing daemon error report")
                            val exception = DaemonException(report, id, daemonClassName = binaryFrameClassName)
                            val call = lock.withLock {
                                val call = calls.remove(id)
                                if (call == null) Timber.w("Unexpected $BINARY_NAME error for call $id")
                                maybeShutdownLocked()
                                call
                            }
                            when (call) {
                                is Call.OneShot -> call.reply.completeExceptionally(exception)
                                is Call.Event -> call.channel.close(exception)
                                null -> { }
                            }
                        }
                        envelope.non_fatal != null -> {
                            val frame = envelope.non_fatal
                            val report = frame.report ?: throw IOException("Missing daemon nonfatal report")
                            val traced = DaemonException(
                                report,
                                frame.call_id?.readCallId(),
                                daemonClassName = binaryFrameClassName,
                            ).withCurrentTrace()
                            Timber.tag(BINARY_NAME).w(traced)
                            SmartSnackbar.make(traced).show()
                        }
                        envelope.complete != null -> {
                            val id = envelope.complete.call_id.readCallId()
                            val protocolError = lock.withLock {
                                when (val call = calls.remove(id)) {
                                    is Call.Event -> {
                                        call.channel.close()
                                        maybeShutdownLocked()
                                        null
                                    }
                                    is Call.OneShot -> {
                                        val error = IOException("Unexpected $BINARY_NAME complete for one-shot call $id")
                                        call.reply.completeExceptionally(error)
                                        maybeShutdownLocked()
                                        error
                                    }
                                    null -> {
                                        Timber.tag(BINARY_NAME).w("Unexpected $BINARY_NAME complete for unknown call $id")
                                        null
                                    }
                                }
                            }
                            if (protocolError != null) lock.withLock {
                                closeAndClearStateLocked(cause = protocolError)
                            }
                        }
                        else -> throw IOException("Missing daemon frame")
                    }
                }
            } catch (_: CancellationException) {
            } catch (e: Exception) {
                lock.withLock {
                    if (!daemonStdioClosing) {
                        Timber.w(e)
                        SmartSnackbar.make(e).show()
                    }
                    closeAndClearStateLocked(cancelReader = false, cause = e)
                }
            }
        }
    }

    private fun Long.readCallId(): Long {
        if (this <= 0) throw IOException("Invalid daemon call id $this")
        return this
    }

    private fun ReplyFrame.requireAck() {
        if (ack == null) {
            throw IOException("Unexpected daemon reply $this")
        }
    }

    private fun EventFrame.requireAck() {
        if (ack == null) {
            throw IOException("Unexpected daemon event $this")
        }
    }

    private fun completeCallsLocked(e: Throwable) {
        calls.forEachValue { call ->
            when (call) {
                is Call.OneShot -> call.reply.completeExceptionally(e)
                is Call.Event -> call.channel.close(e)
            }
        }
        calls.clear()
    }

    private suspend fun cancelCallLocked(id: Long) {
        val call = calls.remove(id) ?: return
        if (call is Call.Event) call.channel.close()
        if (output == null) return
        try {
            writeCommandLocked(id, ClientEnvelope(cancel = CancelCommand()))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Timber.w(e)
            closeConnectionLocked()
        }
    }

    private suspend fun maybeShutdownLocked() {
        if (output == null || calls.isNotEmpty()) return
        closeConnectionLocked()
    }

    private suspend fun closeAndClearStateLocked(
        cancelReader: Boolean = true,
        cause: Throwable? = null,
    ) {
        if (cause != null) completeCallsLocked(cause)
        closeConnectionLocked(cancelReader)
    }

    private suspend fun writeCommandLocked(id: Long, command: ClientEnvelope) {
        require(id > 0) { "Invalid daemon call id $id" }
        DaemonIpc.writeFrame(output!!, ClientEnvelope.ADAPTER.encode(command.copy(call_id = id)))
    }

    private suspend fun closeConnectionLocked(cancelReader: Boolean = true) = withContext(NonCancellable) {
        val wasConnected = socket != null || input != null || output != null || readerJob != null
        if (wasConnected) Timber.d("Stopping $BINARY_NAME")
        daemonStdioClosing = true
        completeCallsLocked(IOException("$BINARY_NAME connection closed"))
        if (cancelReader) readerJob?.cancel()
        readerJob = null
        input?.cancel(null)
        output?.cancel(null)
        try {
            socket?.close()
        } catch (_: IOException) { }
        withContext(Dispatchers.Main.immediate) {
            stdoutLog.close()
            stderrLog.close()
        }
        input = null
        output = null
        socket = null
        if (wasConnected) Timber.d("Stopped $BINARY_NAME")
    }

    private class DaemonLog(private val stream: String, private val log: (String) -> Unit) {
        private var channel: FileDescriptorByteReadChannel? = null
        private val line = StringBuilder()
        private var job: Job? = null

        fun openPipe(scope: CoroutineScope): ParcelFileDescriptor {
            val pipe = ParcelFileDescriptor.createPipe()
            var readEnd: ParcelFileDescriptor? = pipe[0]
            var writeEnd: ParcelFileDescriptor? = pipe[1]
            try {
                val channel = readEnd!!.openReadChannel(Services.mainHandler)
                this.channel = channel
                readEnd = null
                job = scope.launch {
                    try {
                        while (channel.readLineTo(line) >= 0) {
                            log(line.toString())
                            line.clear()
                        }
                        if (line.isNotEmpty()) {
                            log(line.toString())
                            line.clear()
                        }
                        lock.withLock {
                            if (!daemonStdioClosing && calls.isNotEmpty() && !daemonStdioEofReported) {
                                daemonStdioEofReported = true
                                Timber.w(DaemonStdioEofException("$BINARY_NAME $stream EOF calls=${calls.size}"))
                            }
                        }
                    } catch (e: ErrnoException) {
                        if (e.errno != OsConstants.EBADF) Timber.w(e)
                    } catch (e: IOException) {
                        if (!e.isEBADF) Timber.w(e)
                    }
                }
                return writeEnd!!.also { writeEnd = null }
            } finally {
                try {
                    readEnd?.close()
                } catch (_: IOException) { }
                try {
                    writeEnd?.close()
                } catch (_: IOException) { }
            }
        }

        suspend fun close() {
            channel?.let {
                try {
                    it.drain()
                } catch (e: ErrnoException) {
                    if (e.errno != OsConstants.EBADF) Timber.w(e)
                } catch (e: IOException) {
                    if (!e.isEBADF) Timber.w(e)
                }
            }
            job?.cancelAndJoin()
            job = null
            channel?.let {
                try {
                    it.drainLines(line, flushPartial = true, block = log)
                } catch (e: ErrnoException) {
                    if (e.errno != OsConstants.EBADF) Timber.w(e)
                } catch (e: IOException) {
                    if (!e.isEBADF) Timber.w(e)
                } finally {
                    it.cancel(null)
                }
            }
            channel = null
        }
    }
}
