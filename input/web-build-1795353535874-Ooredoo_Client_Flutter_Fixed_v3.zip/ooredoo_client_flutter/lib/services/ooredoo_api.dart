import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import '../core/constants.dart';
import '../models/app_models.dart';

class OoredooApi {
  OoredooApi._();
  static final OoredooApi instance = OoredooApi._();
  final _secure = const FlutterSecureStorage();
  late final Dio _dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 25), receiveTimeout: const Duration(seconds: 35), sendTimeout: const Duration(seconds: 25), validateStatus: (_) => true));
  bool _ready = false;
  OoredooAccount? account;
  String? platformInfo;
  String? lastBalance;
  DateTime? balanceUpdatedAt;
  DateTime? lastServerUpdate;

  Future<void> initialize() async {
    if (_ready) return;
    final dir = await getApplicationSupportDirectory();
    final jar = PersistCookieJar(storage: FileStorage('${dir.path}/http_cookies/'));
    _dio.interceptors.add(CookieManager(jar));
    _ready = true;
  }

  String _uuid() => '${_randomUuid()}${DateTime.now().millisecondsSinceEpoch}';
  String _randomUuid() {
    final r = Random.secure();
    final b = List<int>.generate(16, (_) => r.nextInt(256));
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    final h = b.map((e) => e.toRadixString(16).padLeft(2, '0')).join();
    return '${h.substring(0,8)}-${h.substring(8,12)}-${h.substring(12,16)}-${h.substring(16,20)}-${h.substring(20)}';
  }

  String normalizePhone(String input) {
    var v = input.replaceAll(RegExp(r'\s+'), '').replaceAll('+', '');
    if (v.startsWith('0') && v.length == 10) v = '213${v.substring(1)}';
    if (!RegExp(r'^213\d{9}$').hasMatch(v)) {
      throw const FormatException('أدخل الرقم بصيغة 05xxxxxxxx أو 2135xxxxxxxx');
    }
    return v;
  }

  Future<OoredooAccount> _accountFor(String msisdn) async {
    final raw = await _secure.read(key: 'account_$msisdn');
    if (raw != null) return OoredooAccount.fromJson(jsonDecode(raw));
    final a = OoredooAccount(msisdn: msisdn, instanceId: _uuid());
    await _secure.write(key: 'account_$msisdn', value: jsonEncode(a.toJson()));
    return a;
  }

  Future<void> _save() async {
    final a = account;
    if (a != null) await _secure.write(key: 'account_${a.msisdn}', value: jsonEncode(a.toJson()));
  }

  String _platformSignature(String id) => base64Encode(utf8.encode(jsonEncode({'platform':'android','is-physical-device':true,'device-id':id})));
  String _fingerprint(String iid, String msisdn, String ts) {
    final key = utf8.encode(ts);
    return Hmac(sha256, key).convert(utf8.encode('$ts$iid$msisdn')).toString();
  }
  Map<String, String> _headers({String contentType='application/json', String? path, String? method}) {
    final a = account!;
    final ts = DateTime.now().millisecondsSinceEpoch.toString();
    final h = <String,String>{
      'User-Agent': ApiConstants.userAgent, 'Connection':'Keep-Alive', 'Accept':'application/json',
      'Accept-Encoding':'gzip', 'Content-Type':contentType, 'x-msisdn':a.msisdn,
      'x-device-fingerprint':_fingerprint(a.instanceId,a.msisdn,ts), 'x-platform-origin':'mobile-android',
      'x-correlation-id':_uuid(), 'platform':'android', 'x-version':ApiConstants.version,
      'x-signature':ApiConstants.signature, 'x-platform-info':platformInfo!,
      'x-platform-data-signature':platformInfo!, 'x-timestamp':ts, 'x-instance-id':a.instanceId,
      'x-force-update':'true'
    };
    if (path != null) h['x-path'] = path;
    if (method != null) h['x-method'] = method.toUpperCase();
    return h;
  }

  Future<Map<String,String>> _checkpoint({String path=ApiConstants.tokenPath, String method='POST'}) async {
    final r = await _dio.post('${ApiConstants.bff}/checkpoint/token', data: {}, options: Options(headers: _headers(contentType:'application/json; charset=utf-8', path:path, method:method)));
    if (r.statusCode != 200 && r.statusCode != 202) throw Exception('Checkpoint rejected (${r.statusCode}): ${_message(r.data)}');
    final h = r.headers;
    final nonce = h.value('x-nonce-id'); final chronos = h.value('x-chronos-id');
    if (nonce == null || chronos == null) throw Exception('Checkpoint response did not contain nonce/chronos.');
    return {'nonce':nonce,'chronos':chronos};
  }

  Future<Map<String,dynamic>> _tokenRequest({required String nonce, required String chronos, String? otp, String? refresh}) async {
    final headers = _headers(contentType:'application/x-www-form-urlencoded; charset=utf-8')..addAll({'Accept':'*/*','x-nonce-id':nonce,'x-chronos-id':chronos});
    final form = <String,String>{'client_id':ApiConstants.clientId};
    if (refresh != null) { form.addAll({'grant_type':'refresh_token','refresh_token':refresh}); }
    else { form.addAll({'grant_type':'password','username':account!.msisdn}); if (otp != null) form['otp']=otp; }
    final r = await _dio.post(ApiConstants.tokenUrl, data:form, options:Options(headers:headers, contentType:Headers.formUrlEncodedContentType));
    final body = _asMap(r.data);
    if (r.statusCode == 200 && body['access_token'] != null) return body;
    if (otp == null && refresh == null && (r.statusCode == 400 || r.statusCode == 403)) return {'sms_sent':true,'detail':body};
    throw Exception('Token endpoint rejected (${r.statusCode}): ${_message(r.data)}');
  }

  Future<bool> hasSavedSession(String msisdn) async {
    final raw = await _secure.read(key:'account_$msisdn');
    if (raw == null) return false;
    final a = OoredooAccount.fromJson(jsonDecode(raw));
    return (a.accessToken?.isNotEmpty ?? false) || (a.refreshToken?.isNotEmpty ?? false);
  }

  Future<void> requestOtp(String phone) async {
    await initialize();
    final msisdn = normalizePhone(phone);
    account = await _accountFor(msisdn);
    platformInfo = _platformSignature(account!.instanceId);
    final cp = await _checkpoint();
    final result = await _tokenRequest(nonce:cp['nonce']!, chronos:cp['chronos']!);
    if (result['sms_sent'] != true && result['access_token'] == null) throw Exception('Unexpected OTP response.');
    if (result['access_token'] != null) await _storeTokens(result);
  }

  Future<void> verifyOtp(String otp) async {
    if (!RegExp(r'^\d{4,8}$').hasMatch(otp)) throw const FormatException('رمز OTP يجب أن يتكون من 4 إلى 8 أرقام.');
    final cp = await _checkpoint();
    final tokens = await _tokenRequest(nonce:cp['nonce']!, chronos:cp['chronos']!, otp:otp);
    await _storeTokens(tokens);
  }

  Future<void> _storeTokens(Map<String,dynamic> t) async {
    final a = account!; final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    a.accessToken = t['access_token'] ?? a.accessToken;
    a.refreshToken = t['refresh_token'] ?? a.refreshToken;
    a.accessExpiresAt = now + ((t['expires_in'] as num?)?.toInt() ?? 0);
    a.refreshExpiresAt = now + ((t['refresh_expires_in'] as num?)?.toInt() ?? 0);
    await _save();
  }

  Future<void> restore(String phone) async {
    await initialize();
    final msisdn = normalizePhone(phone);
    account = await _accountFor(msisdn); platformInfo = _platformSignature(account!.instanceId);
    await ensureSession();
  }

  Future<void> ensureSession() async {
    final a = account ?? (throw Exception('No account selected'));
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    if ((a.accessToken?.isNotEmpty ?? false) && now < a.accessExpiresAt - 60) return;
    if ((a.refreshToken?.isNotEmpty ?? false) && now < a.refreshExpiresAt - 60) {
      try {
        final cp = await _checkpoint();
        final t = await _tokenRequest(nonce:cp['nonce']!, chronos:cp['chronos']!, refresh:a.refreshToken);
        await _storeTokens(t); return;
      } catch (_) { /* Fall through: caller must re-authenticate. */ }
    }
    throw Exception('انتهت الجلسة. سجّل الدخول مجدداً برمز OTP.');
  }

  Future<Response<dynamic>> _authorized(String method, String path, {Map<String,dynamic>? query, dynamic data, String? checkpointPath, String checkpointMethod='POST'}) async {
    await ensureSession();
    Map<String,String>? checkpointHeaders;
    if (checkpointPath != null) {
      checkpointHeaders = await _checkpoint(path:checkpointPath, method:checkpointMethod);
    }
    final headers = _headers();
    headers['Authorization']='Bearer ${account!.accessToken}';
    if (checkpointHeaders != null) {
      headers['x-nonce-id']=checkpointHeaders['nonce']!;
      headers['x-chronos-id']=checkpointHeaders['chronos']!;
    }
    final options = Options(headers:headers);
    final url = '${ApiConstants.base}$path';
    final Response<dynamic> r;
    switch (method) {
      case 'GET': r = await _dio.get(url, queryParameters:query, options:options); break;
      case 'POST': r = await _dio.post(url, data:data, options:options); break;
      default: throw UnsupportedError(method);
    }
    lastServerUpdate = DateTime.now();
    if (r.statusCode == 401 || r.statusCode == 403) throw Exception('انتهت الجلسة أو فشل التفويض. أعد تسجيل الدخول.');
    return r;
  }

  Future<String> fetchBalance() async {
    final r = await _authorized('GET', ApiConstants.activePackagesPath, query:{'msisdn':account!.msisdn});
    final b = _asMap(r.data); if (r.statusCode! < 200 || r.statusCode! >= 300 || b['accountBalance'] == null) throw Exception('الرصيد غير متاح');
    lastBalance = '${b['accountBalance']}'; balanceUpdatedAt = DateTime.now(); return lastBalance!;
  }

  Future<List<DataAllowance>> fetchOffers() async {
    final r = await _authorized('GET', ApiConstants.offersPath);
    if (r.statusCode! < 200 || r.statusCode! >= 300) throw Exception('تعذر جلب العروض (${r.statusCode})');
    return parseOffers(r.data);
  }

  Future<List<DataAllowance>> fetchInternetUsage() async => fetchOffers();

  Future<List<SnakeBox>> fetchSnakeBoxes() async {
    final r = await _authorized('GET', ApiConstants.snakePath, query:{'status':'AVAILABLE'});
    if (r.statusCode! < 200 || r.statusCode! >= 300) throw Exception('تعذر جلب صناديق Power Snake');
    final items = _asMap(r.data)['items']; if (items is! List) return [];
    return items.whereType<Map>().where((e)=>e['uuid'] != null && '${e['status'] ?? 'AVAILABLE'}'.toUpperCase()=='AVAILABLE').map((e)=>SnakeBox(uuid:'${e['uuid']}',status:'${e['status'] ?? 'AVAILABLE'}',expiry:'${e['expiryDate'] ?? 'غير معروف'}')).toList();
  }

  Future<Map<String,dynamic>> redeemSnake(String uuid) async {
    final r = await _authorized('POST','${ApiConstants.snakePath}/$uuid/redeem');
    final b = _asMap(r.data); if (r.statusCode! >= 200 && r.statusCode! < 300) return b;
    final msg = _message(r.data).toUpperCase();
    if (msg.contains('EXPIRED')) throw Exception('انتهت صلاحية الصندوق.');
    if (msg.contains('ALREADY') || msg.contains('REDEEMED')) throw Exception('تم فتح هذا الصندوق مسبقاً.');
    throw Exception('تعذر فتح الصندوق: ${_message(r.data)}');
  }

  Future<void> purchaseBundle(String code) async {
    final r = await _authorized('POST',ApiConstants.purchasePath,data:{'bundleCode':code},checkpointPath:ApiConstants.purchasePath);
    _checkPurchase(r);
  }
  Future<void> purchaseYoutube() async {
    final r = await _authorized('POST',ApiConstants.byopPath,data:{'validity':'Monthly','limitedBundleDetails':[],'unlimitedBundleDetails':['YT']},checkpointPath:ApiConstants.byopPath);
    _checkPurchase(r);
  }
  void _checkPurchase(Response r) {
    final b = _asMap(r.data); final code = '${b['code'] ?? ''} ${b['message'] ?? ''}'.toUpperCase();
    if (['DYNAMIC_CREDIT_LIMIT_NOT_ENOUGH','INSUFFICIENT_BALANCE','INSUFFICIENT_CREDIT'].any(code.contains) || code.toLowerCase().contains('insufficient')) throw Exception('رصيدك غير كافٍ.');
    if (r.statusCode! < 200 || r.statusCode! >= 300) throw Exception('لم يتم تأكيد الشراء: ${_message(r.data)}');
  }

  Future<Map<String,dynamic>> giftStatus() async {
    final r = await _authorized('GET',ApiConstants.giftStatusPath);
    if (r.statusCode! < 200 || r.statusCode! >= 300) throw Exception('حالة الهدية غير متاحة');
    return _asMap(r.data);
  }
  Future<Map<String,dynamic>> playGift() async {
    final r = await _authorized('GET',ApiConstants.giftPlayPath,checkpointPath:ApiConstants.giftPlayPath,checkpointMethod:'GET');
    final b = _asMap(r.data);
    if (r.statusCode! >= 200 && r.statusCode! < 300 && b['giftName'] != null) return b;
    throw Exception('لا توجد هدية متاحة حالياً.');
  }

  Future<void> logout({bool deleteAccount=false}) async {
    final a = account;
    if (a != null) {
      if (deleteAccount) await _secure.delete(key:'account_${a.msisdn}');
      else { a.accessToken=null; a.refreshToken=null; a.accessExpiresAt=0; a.refreshExpiresAt=0; await _save(); }
    }
    account=null; platformInfo=null; lastBalance=null; balanceUpdatedAt=null;
  }

  static Map<String,dynamic> _asMap(dynamic value) => value is Map ? Map<String,dynamic>.from(value) : <String,dynamic>{};
  static String _message(dynamic value) => value is Map ? '${value['message'] ?? value['error_description'] ?? value['error'] ?? value}' : '$value';
  static String _normalKey(dynamic value) => '$value'.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  static dynamic _getCi(Map obj, List<String> names) {
    final wanted=names.map(_normalKey).toSet();
    for (final e in obj.entries) { if (wanted.contains(_normalKey(e.key)) && e.value != null && e.value != '' && e.value is! List && e.value is! Map) return e.value; }
    return null;
  }
  static double? _number(dynamic v) => v == null ? null : double.tryParse('$v'.replaceAll(',', '.').trim());
  static Iterable<Map> _walk(dynamic v) sync* {
    if (v is Map) { yield v; for (final child in v.values) { yield* _walk(child); } }
    else if (v is List) { for (final child in v) { yield* _walk(child); } }
  }
  static List<DataAllowance> parseOffers(dynamic body) {
    dynamic items=body;
    if (body is Map) {
      items=null;
      for (final k in ['items','allocations','offers','data','results']) { if (body[k] is List) {items=body[k];break;} }
      if (items==null) {
        final p=body['payload'];
        if (p is List) items=p;
        else if (p is Map) { for (final k in ['items','allocations','offers','data','results']) { if (p[k] is List) {items=p[k];break;} } items ??= [p]; }
        else {items=body.isEmpty?[]:[body];}
      }
    }
    if (items is! List) return [];
    final rows=<DataAllowance>[];
    for (final item in items) {
      final dicts=_walk(item).toList(); String? code,name,expiry;
      for (final d in dicts) {
        code ??= _getCi(d,['code','bundleCode'])?.toString();
        name ??= _getCi(d,['name','offerName','bundleName'])?.toString();
        expiry ??= _getCi(d,['expire-at','expiryDate','expirationDate','endDate'])?.toString();
      }
      for (final d in dicts) {
        final usageType=_getCi(d,['usage-type','usageType'])?.toString().toLowerCase();
        final allowanceCode=_getCi(d,['code'])?.toString().toLowerCase();
        final total=_getCi(d,['usage-value','usageValue']); final unit=_getCi(d,['usage-unit','usageUnit']);
        final remaining=_getCi(d,['available-amount','availableAmount','remaining','remainingVolume']);
        if (total==null || unit==null || remaining==null) continue;
        if (usageType!=null && !['data','internet'].contains(usageType)) continue;
        if (allowanceCode!=null && !['data','internet'].contains(allowanceCode) && usageType==null) continue;
        final t=_number(total), rem=_number(remaining);
        final parsed=_parseDate(expiry);
        rows.add(DataAllowance(name:name??code??'Active offer',code:code??allowanceCode??'—',total:t,unit:'$unit',remaining:rem,consumed:t!=null&&rem!=null?max(0,t-rem):null,expiry:parsed==null?(expiry??'غير محدد'):'${parsed.day.toString().padLeft(2,'0')}-${parsed.month.toString().padLeft(2,'0')}-${parsed.year}'));
      }
    }
    return rows;
  }
  static DateTime? _parseDate(String? s) {
    if (s==null || s.isEmpty) return null;
    return DateTime.tryParse(s.replaceFirst(' ','T')) ?? DateTime.tryParse(s);
  }
}
