# Ooredoo Client

Flutter Android client based on the supplied `ooredoo_client_professional.py` source.

## Build

Requirements: Flutter stable (3.29+ recommended), Android SDK, Android Build Tools, JDK 17.

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

Application ID: `com.khaled.ooredoo.client`.

## Implemented API operations

The API layer is isolated in `lib/services/ooredoo_api.dart` and retains the source script's host, BFF/token endpoints, client ID, version/signature constants, user-agent, platform signature, HMAC-SHA256 fingerprint construction, dynamic correlation ID/timestamp, checkpoint nonce/chronos flow, OTP/password grant, refresh-token grant, and the original request paths/payloads for:

- `getActivePackages` / `accountBalance`
- Power Snake available boxes and UUID redeem
- dynamic bundle purchase for 1GB and 2GB
- BYOP YouTube purchase
- daily gift status and play
- CVM active offers with case-insensitive recursive allowance parsing

Session records and the one-time app-unlocked flag use Android Keystore-backed `flutter_secure_storage`. HTTP cookies are persisted in the app support directory. The balance refresh timer runs every 60 seconds while the dashboard is alive.

## App lock note

The supplied passphrase is represented only by its SHA-256 digest in the client. This prevents it from being displayed or stored as plain text, but a password embedded in an APK is not a strong security boundary: a determined person can patch a locally controlled app. Use Android device authentication or a server-verified secret for high-assurance protection.

## Important API/testing limitations

The source Python script was inspected and its request flow and payloads were ported. This environment does not contain Flutter/Dart or Android SDK tooling, and the Ooredoo API cannot be authenticated/tested from this build environment. Consequently, `flutter analyze`, an Android build, and live OTP/purchase/redeem tests could not be run here; no live API success is claimed. The app treats purchases as accepted only on a successful HTTP response and surfaces API errors.

The current screens are Arabic-first. API models are locale-neutral and the Material theme supports RTL through Flutter's directionality, but complete English and French UI translations are not yet included. No fake API data or demo transaction success is used.

A GitHub Actions workflow is included at `.github/workflows/android.yml`; it installs Flutter stable, regenerates standard Android wrapper metadata, runs analysis/tests, and uploads the release APK artifact.

### Android build compatibility

The Gradle wrapper is pinned to Gradle 8.14.3. This satisfies the minimum Gradle 8.14.0 required by the Flutter SDK used by the AndroidForge build runner. Keep this wrapper version (or a newer Flutter-compatible version) when building in CI.
