#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

fail() { printf 'ERROR: %s\n' "$1" >&2; exit 1; }
command -v java >/dev/null 2>&1 || fail 'JDK 21 is required. Select Android Studio JBR 21 or install JDK 21.'
command -v cargo >/dev/null 2>&1 || fail 'Rust/Cargo is missing. See BUILDING.md.'
command -v cargo-ndk >/dev/null 2>&1 || fail 'cargo-ndk is missing. Install it with: cargo install cargo-ndk'

sdk="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[[ -n "$sdk" && -d "$sdk" ]] || fail 'Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK directory.'

for target in aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android; do
  rustup target list --installed | grep -qx "$target" || fail "Rust target $target is missing. Install all targets listed in BUILDING.md."
done

exec ./gradlew :mobile:assembleDebug "$@"
