# Building VPN Hotspot

This project contains an Android app **and a Rust native daemon**. Android Studio/Gradle alone is not enough: the Rust toolchain and Android NDK must also be installed.

## Required tools

- JDK 21 (Android Studio's bundled JBR 21 is suitable)
- Android SDK Platform 37 and Android Build Tools installed from SDK Manager
- Android NDK (side-by-side; install a current NDK from SDK Manager)
- Rust stable toolchain
- `cargo-ndk`
- Rust Android targets: `aarch64-linux-android`, `armv7-linux-androideabi`, `i686-linux-android`, `x86_64-linux-android`

Install Rust components/targets:

```sh
rustup toolchain install stable
rustup default stable
rustup component add rust-src
rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android
cargo install cargo-ndk
```

Set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) to the Android SDK directory. Set `ANDROID_NDK_HOME` to the installed NDK directory if it is not detected automatically. Make sure the NDK's LLVM toolchain is on the path as required by `cargo-ndk`.

## Build a debug APK

```sh
./gradlew :mobile:assembleDebug
```

The project creates ABI-specific APKs. They are placed under:

```text
mobile/build/outputs/apk/debug/
```

For a release build:

```sh
./gradlew :mobile:assembleRelease
```

Release signing must be configured separately before distributing the APK.

## Common failures

- `Could not find ... gradle-...zip`: network/proxy/DNS issue while downloading the Gradle distribution. Retry with a working connection; this is not a source-code compilation error.
- `SDK location not found`: install Android SDK and set `ANDROID_HOME`/`ANDROID_SDK_ROOT`, or create `local.properties` with `sdk.dir=...` (do not commit that machine-specific file).
- `cargo: command not found` / `cargo-ndk: command not found`: install Rust and `cargo-ndk` as above.
- `can't find crate for ...` / missing target: install all four Rust targets listed above.
- NDK/Clang errors: install NDK from Android Studio SDK Manager and point `ANDROID_NDK_HOME` to that exact installation.
