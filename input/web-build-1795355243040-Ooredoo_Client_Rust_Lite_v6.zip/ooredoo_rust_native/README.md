# Ooredoo Client — Rust Native Edition

نسخة خفيفة أعيد بناؤها دون Flutter أو Dart أو Material Components.

## البنية
- **Rust**: طلبات Ooredoo API، OTP، checkpoint، إنشاء الرؤوس والتوقيع، OAuth refresh، parsing للعروض، الشراء، الهدية وPower Snake.
- **Android Native UI**: واجهة Android أصلية بسيطة عبر Kotlin فقط كطبقة عرض وجسر JNI؛ لا يوجد Flutter runtime ولا Compose ولا مكتبات UI خارجية.
- **التخزين**: قائمة الحسابات والجلسات في SharedPreferences محلياً. الجلسات تشمل رموز OAuth وبيانات cookies.
- **المعمارية**: ARM64 فقط (`arm64-v8a`) لتقليل الحجم، مناسبة لمعظم الهواتف الحديثة مثل Motorola Edge 40 Neo.
- **تحسين الإصدار**: Release + R8 + resource shrinking + Rust release/LTO/strip.

## البناء على GitHub Actions
1. ارفع محتويات هذا المجلد إلى مستودع GitHub.
2. افتح Actions وشغّل `Build lightweight Rust Android APK`.
3. نزّل artifact باسم `Ooredoo-Rust-ARM64-APK`.
4. الملف مخصص لأجهزة ARM64؛ لا يثبت على محاكيات x86.

## الحجم المستهدف
تم حذف Flutter بالكامل وحصر APK على ARM64 مع Rust وواجهة Android أصلية. الإعدادات تستهدف APK أقل من 15MB، لكن الحجم النهائي لا يمكن ضمانه قبل تنفيذ البناء الفعلي؛ يعتمد على حجم مكتبات TLS والـNDK ونتيجة R8.

## تنبيه تقني
لا يمكن أن تكون واجهة Android عملية بالكامل بـRust وحده دون إطار واجهة/طبقة Android إضافية. لذلك يستخدم هذا المشروع Kotlin صغيراً لعرض عناصر Android الأصلية واستدعاء Rust عبر JNI، بينما منطق API ومعالجة البيانات في Rust.

استخدم التطبيق فقط مع أرقام وحسابات تملكها أو لديك إذن باستخدامها. لا تشارك ملفات APK الموقعة أو بيانات الجلسات مع الآخرين.
