package com.khaled.ooredoo.client

internal object NativeBridge {
    init { System.loadLibrary("ooredoo_core") }
    @JvmStatic external fun nativeCall(action: String, payload: String): String
}
