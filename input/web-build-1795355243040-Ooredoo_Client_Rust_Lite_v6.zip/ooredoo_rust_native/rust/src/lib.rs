use base64::{engine::general_purpose::STANDARD as B64, Engine};
use hmac::{Hmac, Mac};
use jni::{objects::{JClass, JString}, sys::jstring, JNIEnv};
use reqwest::{blocking::{Client, Response}, header::{HeaderMap, HeaderName, HeaderValue, SET_COOKIE}};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::Sha256;
use std::{collections::BTreeMap, time::{SystemTime, UNIX_EPOCH}};
use uuid::Uuid;

type HmacSha256 = Hmac<Sha256>;
const BASE: &str = "https://apis.ooredoo.dz";
const BFF: &str = "https://apis.ooredoo.dz/api/ooredoo-bff";
const TOKEN_URL: &str = "https://apis.ooredoo.dz/api/auth/realms/myooredoo/protocol/openid-connect/token";
const TOKEN_PATH: &str = "/api/auth/realms/myooredoo/protocol/openid-connect/token";
const CLIENT_ID: &str = "myooredoo-app";
const SIGNATURE: &str = "ee41e0dcab1ac6840c6d83cba9dcbe1d4b24074fdab16718ae12f48950080114";
const VERSION: &str = "1.5.21";

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct Account {
    msisdn: String,
    instance_id: String,
    #[serde(default)] access_token: Option<String>,
    #[serde(default)] refresh_token: Option<String>,
    #[serde(default)] access_expires_at: i64,
    #[serde(default)] refresh_expires_at: i64,
    #[serde(default)] cookies: BTreeMap<String, String>,
}

fn now() -> i64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64 }
fn uuid() -> String { Uuid::new_v4().to_string() }
fn normalize_phone(input: &str) -> Result<String, String> {
    let mut p = input.chars().filter(|c| !c.is_whitespace() && *c != '+').collect::<String>();
    if p.starts_with('0') && p.len() == 10 { p = format!("213{}", &p[1..]); }
    if p.len() != 12 || !p.starts_with("213") || !p[3..].chars().all(|c| c.is_ascii_digit()) { return Err("أدخل الرقم بصيغة 05xxxxxxxx أو 2135xxxxxxxx".into()); }
    Ok(p)
}
fn platform_info(a: &Account) -> String {
    B64.encode(serde_json::to_vec(&json!({"platform":"android","is-physical-device":true,"device-id":a.instance_id})).unwrap_or_default())
}
fn fingerprint(a: &Account, ts: &str) -> String {
    let mut mac = HmacSha256::new_from_slice(ts.as_bytes()).expect("hmac key");
    mac.update(format!("{}{}{}", ts, a.instance_id, a.msisdn).as_bytes());
    hex(&mac.finalize().into_bytes())
}
fn hex(bytes: &[u8]) -> String { bytes.iter().map(|b| format!("{b:02x}")).collect() }
fn client() -> Result<Client, String> { Client::builder().timeout(std::time::Duration::from_secs(35)).user_agent("Dart/3.11 (dart:io)").build().map_err(|e| e.to_string()) }
fn headers(a: &Account, path: Option<&str>, method: Option<&str>, content_type: &str, auth: bool) -> Result<HeaderMap, String> {
    let ts = (now() * 1000).to_string();
    let pinfo = platform_info(a);
    let mut h = HeaderMap::new();
    let pairs = vec![
        ("accept", "application/json".to_string()), ("accept-encoding", "gzip".to_string()),
        ("content-type", content_type.to_string()), ("x-msisdn", a.msisdn.clone()),
        ("x-device-fingerprint", fingerprint(a, &ts)), ("x-platform-origin", "mobile-android".into()),
        ("x-correlation-id", format!("{}{}", uuid(), ts)), ("platform", "android".into()),
        ("x-version", VERSION.into()), ("x-signature", SIGNATURE.into()),
        ("x-platform-info", pinfo.clone()), ("x-platform-data-signature", pinfo),
        ("x-timestamp", ts), ("x-instance-id", a.instance_id.clone()), ("x-force-update", "true".into()),
    ];
    for (k,v) in pairs { h.insert(HeaderName::from_bytes(k.as_bytes()).map_err(|e|e.to_string())?, HeaderValue::from_str(&v).map_err(|e|e.to_string())?); }
    if let Some(p) = path { h.insert("x-path", HeaderValue::from_str(p).map_err(|e|e.to_string())?); }
    if let Some(m) = method { h.insert("x-method", HeaderValue::from_str(&m.to_uppercase()).map_err(|e|e.to_string())?); }
    if auth { if let Some(t) = &a.access_token { h.insert("authorization", HeaderValue::from_str(&format!("Bearer {t}")).map_err(|e|e.to_string())?); } }
    if !a.cookies.is_empty() { let c = a.cookies.iter().map(|(k,v)|format!("{k}={v}")).collect::<Vec<_>>().join("; "); h.insert("cookie", HeaderValue::from_str(&c).map_err(|e|e.to_string())?); }
    Ok(h)
}
fn update_cookies(a: &mut Account, r: &Response) {
    for raw in r.headers().get_all(SET_COOKIE).iter() {
        if let Ok(s) = raw.to_str() { if let Some(pair) = s.split(';').next() { if let Some((k,v)) = pair.split_once('=') { a.cookies.insert(k.trim().into(), v.trim().into()); } } }
    }
}
fn response_json(r: Response, a: &mut Account) -> Result<(u16, Value), String> {
    let status = r.status().as_u16(); update_cookies(a, &r);
    let body = r.json::<Value>().unwrap_or(Value::Null); Ok((status, body))
}
fn checkpoint(a: &mut Account, path: &str, method: &str) -> Result<(String,String), String> {
    let c = client()?; let h = headers(a, Some(path), Some(method), "application/json; charset=utf-8", false)?;
    let r = c.post(format!("{BFF}/checkpoint/token")).headers(h).json(&json!({})).send().map_err(|e|e.to_string())?;
    let status = r.status().as_u16(); update_cookies(a, &r);
    if status != 200 && status != 202 { return Err(format!("Checkpoint rejected ({status})")); }
    let nonce = r.headers().get("x-nonce-id").and_then(|v|v.to_str().ok()).unwrap_or("").to_string();
    let chronos = r.headers().get("x-chronos-id").and_then(|v|v.to_str().ok()).unwrap_or("").to_string();
    if nonce.is_empty() || chronos.is_empty() { return Err("Checkpoint response did not contain nonce/chronos".into()); }
    Ok((nonce,chronos))
}
fn token_request(a: &mut Account, nonce: &str, chronos: &str, otp: Option<&str>, refresh: Option<&str>) -> Result<Value,String> {
    let c=client()?; let mut h=headers(a,None,None,"application/x-www-form-urlencoded; charset=utf-8",false)?;
    h.insert("accept", HeaderValue::from_static("*/*"));
    h.insert("x-nonce-id",HeaderValue::from_str(nonce).map_err(|e|e.to_string())?);
    h.insert("x-chronos-id",HeaderValue::from_str(chronos).map_err(|e|e.to_string())?);
    let mut form=vec![("client_id",CLIENT_ID.to_string())];
    if let Some(rt)=refresh { form.push(("grant_type","refresh_token".into())); form.push(("refresh_token",rt.into())); }
    else { form.push(("grant_type","password".into())); form.push(("username",a.msisdn.clone())); if let Some(code)=otp {form.push(("otp",code.into()));} }
    let r=c.post(TOKEN_URL).headers(h).form(&form).send().map_err(|e|e.to_string())?;
    let (status,b)=response_json(r,a)?;
    if status==200 && b.get("access_token").is_some() { return Ok(b); }
    if otp.is_none() && refresh.is_none() && (status==400 || status==403) { return Ok(json!({"sms_sent":true,"detail":b})); }
    Err(format!("Token endpoint rejected ({status}): {}", message(&b)))
}
fn store_tokens(a: &mut Account, t: &Value) {
    if let Some(v)=t.get("access_token").and_then(Value::as_str) {a.access_token=Some(v.into());}
    if let Some(v)=t.get("refresh_token").and_then(Value::as_str) {a.refresh_token=Some(v.into());}
    a.access_expires_at=now()+t.get("expires_in").and_then(Value::as_i64).unwrap_or(0);
    a.refresh_expires_at=now()+t.get("refresh_expires_in").and_then(Value::as_i64).unwrap_or(0);
}
fn ensure_session(a: &mut Account) -> Result<(),String> {
    if a.access_token.is_some() && now()<a.access_expires_at-60 {return Ok(());}
    if let Some(rt)=a.refresh_token.clone() { if now()<a.refresh_expires_at-60 {
        let (n,ch)=checkpoint(a,TOKEN_PATH,"POST")?; let t=token_request(a,&n,&ch,None,Some(&rt))?; store_tokens(a,&t); return Ok(());
    }}
    Err("انتهت الجلسة. سجّل الدخول مجدداً برمز OTP.".into())
}
fn authorized(a: &mut Account, method: &str, path: &str, query: Option<&str>, body: Option<Value>, cp: bool, cp_method: &str) -> Result<Value,String> {
    ensure_session(a)?;
    let nonce = if cp { Some(checkpoint(a,path,cp_method)?) } else {None};
    let mut h=headers(a,None,None,"application/json",true)?;
    if let Some((n,ch))=nonce {h.insert("x-nonce-id",HeaderValue::from_str(&n).map_err(|e|e.to_string())?);h.insert("x-chronos-id",HeaderValue::from_str(&ch).map_err(|e|e.to_string())?);}
    let c=client()?; let url=format!("{BASE}{path}");
    let mut req=if method=="GET" {c.get(&url)} else {c.post(&url)};
    req=req.headers(h);
    if let Some(q)=query {req=req.query(&[("msisdn",q)]);}
    if let Some(b)=body {req=req.json(&b);}
    let r=req.send().map_err(|e|e.to_string())?; let (status,b)=response_json(r,a)?;
    if status==401 || status==403 {return Err("انتهت الجلسة أو فشل التفويض. أعد تسجيل الدخول.".into());}
    if !(200..300).contains(&status) {return Err(format!("طلب API فشل ({status}): {}",message(&b)));}
    Ok(b)
}
fn message(v:&Value)->String {v.get("message").or_else(||v.get("error_description")).or_else(||v.get("error")).map(|x|x.as_str().map(str::to_string).unwrap_or_else(||x.to_string())).unwrap_or_else(||v.to_string())}
fn walk_offer(v:&Value, rows:&mut Vec<Value>) {
    match v {Value::Object(m)=>{let norm=|s:&str|s.to_ascii_lowercase().replace(|c:char|!c.is_ascii_alphanumeric(),"");
        let get=|keys:&[&str]|->Option<Value>{m.iter().find(|(k,v)|keys.iter().any(|x|norm(k)==norm(x))&&!v.is_null()&&!v.is_object()&&!v.is_array()).map(|(_,v)|v.clone())};
        let total=get(&["usage-value","usageValue"]); let unit=get(&["usage-unit","usageUnit"]); let rem=get(&["available-amount","availableAmount","remaining","remainingVolume"]);
        if let (Some(t),Some(u),Some(r))=(total,unit,rem) {let tn=t.as_f64().or_else(||t.as_str()?.replace(',','.').parse().ok());let rn=r.as_f64().or_else(||r.as_str()?.replace(',','.').parse().ok());
            let name=get(&["name","offerName","bundleName"]).or_else(||get(&["code","bundleCode"])).unwrap_or(json!("Active offer"));
            let code=get(&["code","bundleCode"]).unwrap_or(json!("—"));let expiry=get(&["expire-at","expiryDate","expirationDate","endDate"]).unwrap_or(json!("غير محدد"));
            let ut=get(&["usage-type","usageType"]).unwrap_or(json!("data")).to_string().to_lowercase();
            if ut.contains("data")||ut.contains("internet") {rows.push(json!({"name":name,"code":code,"total":tn,"unit":u,"remaining":rn,"consumed":match(tn,rn){(Some(x),Some(y))=>Some((x-y).max(0.0)),_=>None},"expiry":expiry}));}
        }
        for child in m.values(){walk_offer(child,rows);}
    },Value::Array(a)=>for x in a {walk_offer(x,rows)},_=>{}}
}
fn run(action:&str, mut p:Value)->Result<Value,String>{
    let mut a:Account=if let Some(x)=p.get("account"){serde_json::from_value(x.clone()).unwrap_or_default()}else{Account::default()};
    match action {
        "request_otp"=>{a.msisdn=normalize_phone(p.get("phone").and_then(Value::as_str).unwrap_or(""))?;if a.instance_id.is_empty(){a.instance_id=uuid();}let(n,ch)=checkpoint(&mut a,TOKEN_PATH,"POST")?;let t=token_request(&mut a,&n,&ch,None,None)?;if t.get("access_token").is_some(){store_tokens(&mut a,&t);}Ok(json!({"sms_sent":true,"account":a}))},
        "verify_otp"=>{let otp=p.get("otp").and_then(Value::as_str).unwrap_or("");if otp.len()<4||otp.len()>8||!otp.chars().all(|c|c.is_ascii_digit()){return Err("رمز OTP يجب أن يتكون من 4 إلى 8 أرقام.".into());}let(n,ch)=checkpoint(&mut a,TOKEN_PATH,"POST")?;let t=token_request(&mut a,&n,&ch,Some(otp),None)?;store_tokens(&mut a,&t);Ok(json!({"account":a,"verified":true}))},
        "dashboard"=>{let phone=a.msisdn.clone();let balance=authorized(&mut a,"GET","/api/ooredoo-bff/bundle/getActivePackages",Some(&phone),None,false,"POST")?;let offers=authorized(&mut a,"GET","/api/ooredoo-bff/cvm/getCvmAllocations",None,None,false,"POST").unwrap_or(Value::Array(vec![]));let mut rows=vec![];walk_offer(&offers,&mut rows);Ok(json!({"account":a,"balance":balance.get("accountBalance").cloned().unwrap_or(Value::Null),"offers":rows,"raw_offers":offers}))},
        "purchase_bundle"=>{let code=p.get("code").and_then(Value::as_str).unwrap_or("");let b=authorized(&mut a,"POST","/api/ooredoo-bff/cvm/dynamic-bundle-purchase",None,Some(json!({"bundleCode":code})),true,"POST")?;Ok(json!({"account":a,"result":b}))},
        "purchase_youtube"=>{let b=authorized(&mut a,"POST","/api/ooredoo-bff/bundle/purchase/byop",None,Some(json!({"validity":"Monthly","limitedBundleDetails":[],"unlimitedBundleDetails":["YT"]})),true,"POST")?;Ok(json!({"account":a,"result":b}))},
        "gift_status"=>{let b=authorized(&mut a,"GET","/api/ooredoo-bff/gamification/status",None,None,false,"POST")?;Ok(json!({"account":a,"result":b}))},
        "play_gift"=>{let b=authorized(&mut a,"GET","/api/ooredoo-bff/gamification/play",None,None,true,"GET")?;Ok(json!({"account":a,"result":b}))},
        "snake_list"=>{let h=authorized(&mut a,"GET","/api/ooredoo-bff/gamification/power-snake?status=AVAILABLE",None,None,false,"POST")?;let items=h.get("items").cloned().unwrap_or(json!([]));Ok(json!({"account":a,"items":items}))},
        "snake_redeem"=>{let id=p.get("uuid").and_then(Value::as_str).unwrap_or("");let path=format!("/api/ooredoo-bff/gamification/power-snake/{id}/redeem");let b=authorized(&mut a,"POST",&path,None,None,false,"POST")?;Ok(json!({"account":a,"result":b}))},
        _=>Err(format!("Unknown native action: {action}"))
    }
}

#[no_mangle]
pub extern "system" fn Java_com_khaled_ooredoo_client_NativeBridge_nativeCall(mut env: JNIEnv, _class: JClass, action: JString, payload: JString) -> jstring {
    let act=env.get_string(&action).map(|s|s.to_string_lossy().into_owned()).unwrap_or_default();
    let raw=env.get_string(&payload).map(|s|s.to_string_lossy().into_owned()).unwrap_or_else(|_|"{}".into());
    let parsed=serde_json::from_str::<Value>(&raw).unwrap_or(json!({}));
    let result=match run(&act,parsed){Ok(v)=>json!({"ok":true,"data":v}),Err(e)=>json!({"ok":false,"error":e})};
    env.new_string(result.to_string()).map(|s|s.into_raw()).unwrap_or(std::ptr::null_mut())
}
